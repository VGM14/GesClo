const { app, BrowserWindow } = require('electron')
const path = require('path')
const http = require('http')
const { spawn } = require('child_process')

const PORT = 3001

// In sviluppo server/frontend vivono in ../server e ../frontend. Una volta pacchettizzato,
// electron-builder li copia in resources/server e resources/frontend (vedi extraResources in package.json).
const SERVER_DIR    = app.isPackaged
  ? path.join(process.resourcesPath, 'server')
  : path.join(__dirname, '..', 'server')
const FRONTEND_HTML = app.isPackaged
  ? path.join(process.resourcesPath, 'frontend', 'dist', 'index.html')
  : path.join(__dirname, '..', 'frontend', 'dist', 'index.html')

let serverProcess = null
let mainWindow    = null

function startServer() {
  // ELECTRON_RUN_AS_NODE fa si che l'exe di Electron si comporti come un normale
  // interprete Node: non serve Node.js installato separatamente sulla macchina.
  serverProcess = spawn(process.execPath, [path.join(SERVER_DIR, 'server.js')], {
    cwd: SERVER_DIR,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', PORT: String(PORT) },
    stdio: 'ignore',
    windowsHide: true
  })
  serverProcess.on('exit', (code) => {
    if (mainWindow && code !== 0) {
      console.error(`Server terminato inaspettatamente (codice ${code})`)
    }
  })
}

function waitForServer(callback, attempt = 0) {
  const req = http.get(`http://localhost:${PORT}/health`, (res) => {
    res.resume()
    callback()
  })
  req.on('error', () => {
    if (attempt > 60) return callback(new Error('Il server non ha risposto in tempo'))
    setTimeout(() => waitForServer(callback, attempt + 1), 500)
  })
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 960,
    minHeight: 600,
    title: 'GesClo',
    icon: path.join(__dirname, '..', 'GesClo.ico'),
    autoHideMenuBar: true,
    show: false,
    backgroundColor: '#1a1a2e'
  })
  mainWindow.setMenuBarVisibility(false)
  // Carica la UI dal disco (file://), non dalla rete: nessun browser esterno puo raggiungerla.
  // Il server su :3001 resta attivo solo per le chiamate API (fetch verso /api/*).
  mainWindow.loadFile(FRONTEND_HTML)
  mainWindow.once('ready-to-show', () => mainWindow.show())
  mainWindow.on('closed', () => { mainWindow = null })
}

function stopServer() {
  if (!serverProcess) return
  try { serverProcess.kill() } catch {}
  serverProcess = null
}

app.whenReady().then(() => {
  startServer()
  waitForServer((err) => {
    if (err) {
      console.error(err)
      stopServer()
      app.quit()
      return
    }
    createWindow()
  })
})

app.on('window-all-closed', () => {
  stopServer()
  if (process.platform !== 'darwin') app.quit()
})

app.on('before-quit', stopServer)
