package com.gesclo.nfcreader;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * GesClo NFC Reader
 *
 * Distingue automaticamente:
 *  - Tag NFC prodotto (MIFARE, NTAG, FeliCa, ecc.)  → source: product_tag
 *  - Carta di pagamento contactless (EMV ISO-DEP)    → source: payment_card
 */
public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "gesclo_nfc";

    private NfcAdapter    nfcAdapter;
    private PendingIntent pendingIntent;

    private EditText etServerIp, etApiKey;
    private TextView tvStatus, tvLastScan, tvPhoneIp;
    private Button   btnSave;
    private SharedPreferences prefs;

    // ── Lifecycle ─────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs      = getSharedPreferences(PREFS, MODE_PRIVATE);
        etServerIp = findViewById(R.id.et_server_ip);
        etApiKey   = findViewById(R.id.et_api_key);
        tvStatus   = findViewById(R.id.tv_status);
        tvLastScan = findViewById(R.id.tv_last_scan);
        tvPhoneIp  = findViewById(R.id.tv_phone_ip);
        btnSave    = findViewById(R.id.btn_save);

        etServerIp.setText(prefs.getString("server_ip", ""));
        etApiKey.setText(prefs.getString("api_key", ""));

        // Mostra l'IP del telefono sulla rete WiFi
        tvPhoneIp.setText("IP telefono: " + getWifiIp());

        btnSave.setOnClickListener(v -> {
            prefs.edit()
                .putString("server_ip", etServerIp.getText().toString().trim())
                .putString("api_key",   etApiKey.getText().toString().trim())
                .apply();
            tvStatus.setText("✓ Impostazioni salvate");
        });

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            tvStatus.setText("NFC non disponibile su questo dispositivo");
            return;
        }

        Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = (Build.VERSION.SDK_INT >= 31) ? PendingIntent.FLAG_MUTABLE : 0;
        pendingIntent = PendingIntent.getActivity(this, 0, intent, flags);

        updateStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        if (nfcAdapter != null) { nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null); updateStatus(); }
    }
    @Override protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) nfcAdapter.disableForegroundDispatch(this);
    }

    // ── NFC dispatch ──────────────────────────────────────────────
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag == null) return;

        // IsoDep presente → quasi certamente carta EMV (bancomat/credito/debito)
        IsoDep isoDep = IsoDep.get(tag);
        if (isoDep != null) {
            tvStatus.setText("Carta contactless rilevata — lettura in corso...");
            new ReadEMVTask(tag, isoDep).execute();
            return;
        }

        // Tag NFC normale → prodotto
        String uid  = bytesToHex(tag.getId());
        String tech = tag.getTechList().length > 0
            ? tag.getTechList()[0].replace("android.nfc.tech.", "")
            : "NFC";
        tvLastScan.setText("TAG PRODOTTO\nUID: " + uid + "\nTipo: " + tech);
        tvStatus.setText("Tag prodotto rilevato — invio...");
        sendToServer(uid, tech, "product_tag", null);
    }

    // ── Lettura EMV (background) ──────────────────────────────────
    private class ReadEMVTask extends AsyncTask<Void, Void, String[]> {
        private final Tag tag;
        private final IsoDep isoDep;
        ReadEMVTask(Tag tag, IsoDep isoDep) { this.tag = tag; this.isoDep = isoDep; }

        @Override
        protected String[] doInBackground(Void... v) {
            String uid   = bytesToHex(tag.getId());
            String brand = "Contactless";
            try {
                isoDep.connect();
                isoDep.setTimeout(3000);
                // Seleziona PPSE per leggere i brand disponibili
                byte[] ppseResp = isoDep.transceive(new byte[]{
                    0x00, (byte)0xA4, 0x04, 0x00, 0x0E,
                    '2','P','A','Y','.','S','Y','S','.','D','D','F','0','1', 0x00
                });
                brand = detectBrandFromPPSE(bytesToHex(ppseResp).toUpperCase());
            } catch (Exception ignored) {
                // carta non standard o protetta — rimane "Contactless"
            } finally {
                try { isoDep.close(); } catch (Exception ignored2) {}
            }
            return new String[]{ uid, brand };
        }

        @Override
        protected void onPostExecute(String[] res) {
            String uid = res[0], brand = res[1];
            tvLastScan.setText("CARTA PAGAMENTO\nBrand: " + brand + "\nUID: " + uid);
            tvStatus.setText("Carta " + brand + " rilevata — invio al gestionale...");
            sendToServer(uid, "EMV", "payment_card", brand);
        }

        private String detectBrandFromPPSE(String hex) {
            // AID standard — controllati nell'ordine di priorità
            if (hex.contains("A0000000031010")) return "Visa";
            if (hex.contains("A0000000032010")) return "Visa Electron";
            if (hex.contains("A0000000033010")) return "Visa V Pay";
            if (hex.contains("A0000000041010")) return "Mastercard";
            if (hex.contains("A0000000043060")) return "Maestro";
            if (hex.contains("A000000025010801")) return "AmEx";
            if (hex.contains("A0000003591010")) return "Discover";
            if (hex.contains("A000000141010201")) return "PagoBANCOMAT";
            if (hex.contains("A000000141")) return "Bancomat";
            if (hex.contains("A00000002401")) return "UnionPay";
            return "Contactless";
        }
    }

    // ── HTTP POST → GesClo ───────────────────────────────────────
    private void sendToServer(String uid, String type, String source, String cardBrand) {
        String serverIp = prefs.getString("server_ip", "").trim();
        String apiKey   = prefs.getString("api_key",   "").trim();
        if (serverIp.isEmpty()) {
            tvStatus.setText("⚠ Configura l'IP del server GesClo");
            return;
        }
        new SendTask(serverIp, apiKey, uid, type, source, cardBrand).execute();
    }

    private class SendTask extends AsyncTask<Void, Void, String> {
        private final String serverIp, apiKey, uid, type, source, cardBrand;
        SendTask(String serverIp, String apiKey, String uid, String type, String source, String cardBrand) {
            this.serverIp  = serverIp; this.apiKey    = apiKey;
            this.uid       = uid;      this.type      = type;
            this.source    = source;   this.cardBrand = cardBrand != null ? cardBrand : "";
        }

        @Override
        protected String doInBackground(Void... v) {
            try {
                String body = "{"
                    + "\"uid\":\""       + esc(uid)       + "\","
                    + "\"type\":\""      + esc(type)      + "\","
                    + "\"source\":\""    + esc(source)    + "\","
                    + "\"cardBrand\":\"" + esc(cardBrand) + "\","
                    + "\"key\":\""       + esc(apiKey)    + "\""
                    + "}";

                URL url = new URL("http://" + serverIp + ":3001/api/nfc/scan");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("X-NFC-Key",    apiKey);
                c.setDoOutput(true);
                c.setConnectTimeout(4000);
                c.setReadTimeout(4000);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                if (code != 200) return "ERR:HTTP " + code;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) sb.append(line);
                }
                return "OK:" + sb;
            } catch (Exception e) { return "ERR:" + e.getMessage(); }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result.startsWith("OK:")) {
                if ("payment_card".equals(source)) {
                    tvStatus.setText("✓ Carta " + cardBrand + " inviata al gestionale");
                } else {
                    boolean found = result.contains("\"product\":{");
                    tvStatus.setText(found
                        ? "✓ Articolo trovato! Controlla il gestionale."
                        : "✓ Tag inviato (articolo non trovato nel magazzino)");
                }
            } else {
                tvStatus.setText("✗ Errore: " + result.substring(4));
            }
        }

        private String esc(String s) {
            return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
        }
    }

    // ── Utils ─────────────────────────────────────────────────────
    @SuppressWarnings("deprecation")
    private String getWifiIp() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null) return "N/D";
            int ip = wm.getConnectionInfo().getIpAddress();
            if (ip == 0) return "non connesso al WiFi";
            // Android usa little-endian su alcuni dispositivi
            if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
                ip = Integer.reverseBytes(ip);
            }
            return InetAddress.getByAddress(new byte[]{
                (byte)(ip >> 24), (byte)(ip >> 16), (byte)(ip >> 8), (byte)ip
            }).getHostAddress();
        } catch (Exception e) { return "N/D"; }
    }

    private void updateStatus() {
        if (nfcAdapter == null) return;
        tvStatus.setText(nfcAdapter.isEnabled()
            ? "Pronto — avvicina un tag prodotto o una carta contactless"
            : "⚠ Attiva NFC nelle impostazioni del telefono");
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02X", b));
        return sb.toString();
    }
}
