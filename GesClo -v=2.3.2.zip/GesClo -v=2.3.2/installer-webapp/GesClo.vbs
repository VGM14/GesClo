Option Explicit
' Avvia il server GesClo in background (nessuna finestra) e apre l'interfaccia nel browser.
Dim sh, fso, root, i
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)

Function ServerUp()
  Dim h
  On Error Resume Next
  Set h = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  h.setTimeouts 500, 500, 500, 500
  h.open "GET", "http://127.0.0.1:3001/health", False
  h.send
  ServerUp = (Err.Number = 0 And h.status = 200)
  On Error GoTo 0
End Function

If Not ServerUp() Then
  sh.CurrentDirectory = root & "\server"
  sh.Run """" & root & "\runtime\node.exe"" server.js", 0, False
  For i = 1 To 40
    WScript.Sleep 300
    If ServerUp() Then Exit For
  Next
End If

sh.Run "http://localhost:3001", 1, False
