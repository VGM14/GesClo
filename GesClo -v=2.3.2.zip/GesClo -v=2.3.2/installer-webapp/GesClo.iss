﻿; GesClo — Inno Setup script (web app: Node server + React interface served on :3001)
; Bilingual installer (Italian / English): Setup asks for the language when it starts.
; Before compiling run build-installer.bat: it prepares the "staging" folder.

#define AppName    "GesClo"
#define AppVersion "2.3.2"

[Setup]
AppId={{7B3E2C1A-5D4F-4A86-9C21-0A6E5C3D9F01}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=GesClo
DefaultDirName={localappdata}\GesClo
DefaultGroupName=GesClo
PrivilegesRequired=lowest
DisableProgramGroupPage=yes
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
SetupIconFile=staging\GesClo.ico
UninstallDisplayIcon={app}\GesClo.ico
OutputDir=output
OutputBaseFilename=GesClo-Setup-{#AppVersion}
; Language dialog: shown at start, preselecting the language of Windows
ShowLanguageDialog=yes
UsePreviousLanguage=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "italian"; MessagesFile: "compiler:Languages\Italian.isl"

[CustomMessages]
english.DesktopIcon=Create a shortcut on the Desktop
english.Shortcuts=Shortcuts:
english.StopGesClo=Stop GesClo
english.LaunchGesClo=Launch GesClo
english.DeleteData=Do you also want to delete the GesClo data (items, sales, users)?%n%nChoose "No" to keep it: a future reinstall will find it again.
italian.DesktopIcon=Crea un collegamento sul Desktop
italian.Shortcuts=Collegamenti:
italian.StopGesClo=Ferma GesClo
italian.LaunchGesClo=Avvia GesClo
italian.DeleteData=Vuoi eliminare anche i dati di GesClo (articoli, vendite, utenti)?%n%nScegli "No" per conservarli: una futura reinstallazione li ritroverà.

[Tasks]
Name: "desktopicon"; Description: "{cm:DesktopIcon}"; GroupDescription: "{cm:Shortcuts}"

[Files]
Source: "staging\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\GesClo\GesClo"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\GesClo.vbs"""; IconFilename: "{app}\GesClo.ico"; WorkingDir: "{app}"
Name: "{autoprograms}\GesClo\{cm:StopGesClo}"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\GesClo-Ferma.vbs"""; IconFilename: "{app}\GesClo.ico"; WorkingDir: "{app}"
Name: "{autodesktop}\GesClo"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\GesClo.vbs"""; IconFilename: "{app}\GesClo.ico"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{sys}\wscript.exe"; Parameters: """{app}\GesClo.vbs"""; Description: "{cm:LaunchGesClo}"; Flags: postinstall nowait skipifsilent

[UninstallRun]
Filename: "{sys}\wscript.exe"; Parameters: """{app}\GesClo-Ferma.vbs"""; RunOnceId: "StopGesClo"; Flags: runhidden

[Code]
// If GesClo is running (update over an existing install) it must be stopped,
// otherwise the node.exe files are in use and cannot be replaced.
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  ResultCode: Integer;
  StopScript: String;
begin
  StopScript := ExpandConstant('{app}\GesClo-Ferma.vbs');
  if FileExists(StopScript) then
    Exec(ExpandConstant('{sys}\wscript.exe'), '"' + StopScript + '"', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  Result := '';
end;

// The database (gesclo.sqlite) is created by the server on first launch and is not part of
// the package: an update never touches it. On uninstall we ask what to do with it;
// if it stays, a reinstall finds users and data again (and skips the admin creation screen).
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
    if FileExists(ExpandConstant('{app}\gesclo.sqlite')) then
      if MsgBox(ExpandConstant('{cm:DeleteData}'), mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
        DeleteFile(ExpandConstant('{app}\gesclo.sqlite'));
end;
