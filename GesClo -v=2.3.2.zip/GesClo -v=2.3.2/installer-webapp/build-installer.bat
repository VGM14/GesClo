@echo off
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0.."

echo [1/4] Build del frontend...
pushd "%ROOT%\frontend"
call npm run build || goto :err
popd

echo [2/4] Preparazione cartella staging...
if exist staging rmdir /s /q staging
mkdir staging\server staging\frontend staging\runtime
copy /y "%ROOT%\server\server.js"         staging\server\ >nul
copy /y "%ROOT%\server\db.js"             staging\server\ >nul
copy /y "%ROOT%\server\i18n.js"           staging\server\ >nul
copy /y "%ROOT%\server\package.json"      staging\server\ >nul
copy /y "%ROOT%\server\package-lock.json" staging\server\ >nul
> staging\server\.env echo PORT=3001
xcopy /e /i /q /y "%ROOT%\frontend\dist" staging\frontend\dist >nul
copy /y GesClo.vbs        staging\ >nul
copy /y GesClo-Ferma.vbs  staging\ >nul
copy /y "%ROOT%\GesClo.ico" staging\ >nul

echo [3/4] Dipendenze del server (solo produzione) e runtime Node...
pushd staging\server
call npm ci --omit=dev || goto :err
popd
for /f "delims=" %%i in ('node -p "process.execPath"') do copy /y "%%i" staging\runtime\node.exe >nul

echo [4/4] Compilazione installer con Inno Setup...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup non trovato: la cartella staging e' pronta, compila GesClo.iss a mano.
  goto :err
)
"%ISCC%" GesClo.iss || goto :err

echo.
echo FATTO: l'installer e' nella cartella output\
exit /b 0

:err
echo.
echo ERRORE: build interrotta.
exit /b 1
