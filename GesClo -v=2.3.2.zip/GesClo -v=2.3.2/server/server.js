require('dotenv').config()

const express            = require('express')
const http               = require('http')
const cors               = require('cors')
const os                 = require('os')
const path               = require('path')
const crypto             = require('crypto')
const { spawn }          = require('child_process')
const { WebSocketServer } = require('ws')
const { initDatabase, getDb, kvGet, kvSet, exportDatabase, replaceDatabase } = require('./db')
const { langMiddleware } = require('./i18n')

const app  = express()
const PORT = process.env.PORT || 3001

// ── DATABASE (SQLite via sql.js) ───────────────────────────────
const DB_FILE = path.join(__dirname, '..', 'gesclo.sqlite')
// Percorsi dei vecchi file JSON, usati solo per l'importazione automatica una tantum
// al primo avvio dopo l'aggiornamento (se gesclo.sqlite non esiste ancora).
const LEGACY_DB_JSON   = path.join(__dirname, '..', 'gesclo.db.json')
const LEGACY_SUPP_JSON = path.join(__dirname, '..', 'gesclo.supplement.json')

// Chiavi riservate in settings_kv, non esposte da GET /api/settings (generiche).
const RESERVED_KV_KEYS = new Set(['_ai_config', '_ui_config', '_cash_register', '_sale_counter'])

app.use(cors())
app.use(express.json())
app.use(langMiddleware) // "X-Lang: en" → messaggi d'errore in inglese (vedi i18n.js)

// ── AUTH LOCALE ───────────────────────────────────────────────
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex')
  const hash = crypto.scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}
function verifyPassword(password, stored) {
  const [salt, hash] = (stored || '').split(':')
  if (!salt || !hash) return false
  const check = crypto.scryptSync(password, salt, 64)
  const ref   = Buffer.from(hash, 'hex')
  return check.length === ref.length && crypto.timingSafeEqual(check, ref)
}

// Sessioni in memoria: token opaco → { userId, role }. Non sopravvivono al riavvio del server.
const sessions = new Map()

// ── PRIMO AVVIO: creazione dell'account amministratore ────────
// Nessun utente di default: finché la tabella users è vuota l'interfaccia mostra la
// schermata di creazione dell'admin. Appena esiste un utente l'endpoint si chiude.
function countUsers() {
  return getDb().prepare('SELECT COUNT(*) AS count FROM users').get().count
}

app.get('/api/setup/status', (req, res) => {
  res.json({ needsSetup: countUsers() === 0 })
})

app.post('/api/setup', (req, res) => {
  if (countUsers() > 0) return res.status(403).json({ error: 'Configurazione già completata' })
  const { username, email, password } = req.body || {}
  if (!username || !String(username).trim()) return res.status(400).json({ error: 'Username obbligatorio' })
  if (!password || password.length < 8)       return res.status(400).json({ error: 'Password minimo 8 caratteri' })

  const user = { id: crypto.randomUUID(), username: String(username).trim(), email: email || '', role: 'Super Admin' }
  getDb().prepare('INSERT INTO users (id,username,email,password,role) VALUES (?,?,?,?,?)')
    .run(user.id, user.username, user.email, hashPassword(password), user.role)

  // Installazione nuova: gli endpoint POS/NFC nascono già protetti da una chiave casuale
  // (visibile in Admin → Hardware, da inserire nelle app Android). Un database esistente
  // senza chiave non viene toccato, per non spezzare app già configurate.
  if (!String(kvGet('nfc_api_key', '') || '').trim()) kvSet('nfc_api_key', crypto.randomBytes(16).toString('hex'))

  const token = crypto.randomBytes(32).toString('hex')
  sessions.set(token, { id: user.id, role: user.role })
  res.json({ token, username: user.username, role: user.role })
})

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {}
  if (!username || !password) return res.status(400).json({ error: 'Username e password richiesti' })
  const db = getDb()
  const user = db.prepare('SELECT * FROM users WHERE LOWER(username) = ?').get(String(username).toLowerCase())
  if (!user || !verifyPassword(password, user.password))
    return res.status(401).json({ error: 'Credenziali non valide' })

  const token = crypto.randomBytes(32).toString('hex')
  sessions.set(token, { id: user.id, role: user.role })
  res.json({ token, username: user.username, role: user.role })
})

function authMiddleware(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '')
  const session = token && sessions.get(token)
  if (!session) return res.status(401).json({ error: 'Non autorizzato' })
  req.user  = session
  req.token = token
  next()
}

app.post('/api/logout', authMiddleware, (req, res) => {
  sessions.delete(req.token)
  res.json({ ok: true })
})

function requireAdmin(req, res) {
  if (!['Super Admin', 'Admin'].includes(req.user.role)) {
    res.status(403).json({ error: 'Accesso riservato agli amministratori' })
    return false
  }
  return true
}

// ── HEALTH (no auth) ─────────────────────────────────────────
app.get('/health', (req, res) => {
  const db = getDb()
  const count = (table) => db.prepare(`SELECT COUNT(*) AS c FROM ${table}`).get().c
  res.json({
    ok:      true,
    version: '2.3.2',
    uptime:  Math.floor(process.uptime()),
    db: {
      products:  count('products'),
      customers: count('customers'),
      movements: count('movements'),
      sales:     count('sales'),
    }
  })
})

// ── MODALITÀ OPERATIVA (Standalone / Network Server / Network Terminal) ──────
// Nessuna autenticazione: serve anche a un client che non si è ancora loggato,
// per sapere che indirizzo dare ad altri terminali (modalità Server).
function getLanIp() {
  const nets = os.networkInterfaces()
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) return net.address
    }
  }
  return '127.0.0.1'
}

app.get('/api/system/network-info', (req, res) => {
  res.json({ lanIp: getLanIp(), port: Number(PORT) })
})

// ── RISORSE DEL SERVER (barra "Risorse dispositivo" in basso) ───────────────
// La CPU si misura confrontando i contatori di os.cpus() tra due istanti: un campionatore
// in background la aggiorna ogni 2 secondi, così la risposta è sempre immediata.
function cpuTimes() {
  let idle = 0, total = 0
  for (const c of os.cpus()) {
    for (const t of Object.values(c.times)) total += t
    idle += c.times.idle
  }
  return { idle, total }
}
let lastCpu = cpuTimes(), cpuPercent = 0
setInterval(() => {
  const now = cpuTimes()
  const dTotal = now.total - lastCpu.total, dIdle = now.idle - lastCpu.idle
  if (dTotal > 0) cpuPercent = Math.max(0, Math.min(100, Math.round((1 - dIdle / dTotal) * 100)))
  lastCpu = now
}, 2000).unref()

const gb = (bytes) => (bytes / 1024 ** 3).toFixed(1)

app.get('/api/system/resources', authMiddleware, async (req, res) => {
  const totalMem = os.totalmem(), usedMem = totalMem - os.freemem()
  const out = {
    cpu: cpuPercent,
    ram: Math.round((usedMem / totalMem) * 100),
    ramLabel: `${gb(usedMem)} / ${gb(totalMem)} GB`,
    disk: null, diskLabel: null
  }
  // Spazio usato sul disco dove si trova il database (statfs: Node 18.15+)
  try {
    const st = await require('fs').promises.statfs(path.parse(DB_FILE).root)
    const total = st.blocks * st.bsize, used = total - st.bavail * st.bsize
    if (total > 0) { out.disk = Math.round((used / total) * 100); out.diskLabel = `${gb(used)} / ${gb(total)} GB` }
  } catch {}
  res.json(out)
})

// ── PROFILO UTENTE ────────────────────────────────────────────
app.get('/api/me', authMiddleware, (req, res) => {
  const u = getDb().prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  if (!u) return res.status(404).json({ error: 'Utente non trovato' })
  res.json({ id: u.id, role: u.role, name: u.username, email: u.email || '' })
})

// ── PRODOTTI ──────────────────────────────────────────────────
// Un articolo con varianti (taglia/colore) non tiene la giacenza su se stesso: la sua
// products.qty viene tenuta sincronizzata come somma delle varianti a ogni modifica, così
// tutto il resto dell'app (report, riordino, export) continua a leggere products.qty
// normalmente senza sapere nulla delle varianti.
function syncVariantQty(db, productId) {
  const row = db.prepare('SELECT COALESCE(SUM(qty),0) AS total FROM product_variants WHERE product_id = ?').get(productId)
  db.prepare('UPDATE products SET qty = ? WHERE id = ?').run(row.total, productId)
  return row.total
}
function hasVariants(db, productId) {
  return db.prepare('SELECT COUNT(*) AS c FROM product_variants WHERE product_id = ?').get(productId).c > 0
}
function variantLabel(v) {
  return [v.size, v.color].filter(s => s && String(s).trim()).join(' / ')
}
// Applica una variazione di giacenza (positiva = carico, negativa = scarico) alla variante
// se indicata, altrimenti all'articolo semplice. Non va mai sotto zero.
function applyStockDelta(db, productId, variantId, delta) {
  if (variantId) {
    const v = db.prepare('SELECT * FROM product_variants WHERE id = ? AND product_id = ?').get(variantId, productId)
    if (v) {
      db.prepare('UPDATE product_variants SET qty = ? WHERE id = ?').run(Math.max(0, v.qty + delta), v.id)
      syncVariantQty(db, productId)
      return
    }
  }
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(productId)
  if (p) db.prepare('UPDATE products SET qty = ? WHERE id = ?').run(Math.max(0, p.qty + delta), productId)
}

// ── CODICI A BARRE MULTIPLI ──────────────────────────────────────
// Un articolo può avere più codici a barre (confezioni, fornitori o lotti diversi). Il primo
// resta in products.barcode (così export, ricerche e import continuano a funzionare come
// prima); gli altri stanno in product_barcodes. Un codice appartiene a un solo articolo.
function cleanBarcodes(list) {
  const out = []
  for (const b of Array.isArray(list) ? list : []) {
    const s = String(b ?? '').trim()
    if (s && !out.includes(s)) out.push(s)
  }
  return out
}
function allBarcodes(db, product) {
  const extra = db.prepare('SELECT barcode FROM product_barcodes WHERE product_id = ? ORDER BY rowid').all(product.id).map(r => r.barcode)
  return cleanBarcodes([product.barcode, ...extra])
}
// Messaggio d'errore se uno dei codici è già assegnato a un altro articolo, altrimenti null.
function barcodeConflict(db, productId, list) {
  for (const code of list) {
    const owner = db.prepare('SELECT id, name FROM products WHERE barcode = ? AND id != ?').get(code, productId || '')
      || db.prepare('SELECT p.id, p.name FROM product_barcodes b JOIN products p ON p.id = b.product_id WHERE b.barcode = ? AND b.product_id != ?').get(code, productId || '')
    if (owner) return `Il codice a barre "${code}" è già assegnato all'articolo "${owner.name}"`
  }
  return null
}
function saveExtraBarcodes(db, productId, list) {
  db.prepare('DELETE FROM product_barcodes WHERE product_id = ?').run(productId)
  for (const code of list.slice(1)) db.prepare('INSERT OR REPLACE INTO product_barcodes (barcode,product_id) VALUES (?,?)').run(code, productId)
}

app.get('/api/products', authMiddleware, (req, res) => {
  const db = getDb()
  const products = db.prepare('SELECT * FROM products ORDER BY name').all()
  const variants = db.prepare('SELECT * FROM product_variants ORDER BY size, color').all()
  const byProduct = {}
  for (const v of variants) (byProduct[v.product_id] = byProduct[v.product_id] || []).push(v)
  const extras = {}
  for (const r of db.prepare('SELECT barcode, product_id FROM product_barcodes ORDER BY rowid').all()) (extras[r.product_id] = extras[r.product_id] || []).push(r.barcode)
  res.json(products.map(p => ({ ...p, barcodes: cleanBarcodes([p.barcode, ...(extras[p.id] || [])]), variants: byProduct[p.id] || [] })))
})

// ── VARIANTI (taglia/colore) ────────────────────────────────────
app.post('/api/products/:id/variants', authMiddleware, (req, res) => {
  const db = getDb()
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id)
  if (!product) return res.status(404).json({ error: 'Articolo non trovato' })
  const size = String(req.body.size || '').trim(), color = String(req.body.color || '').trim()
  if (!size && !color) return res.status(400).json({ error: 'Indica almeno la taglia o il colore' })
  const v = {
    id: crypto.randomUUID(), product_id: product.id, size, color,
    barcode: String(req.body.barcode || '').trim(), qty: intOrNull(req.body.qty) ?? 0,
    created_at: new Date().toISOString()
  }
  db.prepare('INSERT INTO product_variants (id,product_id,size,color,barcode,qty,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(v.id, v.product_id, v.size, v.color, v.barcode, v.qty, v.created_at)
  syncVariantQty(db, product.id)
  res.json(v)
})

app.put('/api/products/:id/variants/:vid', authMiddleware, (req, res) => {
  const db = getDb()
  const existing = db.prepare('SELECT * FROM product_variants WHERE id = ? AND product_id = ?').get(req.params.vid, req.params.id)
  if (!existing) return res.status(404).json({ error: 'Variante non trovata' })
  const merged = {
    size:    req.body.size    !== undefined ? String(req.body.size).trim()    : existing.size,
    color:   req.body.color   !== undefined ? String(req.body.color).trim()   : existing.color,
    barcode: req.body.barcode !== undefined ? String(req.body.barcode).trim() : existing.barcode,
    qty:     req.body.qty     !== undefined ? (intOrNull(req.body.qty) ?? existing.qty) : existing.qty,
  }
  if (!merged.size && !merged.color) return res.status(400).json({ error: 'Indica almeno la taglia o il colore' })
  db.prepare('UPDATE product_variants SET size=?,color=?,barcode=?,qty=? WHERE id=?')
    .run(merged.size, merged.color, merged.barcode, merged.qty, req.params.vid)
  syncVariantQty(db, req.params.id)
  res.json({ id: req.params.vid, product_id: req.params.id, ...merged })
})

app.delete('/api/products/:id/variants/:vid', authMiddleware, (req, res) => {
  const db = getDb()
  db.prepare('DELETE FROM product_variants WHERE id = ? AND product_id = ?').run(req.params.vid, req.params.id)
  syncVariantQty(db, req.params.id)
  res.json({ ok: true })
})

// Numero >= 0 oppure null (campo vuoto/non valido). Usato per il costo d'acquisto, dove
// "non impostato" (null) è diverso da "costo zero".
function numOrNull(v) {
  if (v === undefined || v === null || v === '') return null
  const n = Number(v)
  return Number.isFinite(n) && n >= 0 ? n : null
}

// Intero >= 0 oppure null.
function intOrNull(v) {
  if (v === undefined || v === null || v === '') return null
  const n = Number(v)
  return Number.isInteger(n) && n >= 0 ? n : null
}

app.post('/api/products', authMiddleware, (req, res) => {
  const { name, barcode, nfc_uid, qty, unit, category, notes, price, cost } = req.body
  if (!name) return res.status(400).json({ error: 'Nome obbligatorio' })
  const codes = cleanBarcodes(Array.isArray(req.body.barcodes) ? req.body.barcodes : [barcode])
  const conflict = barcodeConflict(getDb(), null, codes)
  if (conflict) return res.status(400).json({ error: conflict })
  const product = {
    id:         crypto.randomUUID(),
    name,
    barcode:    codes[0] || '',
    nfc_uid:    nfc_uid  || null,
    qty:        parseInt(qty)    || 0,
    unit:       unit     || 'pz',
    category:   category || '',
    notes:      notes    || '',
    price:      parseFloat(price) || 0,
    cost:       numOrNull(cost),
    min_stock:   intOrNull(req.body.min_stock),
    reorder_qty: intOrNull(req.body.reorder_qty),
    supplier_id: req.body.supplier_id || null,
    created_at: new Date().toISOString()
  }
  getDb().prepare('INSERT INTO products (id,name,barcode,nfc_uid,qty,unit,price,cost,min_stock,reorder_qty,supplier_id,category,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(product.id, product.name, product.barcode, product.nfc_uid, product.qty, product.unit, product.price, product.cost, product.min_stock, product.reorder_qty, product.supplier_id, product.category, product.notes, product.created_at)
  saveExtraBarcodes(getDb(), product.id, codes)
  res.json({ ...product, barcodes: codes })
})

app.put('/api/products/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id)
  if (!existing) return res.status(404).json({ error: 'Prodotto non trovato' })
  const merged = { ...existing, ...req.body, id: req.params.id }
  merged.cost        = 'cost'        in req.body ? numOrNull(req.body.cost)         : existing.cost
  merged.min_stock   = 'min_stock'   in req.body ? intOrNull(req.body.min_stock)    : existing.min_stock
  merged.reorder_qty = 'reorder_qty' in req.body ? intOrNull(req.body.reorder_qty)  : existing.reorder_qty
  merged.supplier_id = 'supplier_id' in req.body ? (req.body.supplier_id || null)   : existing.supplier_id
  // Se l'articolo ha varianti la giacenza è la somma delle varianti: un valore inviato qui
  // verrebbe subito risincronizzato, quindi si ignora per evitare di confondere chi lo manda.
  if (hasVariants(db, req.params.id)) merged.qty = existing.qty
  // Codici a barre: si controllano solo quelli nuovi per questo articolo (eventuali doppioni
  // già presenti da prima non bloccano il salvataggio di altre modifiche).
  let codes = null
  if (Array.isArray(req.body.barcodes)) {
    codes = cleanBarcodes(req.body.barcodes)
    const own = new Set(allBarcodes(db, existing))
    const conflict = barcodeConflict(db, existing.id, codes.filter(c => !own.has(c)))
    if (conflict) return res.status(400).json({ error: conflict })
    merged.barcode = codes[0] || ''
  }
  db.prepare('UPDATE products SET name=?,barcode=?,nfc_uid=?,qty=?,unit=?,price=?,cost=?,min_stock=?,reorder_qty=?,supplier_id=?,category=?,notes=? WHERE id=?')
    .run(merged.name, merged.barcode, merged.nfc_uid, merged.qty, merged.unit, merged.price, merged.cost, merged.min_stock, merged.reorder_qty, merged.supplier_id, merged.category, merged.notes, req.params.id)
  if (codes) saveExtraBarcodes(db, req.params.id, codes)
  merged.barcodes = codes || allBarcodes(db, merged)
  res.json(merged)
})

app.delete('/api/products/:id', authMiddleware, (req, res) => {
  const db = getDb()
  db.prepare('DELETE FROM product_barcodes WHERE product_id = ?').run(req.params.id)
  db.prepare('DELETE FROM product_variants WHERE product_id = ?').run(req.params.id)
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// Cerca prima tra i barcode delle varianti (scansionando l'etichetta di una taglia/colore
// specifica), poi tra quelli dell'articolo semplice.
app.get('/api/products/barcode/:barcode', authMiddleware, (req, res) => {
  const db = getDb()
  const variant = db.prepare('SELECT * FROM product_variants WHERE barcode = ?').get(req.params.barcode)
  if (variant) {
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(variant.product_id)
    if (product) return res.json({ ...product, matched_variant: variant })
  }
  const p = db.prepare('SELECT * FROM products WHERE barcode = ?').get(req.params.barcode)
    || db.prepare('SELECT p.* FROM product_barcodes b JOIN products p ON p.id = b.product_id WHERE b.barcode = ?').get(req.params.barcode)
  if (!p) return res.status(404).json({ error: 'Prodotto non trovato' })
  res.json({ ...p, barcodes: allBarcodes(db, p) })
})

// ── MOVIMENTI ─────────────────────────────────────────────────
app.get('/api/movements', authMiddleware, (req, res) => {
  res.json(getDb().prepare('SELECT * FROM movements ORDER BY created_at DESC LIMIT 100').all())
})

app.post('/api/movements', authMiddleware, (req, res) => {
  const { product_id, product_name, variant_id, type, qty, notes } = req.body
  const qtyNum = parseInt(qty) || 0
  const db = getDb()

  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(product_id)
  const variant = product && variant_id ? db.prepare('SELECT * FROM product_variants WHERE id = ? AND product_id = ?').get(variant_id, product_id) : null
  if (product && hasVariants(db, product_id) && !variant)
    return res.status(400).json({ error: 'Questo articolo ha varianti: scegli la taglia/colore del movimento' })
  if (product) applyStockDelta(db, product_id, variant ? variant.id : null, type === 'entrata' ? qtyNum : -qtyNum)

  const baseName = product_name || (product ? product.name : 'Articolo sconosciuto')
  const movement = {
    id:           crypto.randomUUID(),
    product_id,
    product_name: variant ? `${baseName} (${variantLabel(variant)})` : baseName,
    type,
    qty:          qtyNum,
    notes:        notes || '',
    user:         req.user.id,
    created_at:   new Date().toISOString()
  }
  db.prepare('INSERT INTO movements (id,product_id,product_name,type,qty,notes,user,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(movement.id, movement.product_id, movement.product_name, movement.type, movement.qty, movement.notes, movement.user, movement.created_at)
  res.json(movement)
})

// ── CLIENTI ───────────────────────────────────────────────────
// L'elenco include un riepilogo dei rapporti col cliente (numero e totale delle vendite,
// data dell'ultima) ricavato dalle vendite collegate tramite customer_id.
app.get('/api/customers', authMiddleware, (req, res) => {
  res.json(getDb().prepare(`
    SELECT c.*,
      (SELECT COUNT(*)                FROM sales s WHERE s.customer_id = c.id) AS sales_count,
      (SELECT COALESCE(SUM(total), 0) FROM sales s WHERE s.customer_id = c.id) AS sales_total,
      (SELECT MAX(date)               FROM sales s WHERE s.customer_id = c.id) AS last_sale
    FROM customers c ORDER BY c.name`).all())
})

app.post('/api/customers', authMiddleware, (req, res) => {
  const { name, vat_number, email, phone, address, notes } = req.body
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'Nome obbligatorio' })
  const customer = {
    id: crypto.randomUUID(), name: String(name).trim(), vat_number: vat_number || '',
    email: email || '', phone: phone || '', address: address || '', notes: notes || '',
    created_at: new Date().toISOString()
  }
  getDb().prepare('INSERT INTO customers (id,name,vat_number,email,phone,address,notes,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(customer.id, customer.name, customer.vat_number, customer.email, customer.phone, customer.address, customer.notes, customer.created_at)
  res.json(customer)
})

app.put('/api/customers/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const existing = db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id)
  if (!existing) return res.status(404).json({ error: 'Cliente non trovato' })
  const merged = { ...existing, ...req.body, id: req.params.id }
  if (!merged.name || !String(merged.name).trim()) return res.status(400).json({ error: 'Nome obbligatorio' })
  db.prepare('UPDATE customers SET name=?,vat_number=?,email=?,phone=?,address=?,notes=? WHERE id=?')
    .run(String(merged.name).trim(), merged.vat_number, merged.email, merged.phone, merged.address, merged.notes, req.params.id)
  res.json(merged)
})

app.delete('/api/customers/:id', authMiddleware, (req, res) => {
  getDb().prepare('DELETE FROM customers WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// ── VENDITE ───────────────────────────────────────────────────
function mapSaleRow(row) {
  return { ...row, items: JSON.parse(row.items_json || '[]') }
}

app.get('/api/sales', authMiddleware, (req, res) => {
  const rows = getDb().prepare('SELECT * FROM sales ORDER BY created_at DESC LIMIT 100').all()
  res.json(rows.map(mapSaleRow))
})

app.delete('/api/sales', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const db = getDb()
  db.exec('DELETE FROM sales')
  db.exec('DELETE FROM returns')
  db.exec("DELETE FROM dues WHERE ref_type = 'sale'")
  kvSet('_sale_counter', 0)
  res.json({ ok: true })
})

function insertSale(db, fields) {
  const counter = (kvGet('_sale_counter', 0) || 0) + 1
  kvSet('_sale_counter', counter)
  const sale = {
    id: crypto.randomUUID(), number: counter,
    date: new Date().toISOString().split('T')[0],
    customer_id: fields.customer_id || '', customer_name: fields.customer_name || 'Cliente generico',
    items: fields.items || [], subtotal: fields.subtotal || 0, discount: fields.discount || 0,
    tax: fields.tax || 0, total: fields.total || 0, payment_method: fields.payment_method || 'contanti',
    payment_other: fields.payment_other || '', notes: fields.notes || '',
    user: fields.user || 'system', created_at: new Date().toISOString(), quote_id: fields.quote_id || null
  }
  db.prepare(`INSERT INTO sales (id,number,date,customer_id,customer_name,items_json,subtotal,discount,tax,total,payment_method,payment_other,notes,user,created_at,quote_id)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(sale.id, sale.number, sale.date, sale.customer_id, sale.customer_name, JSON.stringify(sale.items),
         sale.subtotal, sale.discount, sale.tax, sale.total, sale.payment_method, sale.payment_other, sale.notes, sale.user, sale.created_at, sale.quote_id)
  return sale
}

// Ogni riga di vendita/preventivo con un articolo che ha varianti deve indicare quale
// (taglia/colore): completa la riga con l'etichetta e restituisce un messaggio se non valida.
function resolveVariantLines(db, items) {
  const out = []
  for (const i of items) {
    const p = i.product_id ? db.prepare('SELECT id, name FROM products WHERE id = ?').get(i.product_id) : null
    let variant = null
    if (p) {
      if (i.variant_id) {
        variant = db.prepare('SELECT * FROM product_variants WHERE id = ? AND product_id = ?').get(i.variant_id, p.id)
        if (!variant) return { error: `Variante non trovata per "${p.name}"` }
      } else if (hasVariants(db, p.id)) {
        return { error: `"${p.name}" ha varianti: scegli taglia/colore` }
      }
    }
    out.push(variant ? { ...i, variant_id: variant.id, variant_label: variantLabel(variant) } : i)
  }
  return { items: out }
}

app.post('/api/sales', authMiddleware, (req, res) => {
  const db = getDb()
  const items = req.body.items
  if (!Array.isArray(items) || items.length === 0)
    return res.status(400).json({ error: 'La vendita non contiene articoli' })
  if (items.some(i => !(Number(i.qty) > 0) || !(Number(i.price) >= 0)))
    return res.status(400).json({ error: 'Quantità o prezzo non validi' })
  // La vendita va salvata PRIMA di scalare le quantità: se l'inserimento fallisse
  // dopo aver già decrementato lo stock, il magazzino risulterebbe scalato senza
  // una vendita corrispondente a giustificarlo.
  // Il costo d'acquisto viene "congelato" nella riga di vendita (letto dal server, non dal
  // client): così il margine di una vendita resta corretto anche se il costo cambia dopo.
  const resolved = resolveVariantLines(db, items)
  if (resolved.error) return res.status(400).json({ error: resolved.error })
  const soldItems = resolved.items.map(i => {
    const p = i.product_id ? db.prepare('SELECT cost FROM products WHERE id = ?').get(i.product_id) : null
    return { ...i, cost: p && p.cost != null ? p.cost : null }
  })
  // Vendita "a credito": serve un cliente e nasce un credito da incassare nello scadenzario.
  let creditCustomer = null
  if (req.body.payment_method === 'credito') {
    creditCustomer = req.body.customer_id ? db.prepare('SELECT id, name FROM customers WHERE id = ?').get(req.body.customer_id) : null
    if (!creditCustomer) return res.status(400).json({ error: 'Per vendere a credito scegli un cliente' })
  }
  const sale = insertSale(db, { ...req.body, items: soldItems, user: req.user.id })
  if (creditCustomer && sale.total > 0) {
    createDue(db, {
      kind: 'credito', party_type: 'customer', party_id: creditCustomer.id, party_name: creditCustomer.name,
      ref_type: 'sale', ref_id: sale.id, ref_label: `Vendita N°${sale.number}`, amount: sale.total,
      due_date: validIso(req.body.due_date) || shiftDate(new Date().toISOString().split('T')[0], 30)
    })
  }
  for (const item of soldItems) applyStockDelta(db, item.product_id, item.variant_id, -(parseInt(item.qty) || 1))
  res.json(sale)
})

app.delete('/api/sales/:id', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const db = getDb()
  const row = db.prepare('SELECT * FROM sales WHERE id = ?').get(req.params.id)
  if (row) {
    const sale = mapSaleRow(row)
    // Le quantità già rese con un reso non vanno ripristinate una seconda volta.
    const returned = {}
    for (const r of db.prepare('SELECT items_json FROM returns WHERE sale_id = ?').all(req.params.id))
      for (const it of JSON.parse(r.items_json || '[]')) { const k = `${it.product_id}|${it.variant_id || ''}`; returned[k] = (returned[k] || 0) + it.qty }
    for (const item of (sale.items || [])) {
      const k = `${item.product_id}|${item.variant_id || ''}`
      const back = Math.max(0, (parseInt(item.qty) || 1) - (returned[k] || 0))
      returned[k] = Math.max(0, (returned[k] || 0) - (parseInt(item.qty) || 1))
      if (back > 0) applyStockDelta(db, item.product_id, item.variant_id, back)
    }
    db.prepare('DELETE FROM returns WHERE sale_id = ?').run(req.params.id)
    db.prepare("DELETE FROM dues WHERE ref_type = 'sale' AND ref_id = ?").run(req.params.id)
    db.prepare('DELETE FROM sales WHERE id = ?').run(req.params.id)
  }
  res.json({ ok: true })
})

// ── FORNITORI ─────────────────────────────────────────────────
// L'elenco include il riepilogo degli acquisti dal fornitore (ordini non annullati, totale
// già ricevuto, ordini ancora aperti, data dell'ultimo ordine).
app.get('/api/suppliers', authMiddleware, (req, res) => {
  res.json(getDb().prepare(`
    SELECT s.*,
      (SELECT COUNT(*)                FROM purchase_orders o WHERE o.supplier_id = s.id AND o.status != 'annullato') AS orders_count,
      (SELECT COALESCE(SUM(total), 0) FROM purchase_orders o WHERE o.supplier_id = s.id AND o.status = 'ricevuto')  AS received_total,
      (SELECT COUNT(*)                FROM purchase_orders o WHERE o.supplier_id = s.id AND o.status IN ('bozza','ordinato')) AS open_orders,
      (SELECT MAX(date)               FROM purchase_orders o WHERE o.supplier_id = s.id AND o.status != 'annullato') AS last_order
    FROM suppliers s ORDER BY s.name`).all())
})

app.post('/api/suppliers', authMiddleware, (req, res) => {
  const { name, vat_number, email, phone, address, notes } = req.body
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'Nome obbligatorio' })
  const s = {
    id: crypto.randomUUID(), name: String(name).trim(),
    vat_number: vat_number || '', email: email || '', phone: phone || '', address: address || '', notes: notes || '',
    payment_days: intOrNull(req.body.payment_days),
    created_at: new Date().toISOString()
  }
  getDb().prepare('INSERT INTO suppliers (id,name,vat_number,email,phone,address,notes,payment_days,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(s.id, s.name, s.vat_number, s.email, s.phone, s.address, s.notes, s.payment_days, s.created_at)
  res.json(s)
})

app.put('/api/suppliers/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const existing = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(req.params.id)
  if (!existing) return res.status(404).json({ error: 'Fornitore non trovato' })
  const merged = { ...existing, ...req.body, id: req.params.id }
  if (!merged.name || !String(merged.name).trim()) return res.status(400).json({ error: 'Nome obbligatorio' })
  merged.payment_days = 'payment_days' in req.body ? intOrNull(req.body.payment_days) : existing.payment_days
  db.prepare('UPDATE suppliers SET name=?,vat_number=?,email=?,phone=?,address=?,notes=?,payment_days=? WHERE id=?')
    .run(String(merged.name).trim(), merged.vat_number, merged.email, merged.phone, merged.address, merged.notes, merged.payment_days, req.params.id)
  res.json(merged)
})

app.delete('/api/suppliers/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const open = db.prepare("SELECT COUNT(*) AS c FROM purchase_orders WHERE supplier_id = ? AND status IN ('bozza','ordinato')").get(req.params.id).c
  if (open > 0) return res.status(400).json({ error: 'Il fornitore ha ordini ancora aperti: ricevili o annullali prima di eliminarlo' })
  db.prepare('DELETE FROM suppliers WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// ── ORDINI D'ACQUISTO ─────────────────────────────────────────
// Stati: bozza → ordinato → ricevuto (carica il magazzino) oppure annullato.
const round2 = (n) => Math.round(n * 100) / 100

function mapPurchaseRow(row) {
  return { ...row, items: JSON.parse(row.items_json || '[]') }
}

// Valida le righe di un ordine e le completa con il nome reale dell'articolo dal magazzino.
function buildPurchaseItems(db, items) {
  if (!Array.isArray(items) || items.length === 0) return { error: "L'ordine non contiene articoli" }
  const out = []
  for (const i of items) {
    const qty = Number(i.qty), cost = Number(i.cost)
    const product = i.product_id ? db.prepare('SELECT id, name FROM products WHERE id = ?').get(i.product_id) : null
    if (!product) return { error: 'Articolo non trovato in magazzino' }
    if (!Number.isInteger(qty) || qty <= 0) return { error: `Quantità non valida per "${product.name}"` }
    if (!Number.isFinite(cost) || cost < 0)  return { error: `Costo non valido per "${product.name}"` }
    out.push({ product_id: product.id, name: product.name, qty, cost, subtotal: round2(qty * cost) })
  }
  return { items: out, total: round2(out.reduce((s, i) => s + i.subtotal, 0)) }
}

app.get('/api/purchase-orders', authMiddleware, (req, res) => {
  const rows = getDb().prepare('SELECT * FROM purchase_orders ORDER BY number DESC LIMIT 300').all()
  res.json(rows.map(mapPurchaseRow))
})

function createPurchaseOrder(db, supplier, built, { status, notes, userId }) {
  const number = (kvGet('_po_counter', 0) || 0) + 1
  kvSet('_po_counter', number)
  const po = {
    id: crypto.randomUUID(), number, date: new Date().toISOString().split('T')[0],
    supplier_id: supplier.id, supplier_name: supplier.name,
    status: status === 'ordinato' ? 'ordinato' : 'bozza',
    items: built.items, total: built.total, notes: notes || '', user: userId,
    created_at: new Date().toISOString(), received_at: null
  }
  db.prepare(`INSERT INTO purchase_orders (id,number,date,supplier_id,supplier_name,status,items_json,total,notes,user,created_at,received_at)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(po.id, po.number, po.date, po.supplier_id, po.supplier_name, po.status, JSON.stringify(po.items), po.total, po.notes, po.user, po.created_at, null)
  return po
}

app.post('/api/purchase-orders', authMiddleware, (req, res) => {
  const db = getDb()
  const { supplier_id, notes, status } = req.body
  const supplier = supplier_id ? db.prepare('SELECT * FROM suppliers WHERE id = ?').get(supplier_id) : null
  if (!supplier) return res.status(400).json({ error: 'Scegli un fornitore' })
  const built = buildPurchaseItems(db, req.body.items)
  if (built.error) return res.status(400).json({ error: built.error })

  res.json(createPurchaseOrder(db, supplier, built, { status, notes, userId: req.user.id }))
})

app.put('/api/purchase-orders/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id)
  if (!row) return res.status(404).json({ error: 'Ordine non trovato' })
  if (!['bozza', 'ordinato'].includes(row.status)) return res.status(400).json({ error: "Un ordine ricevuto o annullato non si può modificare" })

  const supplier = req.body.supplier_id ? db.prepare('SELECT * FROM suppliers WHERE id = ?').get(req.body.supplier_id) : null
  if (!supplier) return res.status(400).json({ error: 'Scegli un fornitore' })
  const built = buildPurchaseItems(db, req.body.items)
  if (built.error) return res.status(400).json({ error: built.error })
  const status = req.body.status === 'ordinato' ? 'ordinato' : req.body.status === 'bozza' ? 'bozza' : row.status

  db.prepare('UPDATE purchase_orders SET supplier_id=?,supplier_name=?,status=?,items_json=?,total=?,notes=? WHERE id=?')
    .run(supplier.id, supplier.name, status, JSON.stringify(built.items), built.total, req.body.notes || '', req.params.id)
  res.json(mapPurchaseRow(db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id)))
})

// Carico merce: aggiorna le quantità, registra un movimento di entrata per ogni riga e
// ricalcola il costo medio ponderato dell'articolo. Tutto in un'unica transazione: o si
// applica per intero o niente, e un ordine già ricevuto non può essere ricevuto due volte.
app.post('/api/purchase-orders/:id/receive', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id)
  if (!row) return res.status(404).json({ error: 'Ordine non trovato' })
  if (!['bozza', 'ordinato'].includes(row.status)) return res.status(400).json({ error: 'Questo ordine è già stato chiuso' })
  const po = mapPurchaseRow(row)
  const noCost = po.items.find(i => !(Number(i.cost) > 0))
  if (noCost) return res.status(400).json({ error: `Inserisci il costo di "${noCost.name}" prima di ricevere l'ordine` })

  db.exec('BEGIN')
  try {
    const now = new Date().toISOString()
    for (const item of po.items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.product_id)
      if (!product) throw new Error(`L'articolo "${item.name}" non esiste più in magazzino`)
      const oldQty = Math.max(0, product.qty || 0)
      const newCost = product.cost == null || oldQty === 0
        ? item.cost
        : Math.round(((oldQty * product.cost + item.qty * item.cost) / (oldQty + item.qty)) * 10000) / 10000
      db.prepare('UPDATE products SET qty = ?, cost = ? WHERE id = ?').run(oldQty + item.qty, newCost, product.id)
      db.prepare('INSERT INTO movements (id,product_id,product_name,type,qty,notes,user,created_at) VALUES (?,?,?,?,?,?,?,?)')
        .run(crypto.randomUUID(), product.id, product.name, 'entrata', item.qty, `Ordine acquisto N°${po.number} — ${po.supplier_name}`, req.user.id, now)
    }
    db.prepare("UPDATE purchase_orders SET status = 'ricevuto', received_at = ? WHERE id = ?").run(now, po.id)
    // La merce ricevuta genera un debito verso il fornitore, con scadenza a "giorni di pagamento" (default 30).
    if (po.total > 0) {
      const sup = po.supplier_id ? db.prepare('SELECT payment_days FROM suppliers WHERE id = ?').get(po.supplier_id) : null
      createDue(db, {
        kind: 'debito', party_type: 'supplier', party_id: po.supplier_id, party_name: po.supplier_name,
        ref_type: 'purchase_order', ref_id: po.id, ref_label: `Ordine acquisto N°${po.number}`, amount: po.total,
        due_date: shiftDate(now.split('T')[0], sup && sup.payment_days != null ? sup.payment_days : 30)
      })
    }
    db.exec('COMMIT')
  } catch (e) {
    try { db.exec('ROLLBACK') } catch {}
    return res.status(400).json({ error: e.message })
  }
  res.json(mapPurchaseRow(db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(po.id)))
})

app.post('/api/purchase-orders/:id/cancel', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id)
  if (!row) return res.status(404).json({ error: 'Ordine non trovato' })
  if (row.status === 'ricevuto') return res.status(400).json({ error: 'Un ordine già ricevuto non si può annullare' })
  db.prepare("UPDATE purchase_orders SET status = 'annullato' WHERE id = ?").run(req.params.id)
  res.json({ ok: true })
})

app.delete('/api/purchase-orders/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id)
  if (!row) return res.json({ ok: true })
  if (!['bozza', 'annullato'].includes(row.status)) return res.status(400).json({ error: 'Si possono eliminare solo bozze e ordini annullati' })
  db.prepare('DELETE FROM purchase_orders WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// ── REPORT: ricavi, margini, magazzino, acquisti ──────────────
function shiftDate(iso, days) {
  const d = new Date(iso + 'T00:00:00Z')
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().split('T')[0]
}

// Il margine si calcola solo sulle righe di cui è noto il costo d'acquisto (congelato nella
// vendita). Lo sconto della vendita viene ripartito in proporzione sulle righe. Le righe
// senza costo (articoli senza costo impostato, vendite POS) finiscono in "uncoveredRevenue"
// invece di gonfiare artificialmente il margine.
function duesSummary(db) {
  const today = new Date().toISOString().split('T')[0]
  const out = { creditOpen: 0, creditOverdue: 0, debitOpen: 0, debitOverdue: 0, creditCount: 0, debitCount: 0 }
  for (const d of db.prepare('SELECT kind, amount, paid, due_date FROM dues').all()) {
    const residual = round2(d.amount - d.paid)
    if (residual <= 0.005) continue
    const k = d.kind === 'credito' ? 'credit' : 'debit'
    out[k + 'Open'] += residual
    out[k + 'Count'] += 1
    if (d.due_date < today) out[k + 'Overdue'] += residual
  }
  return out
}

app.get('/api/reports/summary', authMiddleware, (req, res) => {
  const iso   = /^\d{4}-\d{2}-\d{2}$/
  const today = new Date().toISOString().split('T')[0]
  let to   = iso.test(req.query.to || '')   ? req.query.to   : today
  let from = iso.test(req.query.from || '') ? req.query.from : shiftDate(to, -29)
  if (from > to) [from, to] = [to, from]

  const db   = getDb()
  const rows = db.prepare('SELECT * FROM sales WHERE date >= ? AND date <= ? ORDER BY date').all(from, to)

  const totals = { salesCount: rows.length, revenueGross: 0, revenueNet: 0, tax: 0, discounts: 0, cost: 0, coveredRevenue: 0, uncoveredRevenue: 0 }
  const days = {}, pay = {}, prods = {}
  for (let d = from, n = 0; d <= to && n < 400; d = shiftDate(d, 1), n++) days[d] = { date: d, sales: 0, revenue: 0, margin: 0 }

  for (const s of rows) {
    const sub = Number(s.subtotal) || 0, disc = Number(s.discount) || 0
    const factor = sub > 0 ? (sub - disc) / sub : 1
    let items = []
    try { items = JSON.parse(s.items_json || '[]') } catch {}

    totals.revenueGross += Number(s.total) || 0
    totals.revenueNet   += sub - disc
    totals.tax          += Number(s.tax) || 0
    totals.discounts    += disc

    let saleCovered = 0, saleCost = 0
    for (const it of items) {
      const qty  = Number(it.qty) || 0
      const line = Number.isFinite(Number(it.subtotal)) ? Number(it.subtotal) : qty * (Number(it.price) || 0)
      const net  = line * factor
      const known = it.cost != null && Number.isFinite(Number(it.cost))
      const key = it.product_id || `n:${it.name}`
      const p = prods[key] || (prods[key] = { product_id: it.product_id || '', name: it.name || '—', qty: 0, revenue: 0, covered: 0, cost: 0 })
      p.qty += qty; p.revenue += net
      if (known) { saleCovered += net; saleCost += Number(it.cost) * qty; p.covered += net; p.cost += Number(it.cost) * qty }
      else totals.uncoveredRevenue += net
    }
    totals.coveredRevenue += saleCovered
    totals.cost           += saleCost

    const day = days[s.date]
    if (day) { day.sales += 1; day.revenue += sub - disc; day.margin += saleCovered - saleCost }
    const m = s.payment_method === 'altro' ? (s.payment_other || 'altro') : (s.payment_method || 'n/d')
    const pp = pay[m] || (pay[m] = { method: m, count: 0, total: 0 })
    pp.count += 1; pp.total += Number(s.total) || 0
  }

  const margin = totals.coveredRevenue - totals.cost
  const products = db.prepare('SELECT qty, price, cost FROM products').all()
  const stock = { products: products.length, units: 0, costValue: 0, retailValue: 0, withoutCost: 0 }
  for (const p of products) {
    const q = Math.max(0, p.qty || 0)
    stock.units += q
    if (p.cost != null) stock.costValue += q * p.cost; else if (q > 0) stock.withoutCost += 1
    if (p.price != null) stock.retailValue += q * p.price
  }

  const received = db.prepare("SELECT total FROM purchase_orders WHERE status = 'ricevuto' AND substr(received_at,1,10) >= ? AND substr(received_at,1,10) <= ?").all(from, to)
  const open     = db.prepare("SELECT total FROM purchase_orders WHERE status IN ('bozza','ordinato')").all()

  res.json({
    range: { from, to },
    ...totals,
    margin,
    marginPct: totals.coveredRevenue > 0 ? (margin / totals.coveredRevenue) * 100 : null,
    avgTicket: rows.length ? totals.revenueGross / rows.length : 0,
    byDay: Object.values(days),
    byPayment: Object.values(pay).sort((a, b) => b.total - a.total),
    topProducts: Object.values(prods)
      .sort((a, b) => b.revenue - a.revenue).slice(0, 10)
      .map(p => ({ product_id: p.product_id, name: p.name, qty: p.qty, revenue: p.revenue,
                   margin: p.covered > 0 ? p.covered - p.cost : null,
                   marginPct: p.covered > 0 ? ((p.covered - p.cost) / p.covered) * 100 : null })),
    stock,
    dues: duesSummary(db),
    purchases: {
      receivedCount: received.length, receivedTotal: received.reduce((s, o) => s + (o.total || 0), 0),
      openCount: open.length, openTotal: open.reduce((s, o) => s + (o.total || 0), 0)
    }
  })
})

// ── RIORDINO: articoli sotto scorta minima ────────────────────
// Un articolo va riordinato quando (giacenza + merce già ordinata) <= scorta minima. La merce
// già in ordini aperti (bozza/ordinato) viene contata, così non si riordina due volte.
function computeReorder(db) {
  const onOrder = {}
  for (const o of db.prepare("SELECT items_json FROM purchase_orders WHERE status IN ('bozza','ordinato')").all()) {
    let items = []
    try { items = JSON.parse(o.items_json || '[]') } catch {}
    for (const i of items) onOrder[i.product_id] = (onOrder[i.product_id] || 0) + (Number(i.qty) || 0)
  }
  const suppliers = {}
  for (const sp of db.prepare('SELECT id, name FROM suppliers').all()) suppliers[sp.id] = sp.name

  return db.prepare('SELECT * FROM products WHERE min_stock IS NOT NULL AND min_stock > 0 ORDER BY name').all()
    .map(p => {
      const qty = Math.max(0, p.qty || 0), incoming = onOrder[p.id] || 0
      const suggested = p.reorder_qty > 0 ? p.reorder_qty : Math.max(p.min_stock * 2 - qty - incoming, 1)
      return {
        product_id: p.id, name: p.name, barcode: p.barcode || '', unit: p.unit || 'pz',
        qty, min_stock: p.min_stock, on_order: incoming, suggested,
        cost: p.cost, supplier_id: suppliers[p.supplier_id] ? p.supplier_id : null,
        supplier_name: suppliers[p.supplier_id] || ''
      }
    })
    .filter(r => r.qty + r.on_order <= r.min_stock)
}

app.get('/api/reorder/suggestions', authMiddleware, (req, res) => {
  res.json(computeReorder(getDb()))
})

// Crea una bozza d'ordine per ogni fornitore abituale con gli articoli da riordinare.
// Il costo è quello noto dell'articolo (0 se manca: va inserito prima di ricevere).
app.post('/api/reorder/create-orders', authMiddleware, (req, res) => {
  const db = getDb()
  const only = Array.isArray(req.body.product_ids) ? new Set(req.body.product_ids) : null
  const list = computeReorder(db).filter(r => !only || only.has(r.product_id))
  const skipped = list.filter(r => !r.supplier_id).map(r => r.name)
  const bySupplier = {}
  for (const r of list.filter(r => r.supplier_id)) (bySupplier[r.supplier_id] = bySupplier[r.supplier_id] || []).push(r)

  const created = []
  for (const [supplierId, rows] of Object.entries(bySupplier)) {
    const supplier = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(supplierId)
    const built = buildPurchaseItems(db, rows.map(r => ({ product_id: r.product_id, qty: r.suggested, cost: r.cost != null ? r.cost : 0 })))
    if (built.error) return res.status(400).json({ error: built.error })
    created.push(createPurchaseOrder(db, supplier, built, { status: 'bozza', notes: 'Riordino automatico (scorta minima)', userId: req.user.id }))
  }
  res.json({ created: created.map(o => ({ id: o.id, number: o.number, supplier_name: o.supplier_name, items: o.items.length })), skipped })
})

// ── SCADENZARIO: crediti da incassare e debiti da pagare ──────
const validIso = (v) => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(Date.parse(v))) ? v : null

function createDue(db, d) {
  const due = {
    id: crypto.randomUUID(), kind: d.kind, party_type: d.party_type || null, party_id: d.party_id || null,
    party_name: d.party_name || '', ref_type: d.ref_type || 'manual', ref_id: d.ref_id || null,
    ref_label: d.ref_label || '', description: d.description || '', amount: round2(Number(d.amount)),
    paid: 0, due_date: d.due_date, payments_json: '[]', created_at: new Date().toISOString(), closed_at: null
  }
  db.prepare(`INSERT INTO dues (id,kind,party_type,party_id,party_name,ref_type,ref_id,ref_label,description,amount,paid,due_date,payments_json,created_at,closed_at)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(due.id, due.kind, due.party_type, due.party_id, due.party_name, due.ref_type, due.ref_id, due.ref_label,
         due.description, due.amount, due.paid, due.due_date, due.payments_json, due.created_at, due.closed_at)
  return due
}

function mapDue(row) {
  const residual = round2(row.amount - row.paid)
  const today = new Date().toISOString().split('T')[0]
  let payments = []
  try { payments = JSON.parse(row.payments_json || '[]') } catch {}
  return { ...row, payments, residual, status: residual <= 0.005 ? 'saldata' : row.due_date < today ? 'scaduta' : 'aperta' }
}

app.get('/api/dues', authMiddleware, (req, res) => {
  const kind = ['credito', 'debito'].includes(req.query.kind) ? req.query.kind : null
  const rows = (kind
    ? getDb().prepare('SELECT * FROM dues WHERE kind = ? ORDER BY due_date ASC, created_at ASC LIMIT 1000').all(kind)
    : getDb().prepare('SELECT * FROM dues ORDER BY due_date ASC, created_at ASC LIMIT 1000').all()).map(mapDue)
  const status = req.query.status
  res.json(status === 'open' ? rows.filter(d => d.status !== 'saldata') : status === 'closed' ? rows.filter(d => d.status === 'saldata') : rows)
})

app.get('/api/dues/summary', authMiddleware, (req, res) => res.json(duesSummary(getDb())))

app.post('/api/dues', authMiddleware, (req, res) => {
  const { kind, party_id, party_type, party_name, description } = req.body
  const amount = Number(req.body.amount)
  if (!['credito', 'debito'].includes(kind)) return res.status(400).json({ error: 'Tipo di scadenza non valido' })
  if (!String(party_name || '').trim())       return res.status(400).json({ error: 'Indica il cliente, il fornitore o una descrizione del soggetto' })
  if (!(amount > 0))                          return res.status(400).json({ error: 'Importo non valido' })
  const due_date = validIso(req.body.due_date)
  if (!due_date)                              return res.status(400).json({ error: 'Data di scadenza non valida' })
  res.json(mapDue(createDue(getDb(), { kind, party_id, party_type, party_name: String(party_name).trim(), description, amount, due_date, ref_type: 'manual', ref_label: 'Inserita a mano' })))
})

app.put('/api/dues/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM dues WHERE id = ?').get(req.params.id)
  if (!row) return res.status(404).json({ error: 'Scadenza non trovata' })
  const due_date = req.body.due_date !== undefined ? validIso(req.body.due_date) : row.due_date
  if (!due_date) return res.status(400).json({ error: 'Data di scadenza non valida' })
  db.prepare('UPDATE dues SET due_date = ?, description = ? WHERE id = ?')
    .run(due_date, req.body.description !== undefined ? String(req.body.description) : row.description, req.params.id)
  res.json(mapDue(db.prepare('SELECT * FROM dues WHERE id = ?').get(req.params.id)))
})

// Registra un pagamento (anche parziale). Quando il residuo arriva a zero la scadenza è saldata.
app.post('/api/dues/:id/pay', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM dues WHERE id = ?').get(req.params.id)
  if (!row) return res.status(404).json({ error: 'Scadenza non trovata' })
  const residual = round2(row.amount - row.paid)
  const amount = round2(Number(req.body.amount))
  if (residual <= 0.005)  return res.status(400).json({ error: 'Questa scadenza è già saldata' })
  if (!(amount > 0))      return res.status(400).json({ error: 'Importo non valido' })
  if (amount > residual + 0.005) return res.status(400).json({ error: `L'importo supera il residuo (${residual.toFixed(2)})` })

  let payments = []
  try { payments = JSON.parse(row.payments_json || '[]') } catch {}
  payments.push({ date: validIso(req.body.date) || new Date().toISOString().split('T')[0], amount, method: String(req.body.method || ''), by: req.user.id })
  const paid = round2(row.paid + amount)
  const closed = round2(row.amount - paid) <= 0.005
  db.prepare('UPDATE dues SET paid = ?, payments_json = ?, closed_at = ? WHERE id = ?')
    .run(paid, JSON.stringify(payments), closed ? new Date().toISOString() : null, req.params.id)
  res.json(mapDue(db.prepare('SELECT * FROM dues WHERE id = ?').get(req.params.id)))
})

app.delete('/api/dues/:id', authMiddleware, (req, res) => {
  const db = getDb()
  const row = db.prepare('SELECT * FROM dues WHERE id = ?').get(req.params.id)
  if (!row) return res.json({ ok: true })
  if (row.paid > 0) return res.status(400).json({ error: 'Ci sono pagamenti registrati: non si può eliminare' })
  db.prepare('DELETE FROM dues WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// ── INVENTARIO: rettifica delle giacenze dopo un conteggio fisico ──
// Ogni differenza diventa un movimento (entrata/uscita) con la dicitura della rettifica,
// così resta nel registro dei Movimenti. Tutto in un'unica transazione.
app.post('/api/inventory/apply', authMiddleware, (req, res) => {
  const db = getDb()
  const counts = req.body.counts
  if (!Array.isArray(counts) || counts.length === 0) return res.status(400).json({ error: 'Nessun conteggio da applicare' })
  const note = String(req.body.notes || '').trim()
  const lines = []
  let valueDiff = 0, unchanged = 0

  db.exec('BEGIN')
  try {
    const now = new Date().toISOString()
    for (const c of counts) {
      const counted = Number(c.counted)
      if (!Number.isInteger(counted) || counted < 0) throw new Error('Quantità contata non valida')
      const p = db.prepare('SELECT * FROM products WHERE id = ?').get(c.product_id)
      if (!p) throw new Error('Articolo non trovato in magazzino')
      const before = p.qty || 0, diff = counted - before
      if (diff === 0) { unchanged++; continue }
      db.prepare('UPDATE products SET qty = ? WHERE id = ?').run(counted, p.id)
      db.prepare('INSERT INTO movements (id,product_id,product_name,type,qty,notes,user,created_at) VALUES (?,?,?,?,?,?,?,?)')
        .run(crypto.randomUUID(), p.id, p.name, diff > 0 ? 'entrata' : 'uscita', Math.abs(diff),
             `Rettifica inventario${note ? ': ' + note : ''} (a sistema ${before}, contati ${counted})`, req.user.id, now)
      if (p.cost != null) valueDiff += diff * p.cost
      lines.push({ product_id: p.id, name: p.name, from: before, to: counted, diff })
    }
    db.exec('COMMIT')
  } catch (e) {
    try { db.exec('ROLLBACK') } catch {}
    return res.status(400).json({ error: e.message })
  }
  res.json({ adjusted: lines.length, unchanged, valueDiff: round2(valueDiff), lines })
})

// ── IMPORT CSV (le righe arrivano già lette dal browser) ──────
const clean = (v) => (v === undefined || v === null) ? '' : String(v).trim()
const importNum = (v) => numOrNull(typeof v === 'string' ? v.trim().replace(',', '.') : v)
const importInt = (v) => intOrNull(typeof v === 'string' ? v.trim() : v)

function runImport(res, rows, handler) {
  if (!Array.isArray(rows) || rows.length === 0) return res.status(400).json({ error: 'Nessuna riga da importare' })
  if (rows.length > 5000) return res.status(400).json({ error: 'Massimo 5000 righe per importazione' })
  const db = getDb()
  const result = { created: 0, updated: 0, skipped: 0, errors: [] }
  db.exec('BEGIN')
  try {
    rows.forEach((r, idx) => {
      try { result[handler(db, r || {})] += 1 } catch (e) { result.errors.push({ row: idx + 1, error: e.message }) }
    })
    db.exec('COMMIT')
  } catch (e) {
    try { db.exec('ROLLBACK') } catch {}
    return res.status(400).json({ error: e.message })
  }
  res.json(result)
}

// Per gli articoli già esistenti (stesso barcode, oppure stesso nome se manca il barcode)
// si aggiornano solo i campi compilati; la giacenza NON viene toccata (per quella c'è l'Inventario).
app.post('/api/import/products', authMiddleware, (req, res) => {
  runImport(res, req.body.rows, (db, r) => {
    const name = clean(r.name)
    if (!name) throw new Error('Nome mancante')
    const barcode = clean(r.barcode)
    for (const [k, label] of [['price', 'Prezzo'], ['cost', 'Costo']])
      if (clean(r[k]) !== '' && importNum(r[k]) == null) throw new Error(`${label} non valido`)
    for (const [k, label] of [['qty', 'Quantità'], ['min_stock', 'Scorta minima'], ['reorder_qty', 'Quantità di riordino']])
      if (clean(r[k]) !== '' && importInt(r[k]) == null) throw new Error(`${label} non valida (serve un numero intero)`)
    let supplierId = null
    if (clean(r.supplier)) {
      const sp = db.prepare('SELECT id FROM suppliers WHERE LOWER(name) = ?').get(clean(r.supplier).toLowerCase())
      if (!sp) throw new Error(`Fornitore "${clean(r.supplier)}" non trovato in Anagrafiche`)
      supplierId = sp.id
    }
    const existing = barcode
      ? db.prepare('SELECT * FROM products WHERE barcode = ?').get(barcode)
      : db.prepare('SELECT * FROM products WHERE LOWER(name) = ?').get(name.toLowerCase())

    const price = importNum(r.price), cost = importNum(r.cost)
    if (existing) {
      const next = {
        category: clean(r.category) || existing.category, unit: clean(r.unit) || existing.unit,
        price: price != null ? price : existing.price, cost: cost != null ? cost : existing.cost,
        min_stock: clean(r.min_stock) !== '' ? importInt(r.min_stock) : existing.min_stock,
        reorder_qty: clean(r.reorder_qty) !== '' ? importInt(r.reorder_qty) : existing.reorder_qty,
        supplier_id: supplierId || existing.supplier_id, notes: clean(r.notes) || existing.notes,
        barcode: barcode || existing.barcode
      }
      const changed = Object.keys(next).some(k => (next[k] ?? null) !== (existing[k] ?? null))
      if (!changed) return 'skipped'
      db.prepare('UPDATE products SET category=?,unit=?,price=?,cost=?,min_stock=?,reorder_qty=?,supplier_id=?,notes=?,barcode=? WHERE id=?')
        .run(next.category, next.unit, next.price, next.cost, next.min_stock, next.reorder_qty, next.supplier_id, next.notes, next.barcode, existing.id)
      return 'updated'
    }
    db.prepare('INSERT INTO products (id,name,barcode,nfc_uid,qty,unit,price,cost,min_stock,reorder_qty,supplier_id,category,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(crypto.randomUUID(), name, barcode, null, importInt(r.qty) || 0, clean(r.unit) || 'pz', price != null ? price : 0, cost,
           importInt(r.min_stock), importInt(r.reorder_qty), supplierId, clean(r.category), clean(r.notes), new Date().toISOString())
    return 'created'
  })
})

// Clienti e fornitori: stesso nome/P.IVA = si aggiornano i campi compilati.
function importParty(table, extra) {
  return (db, r) => {
    const name = clean(r.name)
    if (!name) throw new Error('Nome mancante')
    const vat = clean(r.vat_number)
    const existing = vat
      ? db.prepare(`SELECT * FROM ${table} WHERE vat_number = ?`).get(vat)
      : db.prepare(`SELECT * FROM ${table} WHERE LOWER(name) = ?`).get(name.toLowerCase())
    const vals = { vat_number: vat, phone: clean(r.phone), email: clean(r.email), address: clean(r.address), notes: clean(r.notes) }
    if (extra) {
      if (clean(r.payment_days) !== '' && importInt(r.payment_days) == null) throw new Error('Giorni di pagamento non validi')
      vals.payment_days = importInt(r.payment_days)
    }
    if (existing) {
      const next = {}
      for (const k of Object.keys(vals)) next[k] = (vals[k] !== '' && vals[k] != null) ? vals[k] : existing[k]
      if (!Object.keys(next).some(k => (next[k] ?? '') !== (existing[k] ?? ''))) return 'skipped'
      const cols = Object.keys(next)
      db.prepare(`UPDATE ${table} SET ${cols.map(c => c + '=?').join(',')} WHERE id=?`).run(...cols.map(c => next[c]), existing.id)
      return 'updated'
    }
    const cols = ['id', 'name', ...Object.keys(vals), 'created_at']
    db.prepare(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`)
      .run(crypto.randomUUID(), name, ...Object.keys(vals).map(k => vals[k]), new Date().toISOString())
    return 'created'
  }
}
app.post('/api/import/customers', authMiddleware, (req, res) => runImport(res, req.body.rows, importParty('customers', false)))
app.post('/api/import/suppliers', authMiddleware, (req, res) => runImport(res, req.body.rows, importParty('suppliers', true)))

// ── STORICO di un cliente / fornitore ─────────────────────────
app.get('/api/customers/:id/history', authMiddleware, (req, res) => {
  const db = getDb()
  res.json({
    sales: db.prepare('SELECT id, number, date, total, payment_method FROM sales WHERE customer_id = ? ORDER BY created_at DESC LIMIT 100').all(req.params.id),
    dues: db.prepare('SELECT * FROM dues WHERE party_type = ? AND party_id = ? ORDER BY due_date ASC').all('customer', req.params.id).map(mapDue)
  })
})

app.get('/api/suppliers/:id/history', authMiddleware, (req, res) => {
  const db = getDb()
  res.json({
    orders: db.prepare('SELECT id, number, date, status, total FROM purchase_orders WHERE supplier_id = ? ORDER BY number DESC LIMIT 100').all(req.params.id),
    dues: db.prepare('SELECT * FROM dues WHERE party_type = ? AND party_id = ? ORDER BY due_date ASC').all('supplier', req.params.id).map(mapDue)
  })
})


// ── BACKUP / RIPRISTINO (solo Super Admin) ─────────────────────
// Il file contiene anche hash delle password e chiave AI: per questo è riservato al Super Admin.
function requireSuperAdmin(req, res) {
  if (req.user.role !== 'Super Admin') {
    res.status(403).json({ error: 'Riservato al Super Admin' })
    return false
  }
  return true
}

app.get('/api/admin/backup', authMiddleware, (req, res) => {
  if (!requireSuperAdmin(req, res)) return
  res.setHeader('Content-Type', 'application/octet-stream')
  res.send(exportDatabase())
})

app.post('/api/admin/restore', authMiddleware, express.raw({ type: '*/*', limit: '256mb' }), (req, res) => {
  if (!requireSuperAdmin(req, res)) return
  if (!Buffer.isBuffer(req.body) || req.body.length === 0)
    return res.status(400).json({ error: 'Nessun file ricevuto' })
  try {
    replaceDatabase(req.body)
  } catch (e) {
    return res.status(400).json({ error: e.message })
  }
  // Utenti e ruoli possono essere diversi nel backup: tutte le sessioni vanno invalidate.
  sessions.clear()
  res.json({ ok: true })
})

// ── IMPOSTAZIONI (generiche, chiave/valore) ────────────────────
function loadGenericSettings() {
  const rows = getDb().prepare('SELECT key, value FROM settings_kv').all()
  const out = {}
  for (const r of rows) {
    if (RESERVED_KV_KEYS.has(r.key)) continue
    try { out[r.key] = JSON.parse(r.value) } catch { out[r.key] = r.value }
  }
  return out
}

app.get('/api/settings', authMiddleware, (req, res) => res.json(loadGenericSettings()))

app.post('/api/settings', authMiddleware, (req, res) => {
  const { key, value } = req.body
  kvSet(key, value)
  res.json({ ok: true })
})

// ── CONFIGURAZIONE UI ─────────────────────────────────────────
app.get('/api/ui-config', authMiddleware, (req, res) => {
  res.json(kvGet('_ui_config', {}))
})

app.post('/api/ui-config', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  kvSet('_ui_config', { ...kvGet('_ui_config', {}), ...req.body })
  res.json({ ok: true })
})

// ── CONFIGURAZIONE AI ─────────────────────────────────────────
app.get('/api/settings/ai', authMiddleware, (req, res) => {
  const ai = kvGet('_ai_config', {})
  res.json({ provider: ai.provider || 'groq', key: ai.key || '', url: ai.url || '', model: ai.model || '' })
})

app.post('/api/settings/ai', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const { provider, key, url, model } = req.body
  kvSet('_ai_config', { provider: provider || 'groq', key: key || '', url: url || '', model: model || '' })
  res.json({ ok: true })
})

// ── CASSA ─────────────────────────────────────────────────────
const DEFAULT_CASH_REGISTER = {
  name: 'Cassa principale', printer_type: 'epson_a4',
  printer_ip: '', printer_port: '9100',
  header_text: 'GesClo', footer_text: "Grazie per l'acquisto!",
  show_tax: false, tax_rate: 22, currency: 'EUR',
  auto_print: true
}

app.get('/api/cash-register', authMiddleware, (req, res) => res.json(kvGet('_cash_register', DEFAULT_CASH_REGISTER)))

app.put('/api/cash-register', authMiddleware, (req, res) => {
  kvSet('_cash_register', { ...kvGet('_cash_register', DEFAULT_CASH_REGISTER), ...req.body })
  res.json({ ok: true })
})

// ── STATS ─────────────────────────────────────────────────────
app.get('/api/stats', authMiddleware, (req, res) => {
  const today = new Date().toISOString().split('T')[0]
  const db    = getDb()
  const prodRows = db.prepare('SELECT qty, min_stock FROM products').all()
  const qtys  = prodRows.map(r => r.qty || 0)
  const todayMovements = db.prepare("SELECT COUNT(*) AS c FROM movements WHERE created_at LIKE ?").get(today + '%').c
  const todaySalesRows = db.prepare('SELECT total FROM sales WHERE date = ?').all(today)

  res.json({
    totalProducts:  qtys.length,
    lowStock:       prodRows.filter(r => (r.qty || 0) > 0 && (r.qty || 0) <= (r.min_stock > 0 ? r.min_stock : 5)).length,
    outOfStock:     qtys.filter(q => q <= 0).length,
    todayMovements,
    todaySales:     todaySalesRows.length,
    todayRevenue:   todaySalesRows.reduce((sum, s) => sum + (s.total || 0), 0)
  })
})

// ── UTENTI (locale) ───────────────────────────────────────────
function mapLocalUser(u) {
  return { id: u.id, username: u.username, email: u.email || '', role: u.role }
}

app.get('/api/users', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  res.json(getDb().prepare('SELECT * FROM users').all().map(mapLocalUser))
})

app.post('/api/users', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const { username, email, password, role } = req.body
  if (!username || !username.trim())    return res.status(400).json({ error: 'Username obbligatorio' })
  if (!password || password.length < 8) return res.status(400).json({ error: 'Password minimo 8 caratteri' })
  if (role === 'Super Admin' && req.user.role !== 'Super Admin')
    return res.status(403).json({ error: 'Solo un Super Admin può assegnare il ruolo Super Admin' })

  const db = getDb()
  if (db.prepare('SELECT 1 FROM users WHERE LOWER(username) = ?').get(username.trim().toLowerCase()))
    return res.status(400).json({ error: 'Username già in uso' })

  const user = { id: crypto.randomUUID(), username: username.trim(), email: email || '', password: hashPassword(password), role: role || 'Operatore' }
  db.prepare('INSERT INTO users (id,username,email,password,role) VALUES (?,?,?,?,?)')
    .run(user.id, user.username, user.email, user.password, user.role)
  res.json(mapLocalUser(user))
})

app.put('/api/users/:id', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const { username, role, password } = req.body
  if (role === 'Super Admin' && req.user.role !== 'Super Admin')
    return res.status(403).json({ error: 'Solo un Super Admin può assegnare il ruolo Super Admin' })

  const db = getDb()
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id)
  if (!user) return res.status(404).json({ error: 'Utente non trovato' })
  if (password && password.length < 8) return res.status(400).json({ error: 'Password minimo 8 caratteri' })

  const newUsername = (username && username.trim()) ? username.trim() : user.username
  const newRole     = role || user.role
  const newPassword = password ? hashPassword(password) : user.password
  db.prepare('UPDATE users SET username=?,role=?,password=? WHERE id=?').run(newUsername, newRole, newPassword, req.params.id)
  res.json({ ok: true })
})

app.delete('/api/users/:id', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const db = getDb()
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id)
  if (!user) return res.status(404).json({ error: 'Utente non trovato' })
  if (user.role === 'Super Admin' && db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'Super Admin'").get().c <= 1)
    return res.status(400).json({ error: "Impossibile eliminare l'unico Super Admin" })

  db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id)
  for (const [token, s] of sessions) if (s.id === req.params.id) sessions.delete(token)
  res.json({ ok: true })
})

// ── CONTROLLO SERVER (solo admin) ────────────────────────────
app.post('/api/admin/server/close-all', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  res.json({ ok: true })
  setTimeout(() => {
    const fermaPath = path.join(__dirname, '..', 'ferma.bat')
    spawn('cmd.exe', ['/c', fermaPath], {
      detached: true,
      stdio: 'ignore'
    }).unref()
  }, 600)
})

app.post('/api/admin/server/stop', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  res.json({ ok: true, message: 'Server in spegnimento...' })
  setTimeout(() => process.exit(0), 600)
})

app.post('/api/admin/server/shutdown', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  res.json({ ok: true, message: 'Spegnimento PC in corso...' })
  setTimeout(() => {
    spawn('cmd.exe', ['/c', 'shutdown /s /t 5 /c "GesClo: spegnimento richiesto da admin"'], {
      detached: true, stdio: 'ignore'
    }).unref()
  }, 600)
})

app.post('/api/admin/server/restart', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  res.json({ ok: true, message: 'Server in riavvio...' })
  setTimeout(() => {
    const scriptPath = path.join(__dirname, 'server.js')
    spawn('cmd.exe', ['/c', 'ping -n 4 127.0.0.1 >nul && node "' + scriptPath + '"'], {
      cwd: __dirname,
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    }).unref()
    process.exit(0)
  }, 600)
})

// ── NFC ───────────────────────────────────────────────────────
const nfcSseClients = new Set()
let   lastNfcScan   = null

// SSE: il frontend si connette qui per ricevere gli eventi in tempo reale
app.get('/api/nfc/stream', (req, res) => {
  res.setHeader('Content-Type',  'text/event-stream')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection',    'keep-alive')
  res.flushHeaders()
  res.write('data: {"type":"connected"}\n\n')
  nfcSseClients.add(res)
  req.on('close', () => nfcSseClients.delete(res))
})

function broadcastNFC(payload) {
  const msg = `data: ${JSON.stringify(payload)}\n\n`
  nfcSseClients.forEach(c => { try { c.write(msg) } catch {} })
}

// Ricezione scansione (Android app, nfc-service.js, USB reader)
app.post('/api/nfc/scan', (req, res) => {
  const settings   = loadGenericSettings()
  const storedKey  = (settings.nfc_api_key || '').trim()
  const incomingKey = (req.headers['x-nfc-key'] || req.body?.key || '').trim()
  if (storedKey && incomingKey !== storedKey)
    return res.status(401).json({ error: 'NFC key non valida' })

  const { uid, type, source, cardBrand } = req.body
  if (!uid) return res.status(400).json({ error: 'uid obbligatorio' })

  const norm   = uid.replace(/[:\-\s]/g, '').toUpperCase()
  const isCard = source === 'payment_card'

  // Cerca prodotto solo se non è una carta di pagamento
  let product = null
  if (!isCard) {
    const db = getDb()
    product = db.prepare('SELECT * FROM products WHERE UPPER(barcode) = ? OR barcode = ? OR UPPER(nfc_uid) = ? OR nfc_uid = ?')
      .get(norm, uid, norm, uid)
      || db.prepare('SELECT p.* FROM product_barcodes b JOIN products p ON p.id = b.product_id WHERE UPPER(b.barcode) = ? OR b.barcode = ?').get(norm, uid)
      || null
  }

  lastNfcScan = {
    uid: norm, rawUid: uid,
    cardType:  type      || 'unknown',
    source:    source    || 'product_tag',
    cardBrand: cardBrand || null,
    product, ts: Date.now()
  }
  broadcastNFC({ type: 'nfc_scan', ...lastNfcScan })
  res.json({ ok: true, uid: norm, source: lastNfcScan.source, cardBrand: lastNfcScan.cardBrand, product })
})

app.get('/api/nfc/last', authMiddleware, (req, res) => {
  res.json(lastNfcScan || { uid: null })
})

// ── POS ANDROID ──────────────────────────────────────────────
let posRequest = null
const posSseClients = new Set()

app.post('/api/pos/request', authMiddleware, (req, res) => {
  const { amount, saleId, items } = req.body
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Importo non valido' })
  posRequest = {
    id: Date.now().toString(),
    amount: parseFloat(amount),
    saleId: saleId || null,
    items: items || [],
    status: 'pending',
    ts: Date.now()
  }
  broadcastPOS({ type: 'payment_request', ...posRequest })
  res.json({ ok: true, request: posRequest })
})

app.get('/api/pos/pending', (req, res) => {
  const settings = loadGenericSettings()
  const key = (settings.nfc_api_key || '').trim()
  const inKey = (req.headers['x-nfc-key'] || req.query.key || '').trim()
  if (key && inKey !== key) return res.status(401).json({ error: 'Chiave non valida' })
  if (posRequest && posRequest.status === 'pending') {
    res.json(posRequest)
  } else {
    res.json({ status: 'idle' })
  }
})

app.post('/api/pos/confirm', (req, res) => {
  const settings = loadGenericSettings()
  const key = (settings.nfc_api_key || '').trim()
  const inKey = (req.headers['x-nfc-key'] || req.body?.key || '').trim()
  if (key && inKey !== key) return res.status(401).json({ error: 'Chiave non valida' })

  const { uid, cardBrand } = req.body
  if (!posRequest || posRequest.status !== 'pending')
    return res.status(400).json({ error: 'Nessun pagamento in attesa' })

  posRequest.status = 'confirmed'
  posRequest.cardUid = uid || ''
  posRequest.cardBrand = cardBrand || 'Contactless'
  posRequest.confirmedAt = Date.now()

  broadcastPOS({ type: 'payment_confirmed', ...posRequest })
  broadcastNFC({
    type: 'nfc_scan', uid: uid || '', source: 'payment_card',
    cardBrand: posRequest.cardBrand, product: null, ts: Date.now()
  })

  res.json({ ok: true, request: posRequest })
})

app.post('/api/pos/cancel', (req, res) => {
  const settings = loadGenericSettings()
  const key = (settings.nfc_api_key || '').trim()
  const inKey = (req.headers['x-nfc-key'] || req.body?.key || '').trim()
  // Vale solo un token di sessione reale: prima bastava qualunque header Authorization
  // (anche inventato) per saltare il controllo della chiave.
  const hasAuth = sessions.has((req.headers.authorization || '').replace('Bearer ', ''))
  if (!hasAuth && key && inKey !== key) return res.status(401).json({ error: 'Chiave non valida' })

  const reason = req.body?.reason || 'cancelled'
  if (posRequest && posRequest.status === 'pending') {
    posRequest.status = 'cancelled'
    posRequest.reason = reason
    broadcastPOS({ type: 'payment_cancelled', reason })
    broadcastNFC({ type: 'pos_cancelled', reason, ts: Date.now() })
  }
  posRequest = null
  res.json({ ok: true })
})

app.post('/api/pos/sale', (req, res) => {
  const settings = loadGenericSettings()
  const key = (settings.nfc_api_key || '').trim()
  const inKey = (req.headers['x-nfc-key'] || req.body?.key || '').trim()
  if (key && inKey !== key) return res.status(401).json({ error: 'Chiave non valida' })

  const { amount, cardBrand, cardUid } = req.body
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Importo non valido' })

  const db = getDb()
  const sale = insertSale(db, {
    customer_id: '', customer_name: 'POS Contactless',
    items: [{ name: 'Pagamento POS', qty: 1, price: parseFloat(amount), subtotal: parseFloat(amount), product_id: '' }],
    subtotal: parseFloat(amount), discount: 0, tax: 0, total: parseFloat(amount),
    payment_method: 'pos_nfc',
    payment_other: (cardBrand || 'Contactless') + (cardUid ? ' (' + cardUid.substring(0, 8) + ')' : ''),
    notes: 'Vendita da POS Android',
    user: 'pos'
  })

  broadcastNFC({
    type: 'nfc_scan', uid: cardUid || '', source: 'payment_card',
    cardBrand: cardBrand || 'Contactless', product: null, ts: Date.now(),
    posSale: { number: sale.number, total: sale.total }
  })

  res.json({ ok: true, sale })
})

app.get('/api/pos/config', (req, res) => {
  const settings = loadGenericSettings()
  const key = (settings.nfc_api_key || '').trim()
  const inKey = (req.headers['x-nfc-key'] || req.query.key || '').trim()
  if (key && inKey !== key) return res.status(401).json({ error: 'Chiave non valida' })
  res.json({
    pos_pin: settings.pos_pin || '',
    pos_name: settings.pos_name || 'POS GesClo',
    pos_wallpaper: settings.pos_wallpaper || ''
  })
})

app.post('/api/pos/wallpaper', authMiddleware, (req, res) => {
  if (!requireAdmin(req, res)) return
  const { wallpaper } = req.body
  kvSet('pos_wallpaper', wallpaper || '')
  res.json({ ok: true })
})

app.get('/api/pos/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection', 'keep-alive')
  res.flushHeaders()
  res.write('data: {"type":"connected"}\n\n')
  posSseClients.add(res)
  req.on('close', () => posSseClients.delete(res))
})

function broadcastPOS(payload) {
  const msg = `data: ${JSON.stringify(payload)}\n\n`
  posSseClients.forEach(c => { try { c.write(msg) } catch {} })
}

// ── TERMINALE POWERSHELL (WebSocket, solo admin) ─────────────
const httpServer = http.createServer(app)
const wss        = new WebSocketServer({ server: httpServer, path: '/ws/terminal' })

wss.on('connection', async (ws, req) => {
  const params = new URL(req.url, 'http://localhost').searchParams
  const token  = params.get('token')

  const session = token && sessions.get(token)
  if (!session) { ws.close(1008, 'Token non valido'); return }

  if (!['Super Admin', 'Admin'].includes(session.role)) {
    ws.send('Accesso negato: ruolo insufficiente\r\n')
    ws.close(1008, 'Forbidden')
    return
  }

  const ps = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass'], {
    cwd: path.join(__dirname, '..'),
    stdio: ['pipe', 'pipe', 'pipe']
  })

  ps.stdout.setEncoding('utf8')
  ps.stderr.setEncoding('utf8')
  ps.stdin.write('[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\r\n')
  ps.stdin.write('[Console]::InputEncoding  = [System.Text.Encoding]::UTF8\r\n')
  ps.stdin.write('$OutputEncoding = [System.Text.Encoding]::UTF8\r\n')
  ps.stdin.write('Write-Host "[Sessione PowerShell — GesClo Admin]"\r\n')
  ps.stdin.write('Write-Host "Directory: $(Get-Location)"\r\n')
  ps.stdin.write('Write-Host ""\r\n')

  ps.stdout.on('data', d => { if (ws.readyState === 1) ws.send(d) })
  ps.stderr.on('data', d => { if (ws.readyState === 1) ws.send(d) })
  ps.on('close', () => { if (ws.readyState === 1) ws.close() })
  ps.on('error', e => { if (ws.readyState === 1) ws.send('\nErrore PowerShell\n') })

  ws.on('message', msg => {
    try { ps.stdin.write(msg.toString() + '\r\n') } catch {}
  })
  ws.on('close', () => { try { ps.kill() } catch {} })
})

// ── INTERFACCIA WEB (build di frontend/) ──────────────────────────
// Se esiste frontend/dist (versione installata) viene servita da qui sulla stessa porta
// delle API. In sviluppo non esiste: la UI arriva da Vite su :3000. Il frontend usa
// HashRouter, quindi non serve alcun fallback SPA.
const FRONTEND_DIST = path.join(__dirname, '..', 'frontend', 'dist')
if (require('fs').existsSync(path.join(FRONTEND_DIST, 'index.html'))) {
  app.use(express.static(FRONTEND_DIST))
}

// ── AVVIO ─────────────────────────────────────────────────────
;(async () => {
  await initDatabase(DB_FILE, { dbJsonPath: LEGACY_DB_JSON, suppJsonPath: LEGACY_SUPP_JSON })
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`GesClo API avviata su http://0.0.0.0:${PORT}`)
    console.log(`Database: ${DB_FILE}`)
  })
})()
