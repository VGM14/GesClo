// Traduzione dei messaggi d'errore del server (italiano → inglese).
//
// I messaggi nel codice sono scritti in italiano. Se il client manda l'intestazione
// "X-Lang: en" le risposte JSON vengono tradotte qui, prima dell'invio: nessun endpoint
// deve preoccuparsi della lingua. Un messaggio senza traduzione resta in italiano.

const EXACT = {
  'Configurazione già completata': 'Setup has already been completed',
  'Username obbligatorio': 'Username is required',
  'Password minimo 8 caratteri': 'Password must be at least 8 characters',
  'Username e password richiesti': 'Username and password are required',
  'Credenziali non valide': 'Invalid credentials',
  'Non autorizzato': 'Not authorised',
  'Accesso riservato agli amministratori': 'Access restricted to administrators',
  'Utente non trovato': 'User not found',
  'Articolo non trovato': 'Item not found',
  'Indica almeno la taglia o il colore': 'Enter at least the size or the colour',
  'Variante non trovata': 'Variant not found',
  'Nome obbligatorio': 'Name is required',
  'Prodotto non trovato': 'Product not found',
  'Questo articolo ha varianti: scegli la taglia/colore del movimento': 'This item has variants: choose the size/colour of the movement',
  'Cliente non trovato': 'Customer not found',
  'La vendita non contiene articoli': 'The sale contains no items',
  'Quantità o prezzo non validi': 'Invalid quantity or price',
  'Per vendere a credito scegli un cliente': 'To sell on credit, choose a customer',
  'Fornitore non trovato': 'Supplier not found',
  'Il fornitore ha ordini ancora aperti: ricevili o annullali prima di eliminarlo': 'The supplier still has open orders: receive or cancel them before deleting',
  "L'ordine non contiene articoli": 'The order contains no items',
  'Articolo non trovato in magazzino': 'Item not found in stock',
  'Scegli un fornitore': 'Choose a supplier',
  'Ordine non trovato': 'Order not found',
  'Un ordine ricevuto o annullato non si può modificare': 'A received or cancelled order cannot be edited',
  'Questo ordine è già stato chiuso': 'This order has already been closed',
  'Un ordine già ricevuto non si può annullare': 'An order that has already been received cannot be cancelled',
  'Si possono eliminare solo bozze e ordini annullati': 'Only drafts and cancelled orders can be deleted',
  'Tipo di scadenza non valido': 'Invalid due date type',
  'Indica il cliente, il fornitore o una descrizione del soggetto': 'Enter the customer, the supplier or a description of the party',
  'Importo non valido': 'Invalid amount',
  'Data di scadenza non valida': 'Invalid due date',
  'Scadenza non trovata': 'Due date not found',
  'Questa scadenza è già saldata': 'This due date is already settled',
  'Ci sono pagamenti registrati: non si può eliminare': 'Payments have been recorded: it cannot be deleted',
  'Nessun conteggio da applicare': 'No counts to apply',
  'Quantità contata non valida': 'Invalid counted quantity',
  'Nessuna riga da importare': 'No rows to import',
  'Massimo 5000 righe per importazione': 'Maximum 5000 rows per import',
  'Nome mancante': 'Name is missing',
  'Giorni di pagamento non validi': 'Invalid payment days',
  'Riservato al Super Admin': 'Reserved for the Super Admin',
  'Nessun file ricevuto': 'No file received',
  'Solo un Super Admin può assegnare il ruolo Super Admin': 'Only a Super Admin can assign the Super Admin role',
  'Username già in uso': 'Username already in use',
  "Impossibile eliminare l'unico Super Admin": 'The only Super Admin cannot be deleted',
  'Server in spegnimento...': 'Server shutting down...',
  'Spegnimento PC in corso...': 'Shutting down the PC...',
  'Server in riavvio...': 'Server restarting...',
  'NFC key non valida': 'Invalid NFC key',
  'uid obbligatorio': 'uid is required',
  'Chiave non valida': 'Invalid key',
  'Nessun pagamento in attesa': 'No payment pending',
  'Database non inizializzato': 'Database not initialised',
  'Il backup non contiene utenti: dopo il ripristino nessuno potrebbe accedere': 'The backup contains no users: after restoring nobody would be able to sign in',
  'Il file non è un database SQLite valido': 'The file is not a valid SQLite database',
}

// Messaggi con parti variabili: [espressione, modello] — $1, $2… sono i gruppi catturati
const PATTERNS = [
  [/^Il codice a barre "(.*)" è già assegnato all'articolo "(.*)"$/s, 'The barcode "$1" is already assigned to the item "$2"'],
  [/^Variante non trovata per "(.*)"$/s, 'Variant not found for "$1"'],
  [/^"(.*)" ha varianti: scegli taglia\/colore$/s, '"$1" has variants: choose size/colour'],
  [/^Quantità non valida per "(.*)"$/s, 'Invalid quantity for "$1"'],
  [/^Costo non valido per "(.*)"$/s, 'Invalid cost for "$1"'],
  [/^Inserisci il costo di "(.*)" prima di ricevere l'ordine$/s, 'Enter the cost of "$1" before receiving the order'],
  [/^L'articolo "(.*)" non esiste più in magazzino$/s, 'The item "$1" no longer exists in stock'],
  [/^L'importo supera il residuo \((.*)\)$/s, 'The amount exceeds the balance ($1)'],
  [/^Fornitore "(.*)" non trovato in Anagrafiche$/s, 'Supplier "$1" not found in Contacts'],
  [/^Il file non è un backup di GesClo \(mancano: (.*)\)$/s, 'The file is not a GesClo backup (missing: $1)'],
  [/^(Prezzo|Costo) non valido$/, (m, w) => `${w === 'Prezzo' ? 'Price' : 'Cost'} is not valid`],
  [/^(Quantità|Scorta minima|Quantità di riordino) non valida \(serve un numero intero\)$/, (m, w) =>
    `${{ 'Quantità': 'Quantity', 'Scorta minima': 'Minimum stock', 'Quantità di riordino': 'Reorder quantity' }[w]} is not valid (a whole number is required)`],
]

function translate(msg, lang) {
  if (lang !== 'en' || typeof msg !== 'string') return msg
  if (Object.prototype.hasOwnProperty.call(EXACT, msg)) return EXACT[msg]
  for (const [re, out] of PATTERNS) if (re.test(msg)) return msg.replace(re, out)
  return msg
}

// Traduce i campi di testo di una risposta JSON (error, message, e gli errori riga per riga
// dell'importazione CSV).
function translateBody(body, lang) {
  if (lang !== 'en' || !body || typeof body !== 'object' || Array.isArray(body)) return body
  const out = { ...body }
  if (typeof out.error === 'string') out.error = translate(out.error, lang)
  if (typeof out.message === 'string') out.message = translate(out.message, lang)
  if (Array.isArray(out.errors)) {
    out.errors = out.errors.map(e => (e && typeof e.error === 'string' ? { ...e, error: translate(e.error, lang) } : e))
  }
  return out
}

// Middleware Express: legge X-Lang e traduce le risposte res.json(...)
function langMiddleware(req, res, next) {
  const lang = String(req.headers['x-lang'] || '').toLowerCase() === 'en' ? 'en' : 'it'
  req.lang = lang
  if (lang === 'en') {
    const json = res.json.bind(res)
    res.json = (body) => json(translateBody(body, lang))
  }
  next()
}

module.exports = { translate, translateBody, langMiddleware }
