// GesClo NFC Service — bridge lettori USB PC/SC (ACR122U, ecc.)
// Richiede: npm install nfc-pcsc
// Avvia con: node nfc-service.js
// Invia le scansioni a http://localhost:3001/api/nfc/scan

require('dotenv').config()

let NFC
try {
  NFC = require('nfc-pcsc').NFC
} catch {
  console.error('ERRORE: pacchetto nfc-pcsc non installato.')
  console.error('Esegui: npm install nfc-pcsc')
  process.exit(1)
}

const http = require('http')

const SERVER_PORT = process.env.PORT     || 3001
const SERVER_HOST = process.env.NFC_HOST || '127.0.0.1'
const NFC_KEY     = process.env.NFC_API_KEY || ''

function sendToGesClo(uid, type) {
  const body = JSON.stringify({ uid, type, key: NFC_KEY })
  const req  = http.request({
    hostname: SERVER_HOST,
    port:     SERVER_PORT,
    path:     '/api/nfc/scan',
    method:   'POST',
    headers:  { 'Content-Type': 'application/json', 'X-NFC-Key': NFC_KEY, 'Content-Length': Buffer.byteLength(body) }
  }, res => {
    let data = ''
    res.on('data', d => { data += d })
    res.on('end', () => {
      try {
        const j = JSON.parse(data)
        if (j.product) {
          console.log(`[OK] ${uid} → ${j.product.name} (${j.product.qty} pz)`)
        } else {
          console.log(`[--] ${uid} → nessun articolo trovato`)
        }
      } catch { console.log(`[OK] ${uid} → risposta ricevuta`) }
    })
  })
  req.on('error', e => console.error(`[ERR] ${e.message}`))
  req.write(body)
  req.end()
}

const nfc = new NFC()

nfc.on('reader', reader => {
  console.log(`[NFC] Lettore collegato: ${reader.name}`)

  reader.on('card', card => {
    const uid  = card.uid
    const type = card.type || 'unknown'
    console.log(`[SCAN] UID: ${uid}  Tipo: ${type}`)
    sendToGesClo(uid, type)
  })

  reader.on('card.off', () => console.log('[NFC] Carta rimossa'))
  reader.on('error', e => console.error(`[ERR] ${reader.name}: ${e.message}`))
  reader.on('end', () => console.log(`[NFC] Lettore disconnesso: ${reader.name}`))
})

nfc.on('error', e => console.error('[NFC] Errore NFC:', e.message))

console.log(`GesClo NFC Service avviato — in attesa di lettori USB PC/SC...`)
console.log(`Invia scansioni a http://${SERVER_HOST}:${SERVER_PORT}/api/nfc/scan`)
