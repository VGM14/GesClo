// GesClo Launcher — porta 3002
// Avvia il server API (3001) quando è offline.
// Non richiede autenticazione: gira solo in LAN.
const http   = require('http')
const { spawn } = require('child_process')
const path   = require('path')

const PORT = 3002

http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return }

  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ ok: true, service: 'GesClo Launcher' }))
    return
  }

  if (req.url === '/launch' && req.method === 'POST') {
    const serverScript = path.join(__dirname, 'server.js')
    // Apre una finestra cmd con il server (compatibile Windows 8.1+)
    spawn('powershell', [
      '-Command',
      `Start-Process cmd -ArgumentList '/k title GesClo API & node "${serverScript}"' -WorkingDirectory '${__dirname}' -WindowStyle Normal`
    ], { detached: true, stdio: 'ignore' }).unref()

    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ ok: true, message: 'Server in avvio...' }))
    return
  }

  res.writeHead(404)
  res.end()
}).listen(PORT, '0.0.0.0', () => {
  console.log(`GesClo Launcher pronto su :${PORT}`)
})
