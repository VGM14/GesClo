// Database SQLite via sql.js (WASM) — niente toolchain nativa da compilare
// (stessa scelta fatta da un progetto simile, Store POS).
// Sostituisce i due file gesclo.db.json / gesclo.supplement.json.
const initSqlJs = require('sql.js')
const fs        = require('fs')
const path      = require('path')

let SQL          = null
let db           = null
let rawDb        = null
let dbFilePath   = null
let persistTimer = null

// Scrittura atomica (file temporaneo + rename): un crash o un blackout a metà scrittura
// non lascia un gesclo.sqlite troncato.
function persist() {
  if (!rawDb || !dbFilePath) return
  const data = rawDb.export()
  const tmp  = dbFilePath + '.tmp'
  fs.writeFileSync(tmp, Buffer.from(data))
  fs.renameSync(tmp, dbFilePath)
}

function schedulePersist() {
  if (persistTimer) clearTimeout(persistTimer)
  persistTimer = setTimeout(() => { persist(); persistTimer = null }, 50)
}

// Wrapper con la stessa forma di better-sqlite3 (prepare().run/get/all), che sql.js
// non offre nativamente essendo pensato per un uso più "a basso livello".
function wrapDb(raw) {
  return {
    exec(sql) { raw.exec(sql); schedulePersist() },
    prepare(sql) {
      return {
        run(...params) {
          raw.run(sql, params)
          schedulePersist()
          return { changes: raw.getRowsModified() }
        },
        get(...params) {
          const stmt = raw.prepare(sql)
          stmt.bind(params)
          let row
          if (stmt.step()) row = stmt.getAsObject()
          stmt.free()
          return row || undefined
        },
        all(...params) {
          const stmt = raw.prepare(sql)
          stmt.bind(params)
          const rows = []
          while (stmt.step()) rows.push(stmt.getAsObject())
          stmt.free()
          return rows
        }
      }
    }
  }
}

const SCHEMA_SQL = `
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      barcode TEXT,
      nfc_uid TEXT,
      qty INTEGER NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT 'pz',
      price REAL,
      category TEXT,
      notes TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS movements (
      id TEXT PRIMARY KEY,
      product_id TEXT,
      product_name TEXT,
      type TEXT,
      qty INTEGER,
      notes TEXT,
      user TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      address TEXT,
      notes TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sales (
      id TEXT PRIMARY KEY,
      number INTEGER,
      date TEXT,
      customer_id TEXT,
      customer_name TEXT,
      items_json TEXT NOT NULL DEFAULT '[]',
      subtotal REAL,
      discount REAL,
      tax REAL,
      total REAL,
      payment_method TEXT,
      payment_other TEXT,
      notes TEXT,
      user TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      email TEXT,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'Operatore'
    );
    CREATE TABLE IF NOT EXISTS settings_kv (
      key TEXT PRIMARY KEY,
      value TEXT
    );
    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      vat_number TEXT,
      email TEXT,
      phone TEXT,
      address TEXT,
      notes TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS purchase_orders (
      id TEXT PRIMARY KEY,
      number INTEGER,
      date TEXT,
      supplier_id TEXT,
      supplier_name TEXT,
      status TEXT NOT NULL DEFAULT 'bozza',
      items_json TEXT NOT NULL DEFAULT '[]',
      total REAL,
      notes TEXT,
      user TEXT,
      created_at TEXT,
      received_at TEXT
    );
    CREATE TABLE IF NOT EXISTS dues (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      party_type TEXT,
      party_id TEXT,
      party_name TEXT,
      ref_type TEXT,
      ref_id TEXT,
      ref_label TEXT,
      description TEXT,
      amount REAL NOT NULL,
      paid REAL NOT NULL DEFAULT 0,
      due_date TEXT NOT NULL,
      payments_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT,
      closed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS product_variants (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL,
      size TEXT,
      color TEXT,
      barcode TEXT,
      qty INTEGER NOT NULL DEFAULT 0,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS quotes (
      id TEXT PRIMARY KEY,
      number INTEGER,
      date TEXT,
      customer_id TEXT,
      customer_name TEXT,
      status TEXT NOT NULL DEFAULT 'bozza',
      items_json TEXT NOT NULL DEFAULT '[]',
      subtotal REAL, discount REAL, tax REAL, total REAL,
      valid_until TEXT,
      notes TEXT,
      user TEXT,
      created_at TEXT,
      converted_sale_id TEXT
    );
    CREATE TABLE IF NOT EXISTS returns (
      id TEXT PRIMARY KEY,
      number INTEGER,
      date TEXT,
      sale_id TEXT NOT NULL,
      sale_number INTEGER,
      customer_id TEXT,
      customer_name TEXT,
      items_json TEXT NOT NULL DEFAULT '[]',
      total REAL,
      reason TEXT,
      refund_method TEXT,
      user TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS product_barcodes (
      barcode TEXT PRIMARY KEY,
      product_id TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_pbarcodes_product ON product_barcodes(product_id);
    CREATE INDEX IF NOT EXISTS idx_dues_due ON dues(due_date);
    CREATE INDEX IF NOT EXISTS idx_movements_created ON movements(created_at);
    CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(date);
    CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
    CREATE INDEX IF NOT EXISTS idx_products_nfc ON products(nfc_uid);
    CREATE INDEX IF NOT EXISTS idx_po_date ON purchase_orders(date);
    CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id);
    CREATE INDEX IF NOT EXISTS idx_variants_barcode ON product_variants(barcode);
    CREATE INDEX IF NOT EXISTS idx_quotes_date ON quotes(date);
    CREATE INDEX IF NOT EXISTS idx_returns_sale ON returns(sale_id);
`

// Crea le tabelle mancanti e aggiunge le colonne introdotte dopo la prima versione.
// Va applicata all'avvio e a ogni database importato da un backup (che può venire
// da una versione precedente e non avere le tabelle o le colonne più recenti).
function ensureColumn(raw, table, column, type) {
  const cols = raw.exec(`PRAGMA table_info(${table})`)[0].values.map(r => r[1])
  if (!cols.includes(column)) raw.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`)
}

function applySchema(raw) {
  raw.exec(SCHEMA_SQL)
  ensureColumn(raw, 'products',  'cost',          'REAL')     // 2.2: costo d'acquisto
  ensureColumn(raw, 'customers', 'vat_number',    'TEXT')     // 2.2
  ensureColumn(raw, 'products',  'min_stock',     'INTEGER')  // 2.3: scorta minima
  ensureColumn(raw, 'products',  'reorder_qty',   'INTEGER')  // 2.3: quantità di riordino
  ensureColumn(raw, 'products',  'supplier_id',   'TEXT')     // 2.3: fornitore abituale
  ensureColumn(raw, 'suppliers', 'payment_days',  'INTEGER')  // 2.3: giorni di pagamento
  ensureColumn(raw, 'sales',     'quote_id',      'TEXT')     // 2.4: vendita nata da un preventivo
}

// Async: va chiamata una sola volta all'avvio del server, con un await prima di app.listen().
async function initDatabase(filePath, legacyJsonPaths) {
  dbFilePath = filePath
  const isNew = !fs.existsSync(filePath)

  const wasmPath = path.join(path.dirname(require.resolve('sql.js')), 'sql-wasm.wasm')
  SQL = await initSqlJs({ locateFile: () => wasmPath })

  rawDb = isNew ? new SQL.Database() : new SQL.Database(fs.readFileSync(filePath))
  db = wrapDb(rawDb)

  applySchema(rawDb)

  if (isNew) migrateFromJson(legacyJsonPaths)

  persist()
  return db
}

// Importa i dati dai vecchi file JSON, una volta sola, se il database SQLite non esiste ancora.
function migrateFromJson({ dbJsonPath, suppJsonPath }) {
  const legacyDb   = fs.existsSync(dbJsonPath)   ? JSON.parse(fs.readFileSync(dbJsonPath, 'utf8'))   : {}
  const legacySupp = fs.existsSync(suppJsonPath) ? JSON.parse(fs.readFileSync(suppJsonPath, 'utf8')) : {}

  const insProduct = db.prepare(`INSERT INTO products (id,name,barcode,nfc_uid,qty,unit,price,category,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`)
  for (const p of legacyDb.products || [])
    insProduct.run(p.id, p.name, p.barcode || null, p.nfc_uid || null, p.qty || 0, p.unit || 'pz', p.price ?? null, p.category || null, p.notes || null, p.created_at || null)

  const insMovement = db.prepare(`INSERT INTO movements (id,product_id,product_name,type,qty,notes,user,created_at) VALUES (?,?,?,?,?,?,?,?)`)
  for (const m of legacyDb.movements || [])
    insMovement.run(m.id, m.product_id || null, m.product_name || null, m.type || null, m.qty || 0, m.notes || null, m.user || null, m.created_at || null)

  const insCustomer = db.prepare(`INSERT INTO customers (id,name,email,phone,address,notes,created_at) VALUES (?,?,?,?,?,?,?)`)
  for (const c of legacyDb.customers || [])
    insCustomer.run(c.id, c.name, c.email || null, c.phone || null, c.address || null, c.notes || null, c.created_at || null)

  const insSale = db.prepare(`INSERT INTO sales (id,number,date,customer_id,customer_name,items_json,subtotal,discount,tax,total,payment_method,payment_other,notes,user,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
  for (const s of legacySupp.sales || [])
    insSale.run(s.id, s.number || 0, s.date || null, s.customer_id || null, s.customer_name || null, JSON.stringify(s.items || []), s.subtotal || 0, s.discount || 0, s.tax || 0, s.total || 0, s.payment_method || null, s.payment_other || null, s.notes || null, s.user || null, s.created_at || null)

  const insUser = db.prepare(`INSERT INTO users (id,username,email,password,role) VALUES (?,?,?,?,?)`)
  for (const u of legacySupp.users || [])
    insUser.run(u.id, u.username, u.email || null, u.password, u.role || 'Operatore')

  const setKv = db.prepare(`INSERT OR REPLACE INTO settings_kv (key,value) VALUES (?,?)`)
  for (const [k, v] of Object.entries(legacySupp.settings || {})) setKv.run(k, JSON.stringify(v))
  setKv.run('_ai_config', JSON.stringify(legacySupp.ai || {}))
  setKv.run('_ui_config', JSON.stringify(legacySupp.uiConfig || {}))
  setKv.run('_cash_register', JSON.stringify(legacySupp.cashRegister || {}))
  setKv.run('_sale_counter', String(legacySupp.saleCounter || 0))

  console.log(`Migrazione da JSON completata: ${(legacyDb.products||[]).length} prodotti, ${(legacyDb.movements||[]).length} movimenti, ${(legacyDb.customers||[]).length} clienti, ${(legacySupp.sales||[]).length} vendite, ${(legacySupp.users||[]).length} utenti`)
}

function getDb() {
  if (!db) throw new Error('Database non inizializzato')
  return db
}

// ── Backup / ripristino ──────────────────────────────────────────────────────
const REQUIRED_TABLES = ['products', 'movements', 'customers', 'sales', 'users', 'settings_kv']

// Contenuto attuale del database come file .sqlite (scritto su disco e riletto,
// così il backup è identico a ciò che resterebbe dopo un riavvio).
function exportDatabase() {
  persist()
  return fs.readFileSync(dbFilePath)
}

// Sostituisce il database in uso con quello contenuto in `buffer`, dopo averlo validato.
// Prima di sovrascrivere salva una copia di sicurezza (gesclo.sqlite.pre-restore.bak).
function replaceDatabase(buffer) {
  let candidate
  try {
    candidate = new SQL.Database(buffer)
    const rows   = candidate.exec("SELECT name FROM sqlite_master WHERE type = 'table'")
    const tables = rows.length ? rows[0].values.map(r => r[0]) : []
    const missing = REQUIRED_TABLES.filter(t => !tables.includes(t))
    if (missing.length) throw new Error('Il file non è un backup di GesClo (mancano: ' + missing.join(', ') + ')')
    if (candidate.exec('SELECT COUNT(*) FROM users')[0].values[0][0] === 0)
      throw new Error('Il backup non contiene utenti: dopo il ripristino nessuno potrebbe accedere')
    applySchema(candidate)
  } catch (e) {
    try { candidate && candidate.close() } catch {}
    if (/not a database|malformed|file is encrypted/i.test(e.message)) throw new Error('Il file non è un database SQLite valido')
    throw e
  }

  if (persistTimer) { clearTimeout(persistTimer); persistTimer = null }
  persist()
  fs.copyFileSync(dbFilePath, dbFilePath + '.pre-restore.bak')
  rawDb.close()
  rawDb = candidate
  db    = wrapDb(rawDb)
  persist()
}

// ── Helper per settings_kv (chiave/valore generiche + blob speciali) ─────────
function kvGet(key, fallback) {
  const row = db.prepare('SELECT value FROM settings_kv WHERE key = ?').get(key)
  if (row === undefined) return fallback
  try { return JSON.parse(row.value) } catch { return row.value }
}
function kvSet(key, value) {
  db.prepare('INSERT OR REPLACE INTO settings_kv (key,value) VALUES (?,?)').run(key, JSON.stringify(value))
}

module.exports = { initDatabase, getDb, persist, kvGet, kvSet, exportDatabase, replaceDatabase }
