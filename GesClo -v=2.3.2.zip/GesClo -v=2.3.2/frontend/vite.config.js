import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  // Percorsi relativi: la build viene caricata da Electron via file://, non da un server HTTP.
  base: './',
  server: { host: '0.0.0.0', port: 3000 }
})
