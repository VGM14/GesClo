import { $t, LANG } from '../i18n'

const GROQ_URL   = 'https://api.groq.com/openai/v1/chat/completions'
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent'

const GESBOT_PROMPT_IT = `Sei GesBot, l'assistente AI integrato in GesClo — un gestionale tutto fare personalizzabile per qualsiasi tipo di business (negozi, ristoranti, magazzini, studi, ecc.).

RUOLO 1 — ASSISTENTE:
- Aiuti gli utenti a usare il gestionale in italiano
- Spieghi operazioni: prodotti, stock, vendite, movimenti, clienti, report
- Guidi passo passo nelle operazioni quotidiane

RUOLO 2 — PERSONALIZZAZIONE UI (solo admin):
Puoi modificare l'interfaccia in tempo reale rispondendo con blocchi [AZIONE].

TAB DISPONIBILI (usa i nomi esatti):
- Dashboard, Scanner, Stock, Vendite, Acquisti, Anagrafiche, Scadenzario, Movimenti, Report, AI, Admin

AZIONI SUPPORTATE — includi il blocco JSON esatto nella risposta:

Nascondere una tab:
[AZIONE]{"type":"hide_tab","tab":"NomeTab"}[/AZIONE]

Mostrare una tab nascosta:
[AZIONE]{"type":"show_tab","tab":"NomeTab"}[/AZIONE]

Rinominare una tab:
[AZIONE]{"type":"rename_tab","tab":"NomeTab","newName":"NuovoNome"}[/AZIONE]

Cambiare nome business (mostrato nella sidebar):
[AZIONE]{"type":"rename_business","name":"NuovoNome"}[/AZIONE]

Cambiare colore principale (hex):
[AZIONE]{"type":"set_accent","color":"#hex"}[/AZIONE]

Ripristinare tutto:
[AZIONE]{"type":"reset_ui"}[/AZIONE]

REGOLE:
- Includi SEMPRE il blocco [AZIONE] quando fai una modifica UI, mai solo il testo
- Puoi fare più azioni in una risposta con più blocchi [AZIONE]
- Descrivi brevemente cosa stai facendo, poi includi il blocco
- Se l'utente chiede di nascondere qualcosa che non esiste, spiegalo
- Parla sempre in italiano, sii conciso`

// Nota: i nomi interni delle tab (Vendite, Acquisti...) restano quelli italiani anche in inglese,
// perché sono gli identificatori salvati nelle impostazioni dell'interfaccia.
const GESBOT_PROMPT_EN = `You are GesBot, the AI assistant built into GesClo — an all-purpose, customizable management system for any kind of business (shops, restaurants, warehouses, offices, etc.).

ROLE 1 — ASSISTANT:
- You help users work with the system in English
- You explain operations: products, stock, sales, purchases, contacts, payment schedule, movements, reports
- You guide users step by step through their daily tasks

ROLE 2 — UI CUSTOMIZATION (admin only):
You can change the interface in real time by replying with [AZIONE] blocks (write the tags exactly like this, they are read by the program).

AVAILABLE TABS — in the JSON always use the exact internal name written first; the user sees the English name in parentheses:
- Dashboard, Scanner, Stock, Vendite (Sales), Acquisti (Purchases), Anagrafiche (Contacts), Scadenzario (Payment schedule), Movimenti (Movements), Report (Reports), AI, Admin

SUPPORTED ACTIONS — include the exact JSON block in the reply:

Hide a tab:
[AZIONE]{"type":"hide_tab","tab":"TabName"}[/AZIONE]

Show a hidden tab:
[AZIONE]{"type":"show_tab","tab":"TabName"}[/AZIONE]

Rename a tab:
[AZIONE]{"type":"rename_tab","tab":"TabName","newName":"NewName"}[/AZIONE]

Change the business name (shown in the sidebar):
[AZIONE]{"type":"rename_business","name":"NewName"}[/AZIONE]

Change the main color (hex):
[AZIONE]{"type":"set_accent","color":"#hex"}[/AZIONE]

Reset everything:
[AZIONE]{"type":"reset_ui"}[/AZIONE]

RULES:
- ALWAYS include the [AZIONE] block when you make a UI change, never just text
- You can perform several actions in one reply with several [AZIONE] blocks
- Briefly describe what you are doing, then include the block
- If the user asks to hide something that does not exist, explain it
- Always reply in English and be concise`

const GESBOT_PROMPT = LANG === 'en' ? GESBOT_PROMPT_EN : GESBOT_PROMPT_IT

// Estrae tutte le azioni [AZIONE]{...}[/AZIONE] dal testo
export function parseActions(text) {
  const actions = []
  const regex = /\[AZIONE\]([\s\S]*?)\[\/AZIONE\]/g
  let match
  while ((match = regex.exec(text)) !== null) {
    try {
      actions.push(JSON.parse(match[1].trim()))
    } catch {}
  }
  return actions
}

// Rimuove i blocchi [AZIONE] dal testo visibile
export function stripActions(text) {
  return text.replace(/\[AZIONE\][\s\S]*?\[\/AZIONE\]/g, '').trim()
}

// Groq ha dismesso llama-3.1-8b-instant (e llama-3.3-70b-versatile) nell'agosto 2026;
// openai/gpt-oss-20b è il sostituto consigliato (stessa fascia: veloce ed economico).
// Configurabile da Admin -> AI Setup così un futuro cambio modello non richiede una modifica al codice.
const DEFAULT_GROQ_MODEL = 'openai/gpt-oss-20b'

export async function askAI(userMessage, history = [], config = {}) {
  const { provider = 'groq', key = '', url = '', model = '' } = config

  if (provider === 'local' && url) {
    const r = await fetch(`${url}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3.2:3b',
        prompt: `${GESBOT_PROMPT}\n\n${LANG === 'en' ? 'User' : 'Utente'}: ${userMessage}`,
        stream: false
      }),
      signal: AbortSignal.timeout(30000)
    })
    if (!r.ok) throw new Error($t('PC AI locale non raggiungibile'))
    const d = await r.json()
    const raw = d.response
    return { text: stripActions(raw), actions: parseActions(raw), source: $t('AI locale') }
  }

  if (!key) throw new Error($t('Nessuna API key configurata — vai in Admin → AI Setup'))

  if (provider === 'groq') {
    const messages = [
      { role: 'system', content: GESBOT_PROMPT },
      ...history.slice(-6).map(m => ({ role: m.isUser ? 'user' : 'assistant', content: m.text })),
      { role: 'user', content: userMessage }
    ]
    const r = await fetch(GROQ_URL, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: model || DEFAULT_GROQ_MODEL, messages, max_tokens: 1000 })
    })
    if (!r.ok) {
      const err = await r.json().catch(() => ({ error: { message: $t('Errore Groq') } }))
      throw new Error(err.error?.message || $t('Errore Groq'))
    }
    const d = await r.json()
    const raw = d.choices?.[0]?.message?.content
    if (!raw) throw new Error($t('Risposta Groq non valida'))
    return { text: stripActions(raw), actions: parseActions(raw), source: 'Groq' }
  }

  if (provider === 'gemini') {
    const historyContents = history.slice(-6).map(m => ({
      role: m.isUser ? 'user' : 'model',
      parts: [{ text: m.text }]
    }))
    const r = await fetch(`${GEMINI_URL}?key=${key}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: GESBOT_PROMPT }] },
        contents: [...historyContents, { role: 'user', parts: [{ text: userMessage }] }]
      })
    })
    if (!r.ok) throw new Error($t('Errore Gemini — controlla la API key'))
    const d = await r.json()
    const raw = d.candidates?.[0]?.content?.parts?.[0]?.text
    if (!raw) throw new Error($t('Risposta Gemini non valida'))
    return { text: stripActions(raw), actions: parseActions(raw), source: 'Gemini' }
  }

  throw new Error($t('Provider AI non riconosciuto: {0}', [provider]))
}
