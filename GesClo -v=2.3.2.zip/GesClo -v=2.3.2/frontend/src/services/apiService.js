// GesClo API Service — autenticazione locale

import { $t, LANG } from '../i18n'

const TOKEN_KEY = 'gesclo_token'

export function getAuthToken() {
  return localStorage.getItem(TOKEN_KEY) || ''
}

function setAuthToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token)
  else localStorage.removeItem(TOKEN_KEY)
}

// L'app desktop carica la UI da file:// (non da http://), quindi window.location.hostname
// è vuoto — in quel caso il server API è sempre sulla stessa macchina, su 'localhost'.
function getHost() {
  return window.location.hostname || 'localhost'
}

function getApiBase() {
  const stored = localStorage.getItem('gesclo_server')
  if (stored) {
    try { return `http://${new URL(stored).hostname}:3001` } catch {}
  }
  // Auto-detect: usa lo stesso host del frontend
  // → localhost:3000 → localhost:3001
  // → 192.168.1.5:3000 → 192.168.1.5:3001 (accesso da altro dispositivo LAN)
  return `http://${getHost()}:3001`
}

// ── MODALITÀ OPERATIVA (Standalone / Network Server / Network Terminal) ──────
// Impostazione locale al dispositivo (localStorage), non condivisa via server:
// macchine diverse sulla stessa rete possono avere modalità diverse.
// Standalone/Server: il server gira su questa macchina, si usa 'localhost'.
// Terminal: nessun server locale, le richieste vanno a un indirizzo remoto salvato.
const MODE_KEY = 'gesclo_mode'
export const OPERATING_MODES = ['Standalone', 'Network Server', 'Network Terminal']

export function getMode() {
  return localStorage.getItem(MODE_KEY) || OPERATING_MODES[0]
}

export function setOperatingMode(mode, serverIp) {
  localStorage.setItem(MODE_KEY, mode)
  if (mode === 'Network Terminal' && serverIp) localStorage.setItem('gesclo_server', serverIp)
  else localStorage.removeItem('gesclo_server')
}

// Interroga il server LOCALE (questa macchina) per il suo IP di rete — usato in
// modalità Server per mostrare all'admin l'indirizzo da dare ai terminali.
export function getNetworkInfo() {
  return fetch(`http://${getHost()}:3001/api/system/network-info`, { signal: AbortSignal.timeout(3000) })
    .then(r => r.ok ? r.json() : Promise.reject(new Error('no response')))
}

async function request(path, method = 'GET', body = null) {
  const token = getAuthToken()
  const res = await fetch(`${getApiBase()}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-Lang': LANG, // il server risponde con gli errori nella lingua dell'interfaccia
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    },
    body: body ? JSON.stringify(body) : null
  })
  if (res.status === 401) {
    setAuthToken(null)
    window.dispatchEvent(new Event('gesclo:unauthorized'))
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: $t('Errore server') }))
    throw new Error(err.error || $t('Errore {0}', [res.status]))
  }
  return res.json()
}

// ── BACKUP / RIPRISTINO (solo Super Admin) ───────────────────
async function rawErrorMessage(res) {
  const err = await res.json().catch(() => ({}))
  return err.error || $t('Errore {0}', [res.status])
}

// Scarica gesclo.sqlite come file (con la data nel nome).
export async function downloadBackup() {
  const res = await fetch(`${getApiBase()}/api/admin/backup`, {
    headers: { Authorization: `Bearer ${getAuthToken()}`, 'X-Lang': LANG }
  })
  if (!res.ok) throw new Error(await rawErrorMessage(res))
  const url = URL.createObjectURL(await res.blob())
  const a = document.createElement('a')
  a.href = url
  a.download = `gesclo-backup-${new Date().toISOString().slice(0, 10)}.sqlite`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

// Carica un file .sqlite e sostituisce il database. Il server invalida tutte le sessioni:
// dopo il ripristino serve un nuovo login.
export async function restoreBackup(file) {
  const res = await fetch(`${getApiBase()}/api/admin/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream', Authorization: `Bearer ${getAuthToken()}`, 'X-Lang': LANG },
    body: file
  })
  if (!res.ok) throw new Error(await rawErrorMessage(res))
  setAuthToken(null)
}

// ── AUTENTICAZIONE ────────────────────────────────────────────
export async function login(username, password) {
  const data = await request('/api/login', 'POST', { username, password })
  setAuthToken(data.token)
  return data
}

export const getSetupStatus = () => request('/api/setup/status')

export async function setupAdmin(username, email, password) {
  const data = await request('/api/setup', 'POST', { username, email, password })
  setAuthToken(data.token)
  return data
}

export async function logout() {
  try { await request('/api/logout', 'POST') } catch {}
  setAuthToken(null)
}

export const getMe = () => request('/api/me')

// ── PRODOTTI ──────────────────────────────────────────────────
export const getProducts = () => request('/api/products')
export const addProduct = (data) => request('/api/products', 'POST', data)
export const updateProduct = (id, data) => request(`/api/products/${id}`, 'PUT', data)
export const deleteProduct = (id) => request(`/api/products/${id}`, 'DELETE')
export const findByBarcode = (barcode) => request(`/api/products/barcode/${encodeURIComponent(barcode)}`)

// ── MOVIMENTI ─────────────────────────────────────────────────
export const getMovements = () => request('/api/movements')
export const addMovement = (data) => request('/api/movements', 'POST', data)

// ── CLIENTI ──────────────────────────────────────────────────
export const getCustomers = () => request('/api/customers')
export const addCustomer = (data) => request('/api/customers', 'POST', data)
export const updateCustomer = (id, data) => request(`/api/customers/${id}`, 'PUT', data)
export const deleteCustomer = (id) => request(`/api/customers/${id}`, 'DELETE')

// ── VENDITE ──────────────────────────────────────────────────
export const getSales = () => request('/api/sales')
export const addSale = (data) => request('/api/sales', 'POST', data)
export const clearSales = () => request('/api/sales', 'DELETE')
export const deleteSale = (id) => request(`/api/sales/${id}`, 'DELETE')

// ── FORNITORI E ACQUISTI ─────────────────────────────────────
export const getSuppliers = () => request('/api/suppliers')
export const addSupplier = (data) => request('/api/suppliers', 'POST', data)
export const updateSupplier = (id, data) => request(`/api/suppliers/${id}`, 'PUT', data)
export const deleteSupplier = (id) => request(`/api/suppliers/${id}`, 'DELETE')

export const getPurchaseOrders = () => request('/api/purchase-orders')
export const addPurchaseOrder = (data) => request('/api/purchase-orders', 'POST', data)
export const updatePurchaseOrder = (id, data) => request(`/api/purchase-orders/${id}`, 'PUT', data)
export const receivePurchaseOrder = (id) => request(`/api/purchase-orders/${id}/receive`, 'POST')
export const cancelPurchaseOrder = (id) => request(`/api/purchase-orders/${id}/cancel`, 'POST')
export const deletePurchaseOrder = (id) => request(`/api/purchase-orders/${id}`, 'DELETE')

// ── RIORDINO, SCADENZARIO, INVENTARIO, IMPORT, STORICO ───────
export const getReorderSuggestions = () => request('/api/reorder/suggestions')
export const createReorderOrders = (productIds) => request('/api/reorder/create-orders', 'POST', productIds ? { product_ids: productIds } : {})

export const getDues = (kind, status) => request(`/api/dues?kind=${kind || ''}&status=${status || ''}`)
export const getDuesSummary = () => request('/api/dues/summary')
export const addDue = (data) => request('/api/dues', 'POST', data)
export const updateDue = (id, data) => request(`/api/dues/${id}`, 'PUT', data)
export const payDue = (id, data) => request(`/api/dues/${id}/pay`, 'POST', data)
export const deleteDue = (id) => request(`/api/dues/${id}`, 'DELETE')

export const applyInventory = (counts, notes) => request('/api/inventory/apply', 'POST', { counts, notes })

export const importRows = (kind, rows) => request(`/api/import/${kind}`, 'POST', { rows })

export const getCustomerHistory = (id) => request(`/api/customers/${id}/history`)
export const getSupplierHistory = (id) => request(`/api/suppliers/${id}/history`)

// ── REPORT ───────────────────────────────────────────────────
export const getReportSummary = (from, to) => request(`/api/reports/summary?from=${encodeURIComponent(from || '')}&to=${encodeURIComponent(to || '')}`)

// ── IMPOSTAZIONI ──────────────────────────────────────────────
export const getSettings = () => request('/api/settings')
export const saveSetting = (key, value) => request('/api/settings', 'POST', { key, value })

// ── STATS ─────────────────────────────────────────────────────
export const getStats = () => request('/api/stats')

// ── CASSA ────────────────────────────────────────────────────
export const getCashRegister = () => request('/api/cash-register')
export const updateCashRegister = (data) => request('/api/cash-register', 'PUT', data)
export const updateProductPrice = (id, price) => request(`/api/products/${id}`, 'PUT', { price })

// ── CONFIGURAZIONE AI ─────────────────────────────────────────
export const getAIConfig  = ()     => request('/api/settings/ai')
export const saveAIConfig = (data) => request('/api/settings/ai', 'POST', data)

// ── CONFIGURAZIONE UI (personalizzazione via AI) ──────────────
export const getUIConfig  = ()     => request('/api/ui-config')
export const saveUIConfig = (data) => request('/api/ui-config', 'POST', data)

// ── CONTROLLO SERVER ─────────────────────────────────────────
export const stopServer      = () => request('/api/admin/server/stop',      'POST')
export const restartServer   = () => request('/api/admin/server/restart',   'POST')
export const closeAll        = () => request('/api/admin/server/close-all', 'POST')
export const shutdownServer  = () => request('/api/admin/server/shutdown',  'POST')

// ── POS ANDROID ──────────────────────────────────────────────
export const posRequest = (amount, saleId, items) => request('/api/pos/request', 'POST', { amount, saleId, items })
export const posCancel  = () => request('/api/pos/cancel', 'POST')

// ── HEALTH (no auth) ─────────────────────────────────────────
export function checkHealth() {
  return fetch(`${getApiBase()}/health`, { signal: AbortSignal.timeout(3000) })
    .then(r => r.ok ? r.json() : Promise.reject(new Error('no response')))
}

// ── LAUNCHER (porta 3002, no auth) ───────────────────────────
export function checkLauncher() {
  return fetch(`http://${getHost()}:3002/health`, { signal: AbortSignal.timeout(2000) })
    .then(r => r.ok ? r.json() : Promise.reject(new Error('no response')))
}

export function launchServer() {
  return fetch(`http://${getHost()}:3002/launch`, { method: 'POST', signal: AbortSignal.timeout(5000) })
    .then(r => r.ok ? r.json() : Promise.reject(new Error('launch failed')))
}

// ── WEBSOCKET TERMINAL (URL builder) ─────────────────────────
export function getTerminalWsUrl() {
  return `ws://${getHost()}:3001/ws/terminal`
}

// ── RISORSE SISTEMA ──────────────────────────────────────────
export const getSystemResources = () => request('/api/system/resources')

// ── NFC ───────────────────────────────────────────────────────
export function getNfcStreamUrl() {
  return `${getApiBase()}/api/nfc/stream`
}
export const getNfcLast = () => request('/api/nfc/last')

// ── UTENTI ────────────────────────────────────────────────────
export const getUsers = () => request('/api/users')
export const addUser = (data) => request('/api/users', 'POST', data)
export const updateUser = (id, data) => request(`/api/users/${id}`, 'PUT', data)
export const deleteUser = (id) => request(`/api/users/${id}`, 'DELETE')
