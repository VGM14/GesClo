import React, { useState, useEffect, useRef, useCallback } from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import ErrorBoundary from './components/ErrorBoundary'
import { getAuthToken, getMe, getSetupStatus, logout as apiLogout, getUIConfig, saveUIConfig, getNfcStreamUrl } from './services/apiService'
import Login from './pages/Login'
import Setup from './pages/Setup'
import WhatsNew from './components/WhatsNew'
import { APP_VERSION, getUnseenChangelog } from './changelog'

const SEEN_VERSION_KEY = 'gesclo_last_seen_version'
const markVersionSeen = () => { try { localStorage.setItem(SEEN_VERSION_KEY, APP_VERSION) } catch {} }
import Dashboard from './pages/Dashboard'
import Admin from './pages/Admin'
import Stock from './pages/Stock'
import Scanner from './pages/Scanner'
import Movements from './pages/Movements'
import Reports from './pages/Reports'
import AIPage from './pages/AIPage'
import Sales from './pages/Sales'
import Purchases from './pages/Purchases'
import Contacts from './pages/Contacts'
import Dues from './pages/Dues'
import { $t } from './i18n'

export default function App() {
  const location = useLocation()
  const [dark, setDark] = useState(true)
  const [authChecked, setAuthChecked] = useState(false)
  const [authUser, setAuthUser] = useState(null) // { username, role } oppure null
  const [needsSetup, setNeedsSetup] = useState(false) // true finché non esiste nessun utente
  const [whatsNew, setWhatsNew] = useState(null) // voci del changelog da mostrare dopo un aggiornamento
  const isSignedIn = !!authUser
  const [unlocked, setUnlocked] = useState(new Set())
  const [uiConfig, setUiConfigState] = useState({})
  const [lastNfcScan, setLastNfcScan] = useState(null)
  const [nfcToast, setNfcToast] = useState(null)
  const nfcEsRef = useRef(null)
  const nfcToastTimer = useRef(null)

  // Ripristina la sessione da un token salvato (se ancora valido sul server)
  useEffect(() => {
    // Server non raggiungibile → si mostra comunque il login (dove si può cambiare indirizzo)
    getSetupStatus().catch(() => ({ needsSetup: false })).then(({ needsSetup }) => {
      if (needsSetup) { setNeedsSetup(true); setAuthChecked(true); return }
      if (!getAuthToken()) { setAuthChecked(true); return }
      getMe()
        .then(me => setAuthUser({ username: me.name, role: me.role }))
        .catch(() => setAuthUser(null))
        .finally(() => setAuthChecked(true))
    })
  }, [])

  // Se il server rifiuta il token (scaduto/riavviato), torna al login
  useEffect(() => {
    const onUnauthorized = () => setAuthUser(null)
    window.addEventListener('gesclo:unauthorized', onUnauthorized)
    return () => window.removeEventListener('gesclo:unauthorized', onUnauthorized)
  }, [])

  const handleLogout = useCallback(() => { apiLogout(); setAuthUser(null) }, [])

  // Popup "Novità" al primo accesso dopo un aggiornamento (ultima versione vista salvata
  // per dispositivo). Su un'installazione nuova lo imposta la schermata di primo avvio.
  useEffect(() => {
    if (!isSignedIn) return
    let last = null
    try { last = localStorage.getItem(SEEN_VERSION_KEY) } catch {}
    const unseen = getUnseenChangelog(last)
    if (unseen.length) setWhatsNew(unseen)
  }, [isSignedIn])

  const closeWhatsNew = useCallback(() => { markVersionSeen(); setWhatsNew(null) }, [])

  // SSE NFC — connette al server per ricevere eventi in tempo reale
  useEffect(() => {
    if (!isSignedIn) return
    let es
    const connect = () => {
      es = new EventSource(getNfcStreamUrl(), { withCredentials: false })
      es.onmessage = e => {
        try {
          const data = JSON.parse(e.data)
          if (data.type === 'nfc_scan') {
            setLastNfcScan(data)
            const label = data.product
              ? $t("NFC: {0}", [data.product.name])
              : $t("NFC: {0} (non trovato)", [data.uid])
            setNfcToast({ label, product: data.product, uid: data.uid })
            clearTimeout(nfcToastTimer.current)
            nfcToastTimer.current = setTimeout(() => setNfcToast(null), 4000)
          }
        } catch {}
      }
      es.onerror = () => { es.close(); setTimeout(connect, 10000) }
      nfcEsRef.current = es
    }
    connect()
    return () => { es?.close(); clearTimeout(nfcToastTimer.current) }
  }, [isSignedIn])

  // Carica uiConfig dal server dopo il login
  useEffect(() => {
    if (!isSignedIn) return
    getUIConfig().then(cfg => {
      setUiConfigState(cfg || {})
      applyAccentColor(cfg?.accentColor)
    }).catch(() => {})
  }, [isSignedIn])

  // Applica colore accent come CSS variable
  function applyAccentColor(color) {
    if (color) document.documentElement.style.setProperty('--accent', color)
    else        document.documentElement.style.removeProperty('--accent')
  }

  // Esegui un'azione UI da GesBot e salva
  const applyUIAction = useCallback(async (action) => {
    setUiConfigState(prev => {
      const next = { ...prev }
      switch (action.type) {
        case 'hide_tab': {
          const hidden = new Set(next.hiddenTabs || [])
          hidden.add(action.tab)
          next.hiddenTabs = [...hidden]
          break
        }
        case 'show_tab': {
          next.hiddenTabs = (next.hiddenTabs || []).filter(t => t !== action.tab)
          break
        }
        case 'rename_tab': {
          next.tabAliases = { ...(next.tabAliases || {}), [action.tab]: action.newName }
          break
        }
        case 'rename_business': {
          next.businessName = action.name
          break
        }
        case 'set_accent': {
          next.accentColor = action.color
          applyAccentColor(action.color)
          break
        }
        case 'reset_ui': {
          applyAccentColor(null)
          return {}
        }
      }
      return next
    })
    // Salva sul server (fire-and-forget — la UI è già aggiornata localmente)
    try {
      const current = await getUIConfig()
      const merged = applyActionToConfig(current || {}, action)
      await saveUIConfig(merged)
    } catch {}
  }, [])

  const role = authUser?.role || 'Operatore'
  const isAdmin = role === 'Super Admin' || role === 'Admin'
  const unlock = (s) => setUnlocked(p => new Set([...p, s]))
  const isUnlocked = (s) => unlocked.has(s)

  const shared = {
    user: { username: authUser?.username || $t("Utente"), role },
    dark, setDark, isAdmin, unlock, isUnlocked,
    uiConfig, applyUIAction,
    lastNfcScan, setLastNfcScan,
    onLogout: handleLogout
  }

  if (!authChecked) {
    return <div className={dark ? 'dark' : ''} style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', color: 'var(--text3)', fontSize: 14 }}>{$t("Caricamento...")}</div>
  }

  if (needsSetup && !isSignedIn) {
    return <Setup onDone={(u) => { markVersionSeen(); setAuthUser(u); setNeedsSetup(false) }} dark={dark} setDark={setDark} />
  }

  if (!isSignedIn) {
    return <Login onLogin={setAuthUser} dark={dark} setDark={setDark} />
  }

  return (
    <div className={dark ? 'dark' : ''} style={{ minHeight: '100vh', background: 'var(--bg)', position: 'relative' }}>
      {whatsNew && <WhatsNew entries={whatsNew} onClose={closeWhatsNew} />}
      {/* Toast NFC */}
      {nfcToast && (
        <div style={{
          position: 'fixed', bottom: 24, right: 24, zIndex: 9999,
          background: nfcToast.product ? 'var(--success-bg)' : 'var(--warn-bg)',
          color:      nfcToast.product ? 'var(--success-text)' : 'var(--warn-text)',
          border:     `0.5px solid ${nfcToast.product ? 'var(--success-text)' : 'var(--warn-text)'}`,
          borderRadius: 12, padding: '10px 16px', fontSize: 13, fontWeight: 500,
          display: 'flex', alignItems: 'center', gap: 8, maxWidth: 320,
          boxShadow: '0 4px 20px rgba(0,0,0,0.3)'
        }}>
          <i className="ti ti-wifi" style={{ fontSize: 18, flexShrink: 0 }} />
          {nfcToast.label}
          <button onClick={() => setNfcToast(null)} style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'inherit', padding: 0, fontSize: 16, lineHeight: 1 }}>×</button>
        </div>
      )}
      <ErrorBoundary resetKey={location.pathname}>
      <Routes>
        <Route path="/" element={<Dashboard {...shared} />} />
        <Route path="/admin/*" element={isAdmin ? <Admin {...shared} /> : <Navigate to="/" />} />
        <Route path="/stock" element={<Stock {...shared} />} />
        <Route path="/scanner" element={<Scanner {...shared} />} />
        <Route path="/movements" element={<Movements {...shared} />} />
        <Route path="/reports" element={<Reports {...shared} />} />
        <Route path="/sales" element={<Sales {...shared} />} />
        <Route path="/purchases" element={<Purchases {...shared} />} />
        <Route path="/contacts" element={<Contacts {...shared} />} />
        <Route path="/dues" element={<Dues {...shared} />} />
        <Route path="/ai" element={<AIPage {...shared} />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      </ErrorBoundary>
    </div>
  )
}

// Funzione pura per applicare un'azione alla config (usata prima del salvataggio)
function applyActionToConfig(cfg, action) {
  const next = { ...cfg }
  switch (action.type) {
    case 'hide_tab': {
      const hidden = new Set(next.hiddenTabs || [])
      hidden.add(action.tab)
      next.hiddenTabs = [...hidden]
      break
    }
    case 'show_tab':
      next.hiddenTabs = (next.hiddenTabs || []).filter(t => t !== action.tab)
      break
    case 'rename_tab':
      next.tabAliases = { ...(next.tabAliases || {}), [action.tab]: action.newName }
      break
    case 'rename_business':
      next.businessName = action.name
      break
    case 'set_accent':
      next.accentColor = action.color
      break
    case 'reset_ui':
      return {}
  }
  return next
}
