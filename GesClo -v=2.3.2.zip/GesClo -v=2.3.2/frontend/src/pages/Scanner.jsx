import React, { useState, useRef, useEffect, useCallback } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import { findByBarcode, addMovement } from '../services/apiService'
import { $t } from '../i18n'

export default function Scanner(props) {
  const { lastNfcScan, setLastNfcScan } = props
  const [mode, setMode]               = useState('keyboard') // 'keyboard' | 'camera' | 'nfc'
  const [code, setCode]               = useState('')
  const [result, setResult]           = useState(null)
  const [loading, setLoading]         = useState(false)
  const [error, setError]             = useState('')
  const [movementModal, setMovementModal] = useState(false)
  const [movForm, setMovForm]         = useState({ type: 'uscita', qty: '1', notes: '' })
  const [saving, setSaving]           = useState(false)
  const [success, setSuccess]         = useState('')
  const [cameraActive, setCameraActive] = useState(false)
  const [cameraSupported, setCameraSupported] = useState(true)

  const videoRef    = useRef()
  const streamRef   = useRef()
  const detectorRef = useRef()
  const intervalRef = useRef()
  const inputRef    = useRef()

  // Controlla supporto BarcodeDetector
  useEffect(() => {
    setCameraSupported('BarcodeDetector' in window && !!navigator.mediaDevices?.getUserMedia)
    return () => stopCamera()
  }, [])

  // Focus automatico sull'input quando si è in modalità tastiera
  useEffect(() => {
    if (mode === 'keyboard') inputRef.current?.focus()
    if (mode === 'camera')   startCamera()
    else                      stopCamera()
  }, [mode])

  // Va definita PRIMA dell'effetto NFC qui sotto: l'array delle dipendenze viene letto
  // durante il render, e usare una const non ancora inizializzata dà un ReferenceError
  // (pagina bianca).
  const searchCode = useCallback(async (val) => {
    const q = (val || code).trim()
    if (!q) return
    setLoading(true); setError(''); setResult(null)
    try {
      const product = await findByBarcode(q)
      setResult(product)
    } catch(e) {
      setError((e.message === 'Prodotto non trovato' || e.message === $t("Prodotto non trovato")) ? $t("Nessun articolo con codice \"{0}\"", [q]) : e.message)
    }
    setLoading(false)
  }, [code])

  // Quando arriva un evento NFC e siamo in modalità NFC, cerca il codice
  useEffect(() => {
    if (mode !== 'nfc' || !lastNfcScan) return
    searchCode(lastNfcScan.uid)
    if (setLastNfcScan) setLastNfcScan(null)
  }, [lastNfcScan, mode, searchCode])

  // ── Fotocamera ───────────────────────────────────────────────
  const startCamera = async () => {
    if (!cameraSupported) {
      setError($t("Fotocamera non supportata su questo browser. Usa Chrome o Edge."))
      setMode('keyboard')
      return
    }
    setError('')
    try {
      detectorRef.current = new window.BarcodeDetector({
        formats: ['qr_code', 'ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'upc_e', 'aztec', 'data_matrix']
      })
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setCameraActive(true)

      intervalRef.current = setInterval(async () => {
        if (!videoRef.current || videoRef.current.readyState < 2) return
        try {
          const barcodes = await detectorRef.current.detect(videoRef.current)
          if (barcodes.length > 0) {
            const detected = barcodes[0].rawValue
            stopCamera()
            setMode('keyboard')
            setCode(detected)
            searchCode(detected)
          }
        } catch {}
      }, 250)
    } catch(e) {
      setError($t("Accesso fotocamera negato o non disponibile."))
      setMode('keyboard')
    }
  }

  const stopCamera = () => {
    clearInterval(intervalRef.current)
    streamRef.current?.getTracks().forEach(t => t.stop())
    streamRef.current = null
    setCameraActive(false)
  }

  // ── Movimento ────────────────────────────────────────────────
  const handleMovement = async () => {
    setSaving(true)
    try {
      await addMovement({ product_id: result.id, product_name: result.name, ...movForm, qty: parseInt(movForm.qty) || 1 })
      setSuccess($t("Movimento registrato! Stock aggiornato."))
      setMovementModal(false); setResult(null); setCode('')
      setTimeout(() => setSuccess(''), 3000)
    } catch(e) { setError(e.message) }
    setSaving(false)
  }

  const reset = () => { setResult(null); setCode(''); setError(''); inputRef.current?.focus() }

  return (
    <Layout {...props} title={$t("Scanner")}>
      <SectionLock section="scanner" {...props}>
        {success && <div style={{ background: 'var(--success-bg)', color: 'var(--success-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{success}</div>}
        {error   && <div style={{ background: 'var(--danger-bg)',  color: 'var(--danger-text)',  borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12, display: 'flex', justifyContent: 'space-between' }}>
          {error} <button onClick={() => setError('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger-text)' }}>×</button>
        </div>}

        <div style={{ maxWidth: 560 }}>
          {/* Selezione modalità */}
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            {[
              ['keyboard', 'ti-keyboard', $t("Tastiera / Scanner BT-USB")],
              ['camera',   'ti-camera',   $t("Fotocamera")],
              ['nfc',      'ti-wifi',     $t("NFC / Smart card")],
            ].map(([m, icon, label]) => (
              <button key={m} onClick={() => setMode(m)} style={{
                display: 'flex', alignItems: 'center', gap: 6, padding: '6px 14px',
                borderRadius: 20, fontSize: 12, cursor: 'pointer',
                border: `0.5px solid ${mode === m ? 'var(--accent)' : 'var(--border)'}`,
                background: mode === m ? 'var(--accent-bg)' : 'transparent',
                color: mode === m ? 'var(--accent-text)' : 'var(--text3)',
              }}>
                <i className={`ti ${icon}`} style={{ fontSize: 14 }} aria-hidden="true"></i>{label}
              </button>
            ))}
          </div>

          {/* Modalità tastiera / scanner BT-USB */}
          {mode === 'keyboard' && (
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px', marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
                <i className="ti ti-barcode" style={{ fontSize: 14 }} aria-hidden="true"></i>{$t("Scansiona o digita codice")}</div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  ref={inputRef}
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && searchCode()}
                  placeholder={$t("Scansiona con pistola BT/USB o digita il codice...")}
                  autoFocus
                  style={{ flex: 1 }}
                />
                <button onClick={() => searchCode()} disabled={loading} style={{
                  background: loading ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8,
                  padding: '0 16px', color: loading ? 'var(--text3)' : '#fff', fontSize: 13,
                  cursor: loading ? 'default' : 'pointer', fontWeight: 500
                }}>{loading ? '...' : $t("Cerca")}</button>
              </div>
              <div style={{ display: 'flex', gap: 16, marginTop: 10, fontSize: 11, color: 'var(--text3)' }}>
                <span><i className="ti ti-bluetooth" aria-hidden="true"></i>{" "}{$t("Scanner Bluetooth")}</span>
                <span><i className="ti ti-usb" aria-hidden="true"></i>{" "}{$t("Scanner USB")}</span>
                <span><i className="ti ti-keyboard" aria-hidden="true"></i>{" "}{$t("Tastiera manuale")}</span>
              </div>
            </div>
          )}

          {/* Modalità NFC / Smart card */}
          {mode === 'nfc' && (
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '24px 16px', marginBottom: 12, textAlign: 'center' }}>
              <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--info-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                <i className="ti ti-wifi" style={{ fontSize: 36, color: 'var(--info-text)' }} aria-hidden="true"></i>
              </div>
              <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--text)', marginBottom: 8 }}>{$t("In attesa di lettura NFC...")}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', lineHeight: 1.6 }}>{$t("Avvicina una carta NFC o smart card al lettore.")}<br />{$t("Funziona con: app Android GesClo NFC · lettore USB HID · lettore USB PC/SC")}</div>
              {lastNfcScan && (
                <div style={{ marginTop: 16, background: 'var(--bg3)', borderRadius: 8, padding: '8px 12px', fontSize: 12, fontFamily: 'monospace', color: 'var(--text)' }}>{$t("Ultimo tag:")}{" "}<b>{lastNfcScan.uid}</b> ({lastNfcScan.cardType})
                </div>
              )}
            </div>
          )}

          {/* Modalità fotocamera */}
          {mode === 'camera' && (
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
              {!cameraSupported ? (
                <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text3)', fontSize: 13 }}>
                  <i className="ti ti-camera-off" style={{ fontSize: 32, display: 'block', marginBottom: 8 }} aria-hidden="true"></i>{$t("Fotocamera non supportata.")}<br />{$t("Usa Chrome o Edge su Windows.")}</div>
              ) : (
                <>
                  <div style={{ position: 'relative', background: '#000', aspectRatio: '4/3' }}>
                    <video ref={videoRef} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} muted playsInline />
                    {/* mirino */}
                    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                      <div style={{ width: 200, height: 200, border: '2px solid var(--accent)', borderRadius: 12, boxShadow: '0 0 0 9999px rgba(0,0,0,0.45)' }} />
                    </div>
                    {cameraActive && (
                      <div style={{ position: 'absolute', top: 10, right: 10, background: 'var(--accent)', color: '#fff', borderRadius: 20, padding: '3px 10px', fontSize: 11, display: 'flex', alignItems: 'center', gap: 4 }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#fff', display: 'inline-block', animation: 'pulse 1s infinite' }} />{$t("In scansione")}</div>
                    )}
                  </div>
                  <div style={{ padding: '10px 14px', fontSize: 12, color: 'var(--text3)', textAlign: 'center' }}>{$t("Inquadra il barcode o QR code nel riquadro — rilevamento automatico")}</div>
                </>
              )}
            </div>
          )}

          {/* Risultato */}
          {result && (
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>{$t("Articolo trovato")}</div>
              {[[$t("Codice"), result.barcode || code], [$t("Nome"), result.name], [$t("Categoria"), result.category || '—'], [$t("Quantità"), `${result.qty} ${result.unit}`], [$t("Prezzo"), `€${parseFloat(result.price||0).toFixed(2)}`]].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '0.5px solid var(--border)', fontSize: 13 }}>
                  <span style={{ color: 'var(--text3)' }}>{l}</span>
                  <span style={{ color: 'var(--text)', fontWeight: 500 }}>{v}</span>
                </div>
              ))}
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button onClick={reset} style={{ flex: 1, border: '0.5px solid var(--border)', borderRadius: 8, padding: 8, fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Nuova scansione")}</button>
                <button onClick={() => setMovementModal(true)} style={{ flex: 2, background: 'var(--accent)', border: 'none', borderRadius: 8, padding: 8, fontSize: 13, color: '#fff', cursor: 'pointer', fontWeight: 500 }}>
                  <i className="ti ti-arrows-exchange" aria-hidden="true"></i>{" "}{$t("Registra movimento")}</button>
              </div>
            </div>
          )}
        </div>

        {/* Modal movimento */}
        {movementModal && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 14, padding: 22, width: 320 }}>
              <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 4 }}>{$t("Registra movimento")}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 14 }}>{result?.name}{" "}{$t("— stock:")}{" "}{result?.qty} {result?.unit}</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
                <div>
                  <label style={{ fontSize: 11, color: 'var(--text2)', display: 'block', marginBottom: 4 }}>{$t("Tipo")}</label>
                  <select value={movForm.type} onChange={e => setMovForm(p => ({ ...p, type: e.target.value }))} style={{ width: '100%' }}>
                    <option value="uscita">{$t("Uscita")}</option>
                    <option value="entrata">{$t("Entrata")}</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, color: 'var(--text2)', display: 'block', marginBottom: 4 }}>{$t("Quantità")}</label>
                  <input type="number" value={movForm.qty} onChange={e => setMovForm(p => ({ ...p, qty: e.target.value }))} min="1" style={{ width: '100%' }} />
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, color: 'var(--text2)', display: 'block', marginBottom: 4 }}>{$t("Note")}</label>
                <input value={movForm.notes} onChange={e => setMovForm(p => ({ ...p, notes: e.target.value }))} placeholder={$t("Opzionale...")} style={{ width: '100%' }} />
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setMovementModal(false)} style={{ flex: 1, border: '0.5px solid var(--border)', borderRadius: 8, padding: 8, fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Annulla")}</button>
                <button onClick={handleMovement} disabled={saving} style={{ flex: 2, background: saving ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8, padding: 8, fontSize: 13, color: saving ? 'var(--text3)' : '#fff', cursor: 'pointer', fontWeight: 500 }}>
                  {saving ? $t("Salvataggio...") : $t("Conferma")}
                </button>
              </div>
            </div>
          </div>
        )}

        <style>{$t("@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }")}</style>
      </SectionLock>
    </Layout>
  )
}
