import React, { useState, useRef, useEffect } from 'react'
import Layout from '../components/Layout'
import { getAIConfig } from '../services/apiService'
import { askAI } from '../services/aiService'
import { $t } from '../i18n'

const ACTION_LABELS = {
  hide_tab:        a => $t("Tab \"{0}\" nascosta", [a.tab]),
  show_tab:        a => $t("Tab \"{0}\" mostrata", [a.tab]),
  rename_tab:      a => $t("Tab \"{0}\" rinominata in \"{1}\"", [a.tab, a.newName]),
  rename_business: a => $t("Nome cambiato in \"{0}\"", [a.name]),
  set_accent:      a => $t("Colore principale cambiato"),
  reset_ui:        () => $t("Interfaccia ripristinata"),
}

export default function AIPage(props) {
  const { applyUIAction, isAdmin } = props
  const [messages, setMessages] = useState([
    { text: $t("Ciao! Sono GesBot. Posso aiutarti a usare il gestionale o personalizzare l'interfaccia. Cosa vuoi fare?"), isUser: false }
  ])
  const [input,    setInput]    = useState('')
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState('')
  const [aiConfig, setAiConfig] = useState(null)
  const bottomRef = useRef()

  useEffect(() => {
    getAIConfig()
      .then(setAiConfig)
      .catch(() => setAiConfig({ provider: 'groq', key: '', url: '' }))
  }, [])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = async () => {
    if (!input.trim() || loading) return
    const text = input
    setInput(''); setError('')
    setMessages(p => [...p, { text, isUser: true }])
    setLoading(true)
    try {
      const result = await askAI(text, messages, aiConfig || {})

      // Esegui azioni UI
      if (result.actions?.length && applyUIAction) {
        for (const action of result.actions) {
          await applyUIAction(action)
        }
      }

      setMessages(p => [...p, {
        text:    result.text,
        isUser:  false,
        source:  result.source,
        actions: result.actions || []
      }])
    } catch(e) { setError(e.message) }
    setLoading(false)
  }

  const quick = isAdmin
    ? [$t("Come aggiungo un prodotto?"), $t("Nascondi la tab Scanner"), $t("Cambia nome in \"MyShop\""), $t("Ripristina interfaccia")]
    : [$t("Come aggiungo un prodotto?"), $t("Come gestisco i movimenti?"), $t("Come uso lo scanner?"), $t("Come creo un cliente?")]

  return (
    <Layout {...props} title={$t("Assistente AI — GesBot")}>
      <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 130px)' }}>
        <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column', gap: 10, paddingBottom: 8 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: m.isUser ? 'flex-end' : 'flex-start' }}>
              <div style={{
                maxWidth: 540, padding: '10px 14px',
                borderRadius: m.isUser ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                fontSize: 13, lineHeight: 1.6,
                background: m.isUser ? 'var(--accent)' : 'var(--bg2)',
                color: m.isUser ? '#fff' : 'var(--text)',
                border: m.isUser ? 'none' : '0.5px solid var(--border)'
              }}>
                {m.text}

                {/* Badge azioni eseguite */}
                {m.actions?.length > 0 && (
                  <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
                    {m.actions.map((a, j) => (
                      <div key={j} style={{
                        display: 'inline-flex', alignItems: 'center', gap: 6,
                        background: 'var(--success-bg)', color: 'var(--success-text)',
                        borderRadius: 20, padding: '3px 10px', fontSize: 11
                      }}>
                        <i className="ti ti-check" style={{ fontSize: 12 }} aria-hidden="true"></i>
                        {ACTION_LABELS[a.type]?.(a) || a.type}
                      </div>
                    ))}
                  </div>
                )}

                {m.source && <div style={{ fontSize: 10, marginTop: 4, opacity: 0.6 }}>{$t("via")}{" "}{m.source}</div>}
              </div>
            </div>
          ))}

          {loading && (
            <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
              <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: '16px 16px 16px 4px', padding: '10px 14px', fontSize: 13, color: 'var(--text3)' }}>{$t("GesBot sta elaborando...")}</div>
            </div>
          )}
          {error && (
            <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 10, padding: '8px 12px', fontSize: 12 }}>
              {error}
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {messages.length === 1 && (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
            {quick.map(q => (
              <button key={q} onClick={() => setInput(q)} style={{
                background: 'var(--bg2)', border: '0.5px solid var(--border)',
                borderRadius: 20, padding: '5px 12px', fontSize: 12,
                color: 'var(--text2)', cursor: 'pointer'
              }}>{q}</button>
            ))}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, paddingTop: 10, borderTop: '0.5px solid var(--border)' }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
            placeholder={isAdmin ? $t("Chiedi a GesBot o dagli un comando UI...") : $t("Chiedi a GesBot...")}
            style={{ flex: 1, borderRadius: 20, padding: '9px 14px' }}
          />
          <button
            onClick={send}
            disabled={loading || !input.trim()}
            style={{
              background: loading || !input.trim() ? 'var(--bg3)' : 'var(--accent)',
              border: 'none', borderRadius: '50%', width: 38, height: 38,
              cursor: loading || !input.trim() ? 'default' : 'pointer',
              color: loading || !input.trim() ? 'var(--text3)' : '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
            }}
          >
            <i className="ti ti-send" style={{ fontSize: 16 }} aria-hidden="true"></i>
          </button>
        </div>
      </div>
    </Layout>
  )
}
