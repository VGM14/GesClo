import React, { useState, useEffect, useMemo } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import { getDues, addDue, updateDue, payDue, deleteDue, getCustomers, getSuppliers } from '../services/apiService'
import { $t, LOCALE, payLabel, dataText } from '../i18n'

const eur = (n) => Number(n || 0).toLocaleString(LOCALE, { style: 'currency', currency: 'EUR' })
const isoDay = (d) => d.toISOString().split('T')[0]
const today = () => isoDay(new Date())
const plusDays = (n) => { const d = new Date(); d.setUTCDate(d.getUTCDate() + n); return isoDay(d) }
const daysFromToday = (iso) => Math.round((Date.parse(iso + 'T00:00:00Z') - Date.parse(today() + 'T00:00:00Z')) / 86400000)

const METHODS = ['contanti', 'carta', 'bonifico', 'assegno', 'altro']

const card = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px' }
const label = { fontSize: 11, color: 'var(--text2)', display: 'block', marginBottom: 4 }
const btnGhost = { background: 'transparent', border: '0.5px solid var(--border)', borderRadius: 6, padding: '3px 9px', fontSize: 11, color: 'var(--text)', cursor: 'pointer' }
const overlay = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 16 }
const modalBox = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 14, padding: 22, width: 380, maxWidth: '100%', maxHeight: '90vh', overflow: 'auto' }

function Kpi({ label: l, value, sub, tone }) {
  return (
    <div style={{ ...card, padding: '12px 14px' }}>
      <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>{l}</div>
      <div style={{ fontSize: 19, fontWeight: 600, color: tone || 'var(--text)' }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{sub}</div>}
    </div>
  )
}

function DueBadge({ d }) {
  if (d.status === 'saldata') return <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'var(--success-bg)', color: 'var(--success-text)' }}>{$t("Saldata")}</span>
  const n = daysFromToday(d.due_date)
  if (n < 0)  return <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'var(--danger-bg)', color: 'var(--danger-text)' }}>{$t("scaduta da")}{" "}{-n} {-n === 1 ? $t("giorno") : $t("giorni")}</span>
  if (n === 0) return <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'var(--warn-bg)', color: 'var(--warn-text)' }}>{$t("scade oggi")}</span>
  if (n <= 7) return <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'var(--warn-bg)', color: 'var(--warn-text)' }}>{$t("tra")}{" "}{n} {n === 1 ? $t("giorno") : $t("giorni")}</span>
  return <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'var(--bg3)', color: 'var(--text2)' }}>{$t("tra")}{" "}{n}{" "}{$t("giorni")}</span>
}

export default function Dues(props) {
  const [dues, setDues] = useState([])
  const [customers, setCustomers] = useState([])
  const [suppliers, setSuppliers] = useState([])
  const [tab, setTab] = useState('credito') // credito | debito | saldate
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [payModal, setPayModal] = useState(null)   // scadenza da incassare/pagare
  const [payForm, setPayForm] = useState({ amount: '', date: today(), method: 'contanti' })
  const [editModal, setEditModal] = useState(null) // scadenza da modificare
  const [editForm, setEditForm] = useState({ due_date: '', description: '' })
  const [newModal, setNewModal] = useState(false)
  const [newForm, setNewForm] = useState({ kind: 'debito', party: '', party_name: '', description: '', amount: '', due_date: plusDays(30) })
  const [saving, setSaving] = useState(false)

  const flash = (m) => { setSuccess(m); setTimeout(() => setSuccess(''), 4000) }

  const load = () => {
    setLoading(true)
    return Promise.all([getDues(), getCustomers(), getSuppliers()])
      .then(([d, c, s]) => { setDues(d); setCustomers(c); setSuppliers(s) })
      .catch(e => setError(e?.message || String(e)))
      .finally(() => setLoading(false))
  }
  useEffect(() => { load() }, [])

  const open = dues.filter(d => d.status !== 'saldata')
  const sum = (arr) => arr.reduce((s, d) => s + d.residual, 0)
  const credits = open.filter(d => d.kind === 'credito'), debits = open.filter(d => d.kind === 'debito')
  const overdue = (arr) => arr.filter(d => d.status === 'scaduta')
  const soon = open.filter(d => { const n = daysFromToday(d.due_date); return d.status !== 'scaduta' && n <= 7 })

  const list = useMemo(() => {
    const q = search.trim().toLowerCase()
    const base = tab === 'saldate' ? dues.filter(d => d.status === 'saldata').sort((a, b) => (b.closed_at || '').localeCompare(a.closed_at || ''))
      : open.filter(d => d.kind === tab)
    return q ? base.filter(d => [d.party_name, d.ref_label, d.description].some(v => (v || '').toLowerCase().includes(q))) : base
  }, [dues, tab, search])

  const openPay = (d) => { setPayForm({ amount: d.residual.toFixed(2), date: today(), method: 'contanti' }); setPayModal(d) }
  const submitPay = async () => {
    setSaving(true); setError('')
    try {
      const res = await payDue(payModal.id, { amount: Number(String(payForm.amount).replace(',', '.')), date: payForm.date, method: payForm.method })
      setPayModal(null)
      flash(res.status === 'saldata' ? $t("Scadenza saldata.") : $t("Registrati {0}: residuo {1}.", [eur(payForm.amount), eur(res.residual)]))
      await load()
    } catch (e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const openEdit = (d) => { setEditForm({ due_date: d.due_date, description: d.description || '' }); setEditModal(d) }
  const submitEdit = async () => {
    setSaving(true); setError('')
    try { await updateDue(editModal.id, editForm); setEditModal(null); await load() } catch (e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const remove = async (d) => {
    if (!window.confirm($t("Eliminare la scadenza di {0} ({1})?", [eur(d.amount), d.party_name]))) return
    try { await deleteDue(d.id); await load() } catch (e) { setError(e?.message || String(e)) }
  }

  const submitNew = async () => {
    const isCredit = newForm.kind === 'credito'
    const known = (isCredit ? customers : suppliers).find(x => x.id === newForm.party)
    const name = known ? known.name : newForm.party_name.trim()
    if (!name) return setError(isCredit ? $t("Scegli un cliente o scrivi un nome") : $t("Scegli un fornitore o scrivi un nome"))
    setSaving(true); setError('')
    try {
      await addDue({
        kind: newForm.kind, party_name: name, party_id: known ? known.id : undefined, party_type: known ? (isCredit ? 'customer' : 'supplier') : undefined,
        description: newForm.description, amount: Number(String(newForm.amount).replace(',', '.')), due_date: newForm.due_date,
      })
      setNewModal(false)
      setTab(newForm.kind)
      await load()
    } catch (e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const tabBtn = (id, text) => (
    <button key={id} onClick={() => setTab(id)} style={{
      padding: '5px 14px', borderRadius: 20, fontSize: 12, cursor: 'pointer',
      border: `0.5px solid ${tab === id ? 'var(--accent)' : 'var(--border)'}`,
      background: tab === id ? 'var(--accent-bg)' : 'transparent',
      color: tab === id ? 'var(--accent-text)' : 'var(--text3)',
    }}>{text}</button>
  )

  const isCreditTab = tab === 'credito'

  return (
    <Layout {...props} title={$t("Scadenzario")}>
      <SectionLock section="dues" {...props}>
        {error && <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{error} <button onClick={() => setError('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger-text)' }}>×</button></div>}
        {success && <div style={{ background: 'var(--success-bg)', color: 'var(--success-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{success}</div>}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: 10, marginBottom: 12 }}>
          <Kpi label={$t("Da incassare")} value={eur(sum(credits))} sub={$t("{0} {1} aperte", [credits.length, credits.length === 1 ? $t("scadenza") : $t("scadenze")])} />
          <Kpi label={$t("Crediti scaduti")} value={eur(sum(overdue(credits)))} sub={$t("{0} da sollecitare", [overdue(credits).length])} tone={overdue(credits).length ? 'var(--danger-text)' : undefined} />
          <Kpi label={$t("Da pagare")} value={eur(sum(debits))} sub={$t("{0} {1} aperte", [debits.length, debits.length === 1 ? $t("scadenza") : $t("scadenze")])} />
          <Kpi label={$t("Debiti scaduti")} value={eur(sum(overdue(debits)))} sub={$t("{0} in ritardo", [overdue(debits).length])} tone={overdue(debits).length ? 'var(--danger-text)' : undefined} />
          <Kpi label={$t("In scadenza (7 giorni)")} value={soon.length} sub={eur(sum(soon))} tone={soon.length ? 'var(--warn-text)' : undefined} />
        </div>

        <div style={{ display: 'flex', gap: 6, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          {tabBtn('credito', $t("Da incassare ({0})", [credits.length]))}
          {tabBtn('debito', $t("Da pagare ({0})", [debits.length]))}
          {tabBtn('saldate', $t("Saldate"))}
          <span style={{ flex: 1 }} />
          <button onClick={() => { setNewForm({ kind: isCreditTab ? 'credito' : 'debito', party: '', party_name: '', description: '', amount: '', due_date: plusDays(30) }); setNewModal(true) }}
            style={{ background: 'var(--accent)', border: 'none', borderRadius: 8, padding: '7px 14px', fontSize: 12, color: '#fff', cursor: 'pointer', fontWeight: 500 }}>
            <i className="ti ti-plus" aria-hidden="true"></i>{" "}{$t("Nuova scadenza")}</button>
        </div>

        <div style={card}>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10, lineHeight: 1.5 }}>
            {tab === 'credito' && $t("Soldi che i clienti devono ancora darti: nascono dalle vendite «A credito». Premi Incassa quando ti pagano (anche in più rate).")}
            {tab === 'debito' && $t("Soldi che devi ai fornitori: nascono quando ricevi un ordine d’acquisto (scadenza secondo i giorni di pagamento del fornitore, di default 30). Puoi aggiungere anche spese a mano.")}
            {tab === 'saldate' && $t("Storico delle scadenze già saldate.")}
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder={$t("Cerca per nome, riferimento o descrizione...")} style={{ width: '100%', marginBottom: 10 }} />

          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Caricamento...")}</div>
          ) : list.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>{search ? $t("Nessun risultato per \"{0}\"", [search]) : tab === 'saldate' ? $t("Nessuna scadenza saldata") : $t("Nessuna scadenza aperta")}</div>
          ) : (
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 130px 100px 100px 190px', gap: 8, padding: '6px 8px', fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '0.5px solid var(--border)', marginBottom: 4 }}>
                <span>{tab === 'debito' ? $t("Fornitore") : tab === 'credito' ? $t("Cliente") : $t("Soggetto")}</span><span>{tab === 'saldate' ? $t("Saldata il") : $t("Scadenza")}</span><span style={{ textAlign: 'right' }}>{$t("Importo")}</span><span style={{ textAlign: 'right' }}>{tab === 'saldate' ? $t("Tipo") : $t("Residuo")}</span><span></span>
              </div>
              {list.map(d => (
                <div key={d.id} style={{ display: 'grid', gridTemplateColumns: '1.3fr 130px 100px 100px 190px', gap: 8, padding: '9px 8px', borderBottom: '0.5px solid var(--border)', alignItems: 'center' }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.party_name}</div>
                    <div style={{ fontSize: 11, color: 'var(--text3)' }}>{[dataText(d.ref_label), d.description].filter(Boolean).join(' · ')}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 12, color: 'var(--text2)' }}>{tab === 'saldate' ? (d.closed_at || '').slice(0, 10) : d.due_date}</div>
                    <DueBadge d={d} />
                  </div>
                  <div style={{ textAlign: 'right', fontSize: 13, color: 'var(--text)' }}>{eur(d.amount)}</div>
                  <div style={{ textAlign: 'right', fontSize: 13, fontWeight: 600, color: d.status === 'scaduta' ? 'var(--danger-text)' : 'var(--text)' }}>
                    {tab === 'saldate' ? <span style={{ fontWeight: 400, fontSize: 12, color: 'var(--text3)' }}>{d.kind === 'credito' ? $t("incasso") : $t("pagamento")}</span> : eur(d.residual)}
                    {d.paid > 0 && tab !== 'saldate' && <div style={{ fontSize: 10, fontWeight: 400, color: 'var(--text3)' }}>{$t("già")}{" "}{d.kind === 'credito' ? $t("incassati") : $t("pagati")} {eur(d.paid)}</div>}
                  </div>
                  <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                    {d.status !== 'saldata' && <button onClick={() => openPay(d)} style={{ ...btnGhost, background: 'var(--success-bg)', color: 'var(--success-text)', border: '0.5px solid var(--success-text)' }}>{d.kind === 'credito' ? $t("Incassa") : $t("Paga")}</button>}
                    {d.status !== 'saldata' && <button onClick={() => openEdit(d)} style={btnGhost} title={$t("Cambia data o descrizione")}><i className="ti ti-pencil" aria-hidden="true"></i></button>}
                    {d.paid === 0 && <button onClick={() => remove(d)} title={$t("Elimina")} style={{ ...btnGhost, background: 'var(--danger-bg)', color: 'var(--danger-text)', border: '0.5px solid var(--danger-text)' }}><i className="ti ti-trash" aria-hidden="true"></i></button>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Incasso / pagamento */}
        {payModal && (
          <div style={overlay}>
            <div style={modalBox}>
              <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 4 }}>{payModal.kind === 'credito' ? $t("Registra incasso") : $t("Registra pagamento")}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 14 }}>{payModal.party_name} · {dataText(payModal.ref_label) || payModal.description || $t("scadenza")}<br />{$t("Residuo da")}{" "}{payModal.kind === 'credito' ? $t("incassare") : $t("pagare")}: <b style={{ color: 'var(--text)' }}>{eur(payModal.residual)}</b></div>
              <div style={{ marginBottom: 10 }}>
                <label style={label}>{$t("Importo (€)")}</label>
                <input type="number" min="0" step="0.01" value={payForm.amount} onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))} autoFocus style={{ width: '100%' }} />
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 3 }}>{$t("Puoi inserire una cifra minore del residuo per un pagamento parziale.")}</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
                <div><label style={label}>{$t("Data")}</label><input type="date" value={payForm.date} onChange={e => setPayForm(f => ({ ...f, date: e.target.value }))} style={{ width: '100%' }} /></div>
                <div><label style={label}>{$t("Metodo")}</label>
                  <select value={payForm.method} onChange={e => setPayForm(f => ({ ...f, method: e.target.value }))} style={{ width: '100%' }}>{METHODS.map(m => <option key={m} value={m}>{payLabel(m)}</option>)}</select>
                </div>
              </div>
              {payModal.payments.length > 0 && (
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 12 }}>{$t("Già registrati:")}{" "}{payModal.payments.map(p => $t("{0} il {1}", [eur(p.amount), p.date])).join(' · ')}
                </div>
              )}
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setPayModal(null)} style={{ flex: 1, border: '0.5px solid var(--border)', borderRadius: 8, padding: 8, fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Annulla")}</button>
                <button onClick={submitPay} disabled={saving} style={{ flex: 2, background: saving ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8, padding: 8, fontSize: 13, color: saving ? 'var(--text3)' : '#fff', cursor: saving ? 'default' : 'pointer', fontWeight: 500 }}>{saving ? $t("Salvataggio...") : $t("Conferma")}</button>
              </div>
            </div>
          </div>
        )}

        {/* Modifica scadenza */}
        {editModal && (
          <div style={overlay}>
            <div style={modalBox}>
              <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 14 }}>{$t("Modifica scadenza")}</div>
              <div style={{ marginBottom: 10 }}><label style={label}>{$t("Data di scadenza")}</label><input type="date" value={editForm.due_date} onChange={e => setEditForm(f => ({ ...f, due_date: e.target.value }))} style={{ width: '100%' }} /></div>
              <div style={{ marginBottom: 14 }}><label style={label}>{$t("Descrizione")}</label><input value={editForm.description} onChange={e => setEditForm(f => ({ ...f, description: e.target.value }))} style={{ width: '100%' }} /></div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setEditModal(null)} style={{ flex: 1, border: '0.5px solid var(--border)', borderRadius: 8, padding: 8, fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Annulla")}</button>
                <button onClick={submitEdit} disabled={saving} style={{ flex: 2, background: 'var(--accent)', border: 'none', borderRadius: 8, padding: 8, fontSize: 13, color: '#fff', cursor: 'pointer', fontWeight: 500 }}>{$t("Salva")}</button>
              </div>
            </div>
          </div>
        )}

        {/* Nuova scadenza */}
        {newModal && (
          <div style={overlay}>
            <div style={modalBox}>
              <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 14 }}>{$t("Nuova scadenza")}</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 12 }}>
                {[['debito', $t("Da pagare")], ['credito', $t("Da incassare")]].map(([k, t]) => (
                  <button key={k} onClick={() => setNewForm(f => ({ ...f, kind: k, party: '', party_name: '' }))} style={{ padding: '8px', borderRadius: 10, cursor: 'pointer', fontSize: 12, fontWeight: 500, border: `0.5px solid ${newForm.kind === k ? 'var(--accent)' : 'var(--border)'}`, background: newForm.kind === k ? 'var(--accent-bg)' : 'transparent', color: newForm.kind === k ? 'var(--accent-text)' : 'var(--text)' }}>{t}</button>
                ))}
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={label}>{newForm.kind === 'credito' ? $t("Cliente") : $t("Fornitore")}</label>
                <select value={newForm.party} onChange={e => setNewForm(f => ({ ...f, party: e.target.value }))} style={{ width: '100%' }}>
                  <option value="">{$t("Altro (scrivi il nome qui sotto)")}</option>
                  {(newForm.kind === 'credito' ? customers : suppliers).map(x => <option key={x.id} value={x.id}>{x.name}</option>)}
                </select>
                {!newForm.party && <input value={newForm.party_name} onChange={e => setNewForm(f => ({ ...f, party_name: e.target.value }))} placeholder={$t("Es: Affitto negozio, Commercialista...")} style={{ width: '100%', marginTop: 6 }} />}
              </div>
              <div style={{ marginBottom: 10 }}><label style={label}>{$t("Descrizione")}</label><input value={newForm.description} onChange={e => setNewForm(f => ({ ...f, description: e.target.value }))} placeholder={$t("Facoltativa")} style={{ width: '100%' }} /></div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
                <div><label style={label}>{$t("Importo (€)")}</label><input type="number" min="0" step="0.01" value={newForm.amount} onChange={e => setNewForm(f => ({ ...f, amount: e.target.value }))} style={{ width: '100%' }} /></div>
                <div><label style={label}>{$t("Scadenza")}</label><input type="date" value={newForm.due_date} onChange={e => setNewForm(f => ({ ...f, due_date: e.target.value }))} style={{ width: '100%' }} /></div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setNewModal(false)} style={{ flex: 1, border: '0.5px solid var(--border)', borderRadius: 8, padding: 8, fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Annulla")}</button>
                <button onClick={submitNew} disabled={saving} style={{ flex: 2, background: saving ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8, padding: 8, fontSize: 13, color: saving ? 'var(--text3)' : '#fff', cursor: saving ? 'default' : 'pointer', fontWeight: 500 }}>{saving ? $t("Salvataggio...") : $t("Aggiungi")}</button>
              </div>
            </div>
          </div>
        )}
      </SectionLock>
    </Layout>
  )
}
