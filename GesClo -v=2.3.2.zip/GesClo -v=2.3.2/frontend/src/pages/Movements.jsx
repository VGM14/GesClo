import React, { useState, useEffect } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import { getMovements, getProducts, addMovement } from '../services/apiService'
import { $t, LOCALE } from '../i18n'

export default function Movements(props) {
  const [movements, setMovements] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState({ product_id:'', type:'entrata', qty:'1', notes:'' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const load = () => {
    Promise.all([getMovements(), getProducts()])
      .then(([m, p]) => { setMovements(m); setProducts(p) })
      .catch(e => setError(e?.message || String(e)))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleSave = async () => {
    if (!form.product_id || !form.qty) return
    setSaving(true)
    try {
      const product = products.find(p => p.id === form.product_id)
      await addMovement({ ...form, qty: parseInt(form.qty)||1, product_name: product?.name || '' })
      load(); setModal(false)
    } catch(e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  return (
    <Layout {...props} title={$t("Movimenti")}>
      <SectionLock section="movements" {...props}>
        {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',borderRadius:10,padding:'8px 12px',marginBottom:12,fontSize:12}}>{error}</div>}
        <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em'}}>{$t("Ultimi movimenti")}</div>
            <button onClick={()=>setModal(true)} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'6px 12px',fontSize:12,color:'#fff',cursor:'pointer',fontWeight:500}}>
              <i className="ti ti-plus" aria-hidden="true"></i>{" "}{$t("Nuovo movimento")}</button>
          </div>
          {loading ? (
            <div style={{textAlign:'center',padding:'30px 0',color:'var(--text3)',fontSize:13}}>{$t("Caricamento...")}</div>
          ) : movements.length === 0 ? (
            <div style={{textAlign:'center',padding:'30px 0',color:'var(--text3)',fontSize:13}}>{$t("Nessun movimento registrato")}</div>
          ) : movements.map(m=>(
            <div key={m.id} style={{display:'flex',alignItems:'center',gap:10,padding:'9px 0',borderBottom:'0.5px solid var(--border)'}}>
              <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,background:m.type==='entrata'?'var(--success-bg)':'var(--danger-bg)',color:m.type==='entrata'?'var(--success-text)':'var(--danger-text)',flexShrink:0}}>
                {m.type==='entrata'?$t("Entrata"):$t("Uscita")}
              </span>
              <span style={{flex:1,fontSize:13,color:'var(--text)'}}>{m.product_name}</span>
              <span style={{fontSize:13,fontWeight:500,color:m.type==='entrata'?'var(--success-text)':'var(--danger-text)'}}>
                {m.type==='entrata'?'+':'-'}{m.qty}
              </span>
              <span style={{fontSize:11,color:'var(--text3)'}}>{m.user}</span>
              <span style={{fontSize:11,color:'var(--text3)'}}>{new Date(m.created_at).toLocaleDateString(LOCALE)}</span>
            </div>
          ))}
        </div>

        {modal && (
          <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:100}}>
            <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:14,padding:22,width:340}}>
              <div style={{fontWeight:500,fontSize:15,color:'var(--text)',marginBottom:16}}>{$t("Nuovo movimento")}</div>
              <div style={{marginBottom:10}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Articolo")}</label>
                <select value={form.product_id} onChange={e=>setForm(p=>({...p,product_id:e.target.value}))} style={{width:'100%'}}>
                  <option value="">{$t("Seleziona articolo...")}</option>
                  {products.map(p=><option key={p.id} value={p.id}>{p.name} ({p.qty} {p.unit})</option>)}
                </select>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:10}}>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Tipo")}</label>
                  <select value={form.type} onChange={e=>setForm(p=>({...p,type:e.target.value}))} style={{width:'100%'}}>
                    <option value="entrata">{$t("Entrata")}</option>
                    <option value="uscita">{$t("Uscita")}</option>
                  </select>
                </div>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Quantita")}</label>
                  <input type="number" value={form.qty} onChange={e=>setForm(p=>({...p,qty:e.target.value}))} min="1" style={{width:'100%'}} />
                </div>
              </div>
              <div style={{marginBottom:14}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Note")}</label>
                <input value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))} placeholder={$t("Opzionale...")} style={{width:'100%'}} />
              </div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>setModal(false)} style={{flex:1,border:'0.5px solid var(--border)',borderRadius:8,padding:8,fontSize:13,background:'transparent',color:'var(--text)',cursor:'pointer'}}>{$t("Annulla")}</button>
                <button onClick={handleSave} disabled={saving||!form.product_id} style={{flex:2,background:saving||!form.product_id?'var(--bg3)':'var(--accent)',border:'none',borderRadius:8,padding:8,fontSize:13,color:saving||!form.product_id?'var(--text3)':'#fff',cursor:'pointer',fontWeight:500}}>
                  {saving?$t("Salvataggio..."):$t("Registra")}
                </button>
              </div>
            </div>
          </div>
        )}
      </SectionLock>
    </Layout>
  )
}
