import React, { useState, useEffect } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import { getProducts, addProduct, updateProduct, deleteProduct, getSuppliers } from '../services/apiService'
import CsvTools from '../components/CsvTools'
import Inventory from '../components/Inventory'
import { $t } from '../i18n'

const COMMA = (n) => (n == null || n === '' ? '' : String(n).replace('.', ','))

export default function Stock(props) {
  const { lastNfcScan, setLastNfcScan } = props
  const [search, setSearch] = useState('')
  const [products, setProducts] = useState([])
  const [suppliers, setSuppliers] = useState([])
  const [tab, setTab] = useState('articoli')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [modal, setModal] = useState(null)
  const [form, setForm] = useState({ name:'', barcodes:[], nfc_uid:'', price:'', cost:'', min_stock:'', reorder_qty:'', supplier_id:'', qty:'0', unit:'pz', category:'', notes:'' })
  const [saving, setSaving] = useState(false)
  const [barcodeDraft, setBarcodeDraft] = useState('')

  const load = () => {
    setLoading(true)
    Promise.all([getProducts(), getSuppliers()])
      .then(([p, sp]) => { setProducts(p); setSuppliers(sp) })
      .catch(e => setError(e?.message || String(e)))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const filtered = products.filter(p =>
    p.name?.toLowerCase().includes(search.toLowerCase()) ||
    (p.barcodes || [p.barcode]).some(b => b?.includes(search)) ||
    p.category?.toLowerCase().includes(search.toLowerCase())
  )

  const openAdd = () => { setForm({ name:'', barcodes:[], nfc_uid:'', price:'', cost:'', min_stock:'', reorder_qty:'', supplier_id:'', qty:'0', unit:'pz', category:'', notes:'' }); setBarcodeDraft(''); setModal('add') }
  const openEdit = (p) => { setForm({ name:p.name, barcodes:p.barcodes||(p.barcode?[p.barcode]:[]), nfc_uid:p.nfc_uid||'', price:p.price!=null?String(p.price):'', cost:p.cost!=null?String(p.cost):'', min_stock:p.min_stock!=null?String(p.min_stock):'', reorder_qty:p.reorder_qty!=null?String(p.reorder_qty):'', supplier_id:p.supplier_id||'', qty:String(p.qty||0), unit:p.unit||'pz', category:p.category||'', notes:p.notes||'' }); setBarcodeDraft(''); setModal(p.id) }

  // Aggiunge il codice digitato/scansionato all'elenco dei codici a barre dell'articolo
  const addBarcode = () => {
    const d = barcodeDraft.trim()
    if (!d) return
    setForm(f => f.barcodes.includes(d) ? f : { ...f, barcodes: [...f.barcodes, d] })
    setBarcodeDraft('')
  }

  const handleSave = async () => {
    if (!form.name.trim()) return
    setSaving(true)
    try {
      const draft = barcodeDraft.trim()
      const payload = { ...form, barcodes: draft && !form.barcodes.includes(draft) ? [...form.barcodes, draft] : form.barcodes, qty: parseInt(form.qty)||0, price: form.price !== '' ? parseFloat(form.price) : null, cost: form.cost !== '' ? parseFloat(form.cost) : null, min_stock: form.min_stock !== '' ? parseInt(form.min_stock) : null, reorder_qty: form.reorder_qty !== '' ? parseInt(form.reorder_qty) : null, supplier_id: form.supplier_id || null }
      if (modal === 'add') await addProduct(payload)
      else await updateProduct(modal, payload)
      load(); setModal(null)
    } catch(e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const handleDelete = async (id) => {
    if (!window.confirm($t("Eliminare questo articolo? L'azione è irreversibile."))) return
    try {
      await deleteProduct(id)
      load()
    } catch(e) { setError(e?.message || String(e)) }
  }

  // Margine % sul prezzo di vendita; null se manca il costo o il prezzo.
  const marginOf = (p) => (p.cost!=null && p.price>0) ? ((p.price - p.cost) / p.price) * 100 : null

  const getStatus = (qty, min) => {
    const n = parseInt(qty)||0
    if (n <= 0) return { bg:'var(--danger-bg)', cl:'var(--danger-text)', label:$t("Esaurito") }
    if (n <= (min > 0 ? min : 5)) return { bg:'var(--warn-bg)', cl:'var(--warn-text)', label:$t("Basso") }
    return { bg:'var(--success-bg)', cl:'var(--success-text)', label:$t("OK") }
  }

  return (
    <Layout {...props} title={$t("Stock — Inventario")}>
      <SectionLock section="stock" {...props}>
        {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',borderRadius:10,padding:'8px 12px',marginBottom:12,fontSize:12}}>{error} <button onClick={()=>setError('')} style={{background:'none',border:'none',cursor:'pointer',color:'var(--danger-text)'}}>×</button></div>}
        <div style={{display:'flex',gap:6,marginBottom:14}}>
          {[['articoli',$t("Articoli")],['inventario',$t("Inventario")]].map(([id,text])=>(
            <button key={id} onClick={()=>setTab(id)} style={{padding:'5px 14px',borderRadius:20,fontSize:12,cursor:'pointer',border:`0.5px solid ${tab===id?'var(--accent)':'var(--border)'}`,background:tab===id?'var(--accent-bg)':'transparent',color:tab===id?'var(--accent-text)':'var(--text3)'}}>{text}</button>
          ))}
        </div>

        {tab === 'inventario' ? (
          <Inventory products={products} onApplied={load} />
        ) : (
        <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={$t("Cerca per nome, barcode o categoria...")} style={{flex:1}} />
            <button onClick={load} style={{border:'0.5px solid var(--border)',borderRadius:8,padding:'7px 10px',fontSize:12,background:'transparent',color:'var(--text)',cursor:'pointer'}} title={$t("Aggiorna")}>
              <i className="ti ti-refresh" aria-hidden="true"></i>
            </button>
            <CsvTools config={{
              kind: 'products', label: $t("articoli"), filename: 'articoli.csv',
              importNote: $t("Gli articoli già presenti (stesso barcode o stesso nome) vengono aggiornati con i campi compilati; la giacenza degli esistenti non cambia (per quella usa la scheda Inventario)."),
              columns: [
                { key: 'name', label: $t("Nome"), aliases: ['articolo', 'descrizione'], value: p => p.name },
                { key: 'barcode', label: $t("Barcode"), aliases: ['codice', 'ean'], value: p => p.barcode },
                { key: 'category', label: $t("Categoria"), value: p => p.category },
                { key: 'unit', label: $t("Unità"), aliases: ['um', 'unita di misura'], value: p => p.unit },
                { key: 'price', label: $t("Prezzo di vendita"), aliases: ['prezzo', 'price'], value: p => COMMA(p.price) },
                { key: 'cost', label: $t("Costo d’acquisto"), aliases: ['costo', 'cost'], value: p => COMMA(p.cost) },
                { key: 'qty', label: $t("Quantità"), aliases: ['giacenza', 'qta', 'qty'], value: p => p.qty },
                { key: 'min_stock', label: $t("Scorta minima"), aliases: ['minimo'], value: p => p.min_stock },
                { key: 'reorder_qty', label: $t("Quantità di riordino"), value: p => p.reorder_qty },
                { key: 'supplier', label: $t("Fornitore"), value: p => suppliers.find(sp => sp.id === p.supplier_id)?.name || '' },
                { key: 'notes', label: $t("Note"), value: p => p.notes },
              ],
              exportRows: () => filtered,
              onDone: load,
            }} />
            <button onClick={openAdd} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'7px 14px',fontSize:12,color:'#fff',cursor:'pointer',fontWeight:500,flexShrink:0}}>
              <i className="ti ti-plus" aria-hidden="true"></i>{" "}{$t("Nuovo articolo")}</button>
          </div>

          {loading ? (
            <div style={{textAlign:'center',padding:'40px 0',color:'var(--text3)',fontSize:13}}>{$t("Caricamento...")}</div>
          ) : filtered.length === 0 ? (
            <div style={{textAlign:'center',padding:'40px 0',color:'var(--text3)',fontSize:13}}>
              {products.length === 0 ? $t("Nessun articolo — clicca \"Nuovo articolo\"") : $t("Nessun risultato per \"{0}\"", [search])}
            </div>
          ) : (
            <div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 80px 70px 70px 80px 80px',gap:8,padding:'6px 8px',fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',borderBottom:'0.5px solid var(--border)',marginBottom:4}}>
                <span>{$t("Articolo")}</span><span>{$t("Categoria")}</span><span>{$t("Prezzo")}</span><span>{$t("Qty")}</span><span>{$t("Stato")}</span><span></span>
              </div>
              {filtered.map(p => {
                const status = getStatus(p.qty, p.min_stock)
                return (
                  <div key={p.id} style={{display:'grid',gridTemplateColumns:'1fr 80px 70px 70px 80px 80px',gap:8,padding:'9px 8px',borderBottom:'0.5px solid var(--border)',alignItems:'center'}}>
                    <div>
                      <div style={{fontSize:13,fontWeight:500,color:'var(--text)'}}>{p.name}</div>
                      {p.barcode && <div style={{fontSize:11,color:'var(--text3)'}}>#{p.barcode}{p.barcodes?.length > 1 ? ` (+${p.barcodes.length - 1})` : ''}</div>}
                    </div>
                    <div style={{fontSize:12,color:'var(--text2)'}}>{p.category||'—'}</div>
                    <div style={{fontSize:13,color:'var(--text)'}}>{p.price!=null ? `€${Number(p.price).toFixed(2)}` : '—'}{marginOf(p)!=null && <div style={{fontSize:10,color:marginOf(p)<0?'var(--danger-text)':'var(--text3)'}}>{$t("marg.")}{" "}{marginOf(p).toFixed(0)}%</div>}</div>
                    <div style={{fontSize:13,fontWeight:500,color:'var(--text)'}}>{p.qty} {p.unit}</div>
                    <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,background:status.bg,color:status.cl,textAlign:'center'}}>{status.label}</span>
                    <div style={{display:'flex',gap:4}}>
                      <button onClick={()=>openEdit(p)} style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:6,padding:'3px 8px',fontSize:11,color:'var(--text)',cursor:'pointer'}}><i className="ti ti-pencil" aria-hidden="true"></i></button>
                      <button onClick={()=>handleDelete(p.id)} style={{background:'var(--danger-bg)',border:'0.5px solid var(--danger-text)',borderRadius:6,padding:'3px 8px',fontSize:11,color:'var(--danger-text)',cursor:'pointer'}}><i className="ti ti-trash" aria-hidden="true"></i></button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
        )}

        {modal && (
          <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:100}}>
            <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:14,padding:22,width:360,maxHeight:'90vh',overflow:'auto'}}>
              <div style={{fontWeight:500,fontSize:15,color:'var(--text)',marginBottom:16,display:'flex',alignItems:'center',gap:8}}>
                <i className={`ti ${modal==='add'?'ti-plus':'ti-pencil'}`} style={{color:'var(--accent)'}} aria-hidden="true"></i>
                {modal==='add' ? $t("Nuovo articolo") : $t("Modifica articolo")}
              </div>
              {[[$t("Nome articolo *"),'text','name',$t("Es: Martello")],[$t("Categoria"),'text','category',$t("Es: Utensileria")]].map(([label,type,field,ph])=>(
                <div key={field} style={{marginBottom:10}}>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{label}</label>
                  <input type={type} value={form[field]} onChange={e=>setForm(p=>({...p,[field]:e.target.value}))} placeholder={ph} style={{width:'100%'}} />
                </div>
              ))}
              {/* Codici a barre: ne servono anche 5 per lo stesso articolo; ogni codice trova lo stesso articolo */}
              <div style={{marginBottom:10}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Codici a barre")}</label>
                {form.barcodes.length > 0 && (
                  <div style={{display:'flex',flexWrap:'wrap',gap:6,marginBottom:6}}>
                    {form.barcodes.map(b => (
                      <span key={b} style={{display:'inline-flex',alignItems:'center',gap:2,background:'var(--bg3)',border:'0.5px solid var(--border)',borderRadius:20,padding:'2px 4px 2px 10px',fontSize:12,color:'var(--text)'}}>
                        {b}
                        <button type="button" onClick={()=>setForm(f=>({...f,barcodes:f.barcodes.filter(x=>x!==b)}))} title={$t("Rimuovi")} aria-label={$t("Rimuovi")} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:14,lineHeight:1,padding:'0 4px'}}>×</button>
                      </span>
                    ))}
                  </div>
                )}
                <div style={{display:'flex',gap:6}}>
                  <input value={barcodeDraft} onChange={e=>setBarcodeDraft(e.target.value)} onKeyDown={e=>{ if (e.key==='Enter') { e.preventDefault(); addBarcode() } }} placeholder={$t("Scansiona o scrivi un codice e premi Invio")} style={{flex:1}} />
                  <button type="button" onClick={addBarcode} style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:8,padding:'0 12px',fontSize:12,color:'var(--text)',cursor:'pointer'}}>{$t("Aggiungi")}</button>
                </div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:10}}>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Prezzo di vendita (€)")}</label>
                  <input type="number" min="0" step="0.01" value={form.price} onChange={e=>setForm(p=>({...p,price:e.target.value}))} placeholder={$t("Es: 9.99")} style={{width:'100%'}} />
                </div>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Costo d'acquisto (€)")}</label>
                  <input type="number" min="0" step="0.01" value={form.cost} onChange={e=>setForm(p=>({...p,cost:e.target.value}))} placeholder={$t("Es: 4.50")} style={{width:'100%'}} />
                </div>
                {form.price !== '' && form.cost !== '' && parseFloat(form.price) > 0 && (
                  <div style={{gridColumn:'1 / -1',fontSize:11,color:'var(--text3)'}}>{$t("Margine:")}{" "}<b style={{color:'var(--text)'}}>€{(parseFloat(form.price) - parseFloat(form.cost)).toFixed(2)}</b> ({(((parseFloat(form.price) - parseFloat(form.cost)) / parseFloat(form.price)) * 100).toFixed(0)}{$t("%) per pezzo")}</div>
                )}
              </div>
              {/* UID NFC tag prodotto */}
              <div style={{marginBottom:10}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("UID tag NFC")}{" "}<span style={{color:'var(--text3)'}}>{$t("(opzionale — per lettori NFC)")}</span>
                </label>
                <div style={{display:'flex',gap:6}}>
                  <input
                    value={form.nfc_uid}
                    onChange={e=>setForm(p=>({...p,nfc_uid:e.target.value.toUpperCase()}))}
                    placeholder={$t("Es: 04A1B2C3D4E5")}
                    style={{flex:1,fontFamily:'monospace',fontSize:12}}
                  />
                  {lastNfcScan && lastNfcScan.source !== 'payment_card' && (
                    <button
                      onClick={() => {
                        setForm(p=>({...p, nfc_uid: lastNfcScan.uid}))
                        if (setLastNfcScan) setLastNfcScan(null)
                      }}
                      style={{background:'var(--info-bg)',border:'0.5px solid var(--info-text)',borderRadius:6,padding:'0 10px',fontSize:11,color:'var(--info-text)',cursor:'pointer',flexShrink:0,whiteSpace:'nowrap'}}
                    >
                      <i className="ti ti-wifi" style={{marginRight:4}} aria-hidden="true"></i>{$t("Usa NFC (")}{lastNfcScan.uid.substring(0,8)}…)
                    </button>
                  )}
                </div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:10}}>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Quantita")}</label>
                  <input type="number" value={form.qty} onChange={e=>setForm(p=>({...p,qty:e.target.value}))} min="0" style={{width:'100%'}} />
                </div>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Unita")}</label>
                  <select value={form.unit} onChange={e=>setForm(p=>({...p,unit:e.target.value}))} style={{width:'100%'}}>
                    {['pz','kg','g','l','ml','m','cm','conf','box'].map(u=><option key={u}>{u}</option>)}
                  </select>
                </div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:10}}>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Scorta minima")}</label>
                  <input type="number" min="0" step="1" value={form.min_stock} onChange={e=>setForm(p=>({...p,min_stock:e.target.value}))} placeholder={$t("Es: 5")} style={{width:'100%'}} />
                </div>
                <div>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Quantità di riordino")}</label>
                  <input type="number" min="0" step="1" value={form.reorder_qty} onChange={e=>setForm(p=>({...p,reorder_qty:e.target.value}))} placeholder={$t("Es: 20")} style={{width:'100%'}} />
                </div>
                <div style={{gridColumn:'1 / -1'}}>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Fornitore abituale")}{" "}<span style={{color:'var(--text3)'}}>{$t("(per il riordino automatico)")}</span></label>
                  <select value={form.supplier_id} onChange={e=>setForm(p=>({...p,supplier_id:e.target.value}))} style={{width:'100%'}}>
                    <option value="">{$t("Nessuno")}</option>
                    {suppliers.map(sp=><option key={sp.id} value={sp.id}>{sp.name}</option>)}
                  </select>
                </div>
              </div>
              <div style={{marginBottom:14}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Note")}</label>
                <textarea value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))} rows={2} style={{width:'100%',resize:'vertical'}} />
              </div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>setModal(null)} style={{flex:1,border:'0.5px solid var(--border)',borderRadius:8,padding:8,fontSize:13,background:'transparent',color:'var(--text)',cursor:'pointer'}}>{$t("Annulla")}</button>
                <button onClick={handleSave} disabled={saving} style={{flex:2,background:saving?'var(--bg3)':'var(--accent)',border:'none',borderRadius:8,padding:8,fontSize:13,color:saving?'var(--text3)':'#fff',cursor:saving?'default':'pointer',fontWeight:500}}>
                  {saving ? $t("Salvataggio...") : $t("Salva")}
                </button>
              </div>
            </div>
          </div>
        )}

      </SectionLock>
    </Layout>
  )
}
