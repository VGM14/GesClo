import React, { useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import {
  getSuppliers,
  getPurchaseOrders, addPurchaseOrder, updatePurchaseOrder, receivePurchaseOrder, cancelPurchaseOrder, deletePurchaseOrder,
  getProducts, getReorderSuggestions, createReorderOrders,
} from '../services/apiService'
import { $t, dataText } from '../i18n'

const eur = (n) => '€' + Number(n || 0).toFixed(2)

const STATUS = {
  bozza:     { label: $t("Bozza"),     bg: 'var(--bg3)',        cl: 'var(--text2)' },
  ordinato:  { label: $t("Ordinato"),  bg: 'var(--info-bg)',    cl: 'var(--info-text)' },
  ricevuto:  { label: $t("Ricevuto"),  bg: 'var(--success-bg)', cl: 'var(--success-text)' },
  annullato: { label: $t("Annullato"), bg: 'var(--danger-bg)',  cl: 'var(--danger-text)' },
}

const EMPTY_ORDER = { id: null, supplier_id: '', notes: '', status: 'bozza', items: [] }

const card = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px' }
const label = { fontSize: 11, color: 'var(--text2)', display: 'block', marginBottom: 4 }
const btnGhost = { background: 'transparent', border: '0.5px solid var(--border)', borderRadius: 6, padding: '3px 9px', fontSize: 11, color: 'var(--text)', cursor: 'pointer' }
const btnPrimary = { background: 'var(--accent)', border: 'none', borderRadius: 8, padding: '7px 14px', fontSize: 12, color: '#fff', cursor: 'pointer', fontWeight: 500 }

export default function Purchases(props) {
  const [suppliers, setSuppliers] = useState([])
  const [orders, setOrders] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [orderModal, setOrderModal] = useState(false)
  const [order, setOrder] = useState(EMPTY_ORDER)
  const [productSearch, setProductSearch] = useState('')
  const [saving, setSaving] = useState(false)
  const [reorder, setReorder] = useState([])
  const [reorderBusy, setReorderBusy] = useState(false)

  const flash = (msg) => { setSuccess(msg); setTimeout(() => setSuccess(''), 4000) }

  const load = () => {
    setLoading(true)
    return Promise.all([getSuppliers(), getPurchaseOrders(), getProducts(), getReorderSuggestions()])
      .then(([s, o, p, r]) => { setSuppliers(s); setOrders(o); setProducts(p); setReorder(r) })
      .catch(e => setError(e?.message || String(e)))
      .finally(() => setLoading(false))
  }
  useEffect(() => { load() }, [])

  // ── Ordini ───────────────────────────────────────────────────
  const readOnly = order.id && ['ricevuto', 'annullato'].includes(order.status)

  const openOrder = (o) => {
    setProductSearch('')
    setOrder(o
      ? { id: o.id, supplier_id: o.supplier_id, notes: o.notes || '', status: o.status, number: o.number, items: o.items.map(i => ({ ...i })) }
      : { ...EMPTY_ORDER, supplier_id: suppliers[0]?.id || '', items: [] })
    setOrderModal(true)
  }

  const matches = useMemo(() => {
    const q = productSearch.trim().toLowerCase()
    if (!q) return []
    return products.filter(p => p.name?.toLowerCase().includes(q) || (p.barcodes || [p.barcode]).some(b => b?.toLowerCase().includes(q))).slice(0, 6)
  }, [productSearch, products])

  const addLine = (p) => {
    setOrder(o => {
      const existing = o.items.find(i => i.product_id === p.id)
      if (existing) return { ...o, items: o.items.map(i => i.product_id === p.id ? { ...i, qty: Number(i.qty) + 1 } : i) }
      return { ...o, items: [...o.items, { product_id: p.id, name: p.name, qty: 1, cost: p.cost != null ? p.cost : '' }] }
    })
    setProductSearch('')
  }

  const setLine = (idx, field, value) => setOrder(o => ({ ...o, items: o.items.map((i, k) => k === idx ? { ...i, [field]: value } : i) }))
  const removeLine = (idx) => setOrder(o => ({ ...o, items: o.items.filter((_, k) => k !== idx) }))
  const orderTotal = order.items.reduce((s, i) => s + (Number(i.qty) || 0) * (Number(i.cost) || 0), 0)

  const saveOrder = async (status) => {
    if (!order.supplier_id) return setError($t("Scegli un fornitore"))
    if (order.items.length === 0) return setError($t("Aggiungi almeno un articolo"))
    if (order.items.some(i => !(Number(i.qty) > 0) || !Number.isInteger(Number(i.qty)))) return setError($t("Le quantità devono essere numeri interi maggiori di zero"))
    if (order.items.some(i => i.cost === '' || !(Number(i.cost) >= 0))) return setError($t("Inserisci il costo di ogni articolo"))
    if (status === 'ordinato' && order.items.some(i => !(Number(i.cost) > 0))) return setError($t("Per segnare l'ordine come ordinato inserisci il costo di ogni articolo (maggiore di zero). Se non lo conosci ancora, salvalo come bozza."))
    setSaving(true); setError('')
    const payload = {
      supplier_id: order.supplier_id, notes: order.notes, status,
      items: order.items.map(i => ({ product_id: i.product_id, qty: Number(i.qty), cost: Number(i.cost) })),
    }
    try {
      if (order.id) await updatePurchaseOrder(order.id, payload)
      else await addPurchaseOrder(payload)
      setOrderModal(false)
      flash(status === 'ordinato' ? $t("Ordine registrato come ordinato.") : $t("Bozza salvata."))
      await load()
    } catch (e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const createReorder = async () => {
    setReorderBusy(true); setError('')
    try {
      const res = await createReorderOrders()
      const n = res.created.length
      flash(n
        ? $t("Create {0} {1} d'ordine: controlla i costi e segnalale come ordinate.{2}", [n, n === 1 ? $t("bozza") : $t("bozze"), res.skipped.length ? $t(" {0} articoli non hanno un fornitore abituale (impostalo in Stock).", [res.skipped.length]) : ''])
        : $t("Nessuna bozza creata: gli articoli da riordinare non hanno un fornitore abituale (impostalo in Stock)."))
      await load()
    } catch (e) { setError(e?.message || String(e)) }
    setReorderBusy(false)
  }

  const receive = async (o) => {
    const units = o.items.reduce((s, i) => s + i.qty, 0)
    if (!window.confirm($t("Ricevere l'ordine N°{0} da {1}?\n\nVerranno caricati a magazzino {2} pezzi ({3} articoli) e aggiornato il costo degli articoli. L'operazione non si può annullare.", [o.number, o.supplier_name, units, o.items.length]))) return
    try { await receivePurchaseOrder(o.id); flash($t("Ordine N°{0} ricevuto: magazzino aggiornato.", [o.number])); await load() }
    catch (e) { setError(e?.message || String(e)) }
  }

  const cancelOrder = async (o) => {
    if (!window.confirm($t("Annullare l'ordine N°{0}?", [o.number]))) return
    try { await cancelPurchaseOrder(o.id); await load() } catch (e) { setError(e?.message || String(e)) }
  }

  const removeOrder = async (o) => {
    if (!window.confirm($t("Eliminare definitivamente l'ordine N°{0}?", [o.number]))) return
    try { await deletePurchaseOrder(o.id); await load() } catch (e) { setError(e?.message || String(e)) }
  }

  return (
    <Layout {...props} title={$t("Acquisti")}>
      <SectionLock section="purchases" {...props}>
        {error && <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{error} <button onClick={() => setError('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger-text)' }}>×</button></div>}
        {success && <div style={{ background: 'var(--success-bg)', color: 'var(--success-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{success}</div>}

        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Caricamento...")}</div>
        ) : (
          <>
          {reorder.length > 0 && (
            <div style={{ ...card, marginBottom: 12, borderColor: 'var(--warn-text)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <i className="ti ti-alert-triangle" style={{ color: 'var(--warn-text)', fontSize: 18 }} aria-hidden="true"></i>
                <div style={{ flex: 1, fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{reorder.length} {reorder.length === 1 ? $t("articolo da riordinare") : $t("articoli da riordinare")}</div>
                <button onClick={createReorder} disabled={reorderBusy} style={{ ...btnPrimary, opacity: reorderBusy ? 0.6 : 1 }}>{reorderBusy ? $t("Creazione...") : $t("Crea bozze d'ordine")}</button>
              </div>
              <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 8 }}>{$t("Sono sotto la scorta minima (contando anche la merce già ordinata). Le bozze si creano per fornitore abituale: controlla i costi prima di segnarle come ordinate.")}</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px 70px 80px 1fr', gap: 8, fontSize: 11, color: 'var(--text3)', padding: '0 0 4px', borderBottom: '0.5px solid var(--border)' }}>
                <span>{$t("Articolo")}</span><span style={{ textAlign: 'right' }}>{$t("In magazzino")}</span><span style={{ textAlign: 'right' }}>{$t("Minimo")}</span><span style={{ textAlign: 'right' }}>{$t("Suggerito")}</span><span>{$t("Fornitore")}</span>
              </div>
              {reorder.slice(0, 8).map(r => (
                <div key={r.product_id} style={{ display: 'grid', gridTemplateColumns: '1fr 80px 70px 80px 1fr', gap: 8, padding: '5px 0', fontSize: 12, borderBottom: '0.5px solid var(--border)', alignItems: 'center' }}>
                  <span style={{ color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</span>
                  <span style={{ textAlign: 'right', color: r.qty === 0 ? 'var(--danger-text)' : 'var(--text2)' }}>{r.qty}{r.on_order > 0 ? ` (+${r.on_order})` : ''}</span>
                  <span style={{ textAlign: 'right', color: 'var(--text2)' }}>{r.min_stock}</span>
                  <span style={{ textAlign: 'right', color: 'var(--text)', fontWeight: 500 }}>{r.suggested} {r.unit}</span>
                  <span style={{ color: r.supplier_name ? 'var(--text2)' : 'var(--warn-text)' }}>{r.supplier_name || $t("nessun fornitore abituale")}</span>
                </div>
              ))}
              {reorder.length > 8 && <div style={{ fontSize: 11, color: 'var(--text3)', paddingTop: 6 }}>{$t("… e altri")}{" "}{reorder.length - 8}</div>}
            </div>
          )}
          <div style={card}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ flex: 1, fontSize: 12, color: 'var(--text3)' }}>{$t("Ordina la merce ai fornitori e, quando arriva, premi")}{" "}<b>{$t("Ricevi")}</b>{$t(": il magazzino e il costo degli articoli si aggiornano da soli.")}</div>
              <button onClick={() => (suppliers.length ? openOrder(null) : setError($t("Per creare un ordine aggiungi prima un fornitore da Anagrafiche.")))} style={btnPrimary}>
                <i className="ti ti-plus" aria-hidden="true"></i>{" "}{$t("Nuovo ordine")}</button>
            </div>

            {suppliers.length === 0 && (
              <div style={{ background: 'var(--warn-bg)', color: 'var(--warn-text)', borderRadius: 8, padding: '8px 10px', fontSize: 12, marginBottom: 10 }}>{$t("Per creare un ordine serve almeno un fornitore: aggiungilo da")}{" "}<Link to="/contacts" style={{ color: "inherit", fontWeight: 600 }}>{$t("Anagrafiche")}</Link>.
              </div>
            )}

            {orders.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Nessun ordine d'acquisto")}</div>
            ) : (
              <div>
                <div style={{ display: 'grid', gridTemplateColumns: '60px 90px 1fr 90px 90px 210px', gap: 8, padding: '6px 8px', fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '0.5px solid var(--border)', marginBottom: 4 }}>
                  <span>{$t("N°")}</span><span>{$t("Data")}</span><span>{$t("Fornitore")}</span><span>{$t("Totale")}</span><span>{$t("Stato")}</span><span></span>
                </div>
                {orders.map(o => {
                  const st = STATUS[o.status] || STATUS.bozza
                  const open = o.status === 'bozza' || o.status === 'ordinato'
                  return (
                    <div key={o.id} style={{ display: 'grid', gridTemplateColumns: '60px 90px 1fr 90px 90px 210px', gap: 8, padding: '9px 8px', borderBottom: '0.5px solid var(--border)', alignItems: 'center', fontSize: 13 }}>
                      <span style={{ fontWeight: 500, color: 'var(--text)' }}>#{o.number}</span>
                      <span style={{ color: 'var(--text2)', fontSize: 12 }}>{o.date}</span>
                      <div>
                        <div style={{ color: 'var(--text)' }}>{o.supplier_name}</div>
                        <div style={{ fontSize: 11, color: 'var(--text3)' }}>{o.items.length}{" "}{o.items.length === 1 ? $t("articolo ·") : $t("articoli ·")}{" "}{o.items.reduce((s, i) => s + i.qty, 0)}{" "}{o.items.reduce((s, i) => s + i.qty, 0) === 1 ? $t("pezzo") : $t("pezzi")}</div>
                      </div>
                      <span style={{ color: 'var(--text)' }}>{eur(o.total)}</span>
                      <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: st.bg, color: st.cl, textAlign: 'center' }}>{st.label}</span>
                      <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                        {open && <button onClick={() => receive(o)} style={{ ...btnGhost, background: 'var(--success-bg)', color: 'var(--success-text)', border: '0.5px solid var(--success-text)' }}>{$t("Ricevi")}</button>}
                        <button onClick={() => openOrder(o)} style={btnGhost}>{open ? $t("Modifica") : $t("Dettagli")}</button>
                        {open && <button onClick={() => cancelOrder(o)} style={btnGhost}>{$t("Annulla")}</button>}
                        {(o.status === 'bozza' || o.status === 'annullato') && (
                          <button onClick={() => removeOrder(o)} style={{ ...btnGhost, background: 'var(--danger-bg)', color: 'var(--danger-text)', border: '0.5px solid var(--danger-text)' }}><i className="ti ti-trash" aria-hidden="true"></i></button>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
          </>
        )}

        {/* Modal ordine */}
        {orderModal && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 16 }}>
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 14, padding: 22, width: 640, maxWidth: '100%', maxHeight: '92vh', overflow: 'auto' }}>
              <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
                <i className="ti ti-truck-delivery" style={{ color: 'var(--accent)' }} aria-hidden="true"></i>
                {order.id ? $t("Ordine d'acquisto N°{0}", [order.number]) : $t("Nuovo ordine d'acquisto")}
                {order.id && <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: STATUS[order.status].bg, color: STATUS[order.status].cl }}>{STATUS[order.status].label}</span>}
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={label}>{$t("Fornitore *")}</label>
                <select value={order.supplier_id} disabled={readOnly} onChange={e => setOrder(o => ({ ...o, supplier_id: e.target.value }))} style={{ width: '100%' }}>
                  {suppliers.length === 0 && <option value="">{$t("Nessun fornitore")}</option>}
                  {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  {order.supplier_id && !suppliers.some(s => s.id === order.supplier_id) && <option value={order.supplier_id}>{$t("(fornitore eliminato)")}</option>}
                </select>
              </div>

              {!readOnly && (
                <div style={{ marginBottom: 10, position: 'relative' }}>
                  <label style={label}>{$t("Aggiungi articolo")}</label>
                  <input value={productSearch} onChange={e => setProductSearch(e.target.value)} placeholder={$t("Cerca per nome o barcode...")} style={{ width: '100%' }} />
                  {matches.length > 0 && (
                    <div style={{ position: 'absolute', left: 0, right: 0, top: '100%', zIndex: 5, background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 8, marginTop: 2, boxShadow: '0 6px 20px rgba(0,0,0,0.25)' }}>
                      {matches.map(p => (
                        <button key={p.id} onClick={() => addLine(p)} style={{ display: 'flex', justifyContent: 'space-between', width: '100%', padding: '7px 10px', border: 'none', background: 'transparent', cursor: 'pointer', fontSize: 13, color: 'var(--text)', textAlign: 'left' }}>
                          <span>{p.name}{p.barcode ? <span style={{ color: 'var(--text3)', fontSize: 11 }}> #{p.barcode}</span> : null}</span>
                          <span style={{ color: 'var(--text3)', fontSize: 12 }}>{$t("in magazzino:")}{" "}{p.qty} {p.unit}</span>
                        </button>
                      ))}
                    </div>
                  )}
                  {productSearch.trim() && matches.length === 0 && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>{$t("Nessun articolo trovato: crealo prima da Stock.")}</div>}
                </div>
              )}

              <div style={{ marginBottom: 10 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 70px 90px 80px 28px', gap: 8, padding: '6px 4px', fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '0.5px solid var(--border)' }}>
                  <span>{$t("Articolo")}</span><span>{$t("Qtà")}</span><span>{$t("Costo unit.")}</span><span style={{ textAlign: 'right' }}>{$t("Totale")}</span><span></span>
                </div>
                {order.items.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '18px 0', color: 'var(--text3)', fontSize: 12 }}>{$t("Nessun articolo nell'ordine")}</div>
                ) : order.items.map((i, idx) => (
                  <div key={i.product_id} style={{ display: 'grid', gridTemplateColumns: '1fr 70px 90px 80px 28px', gap: 8, padding: '6px 4px', alignItems: 'center', borderBottom: '0.5px solid var(--border)' }}>
                    <span style={{ fontSize: 13, color: 'var(--text)' }}>{i.name}</span>
                    <input type="number" min="1" step="1" value={i.qty} disabled={readOnly} onChange={e => setLine(idx, 'qty', e.target.value)} style={{ width: '100%' }} />
                    <input type="number" min="0" step="0.01" value={i.cost} disabled={readOnly} placeholder="€" onChange={e => setLine(idx, 'cost', e.target.value)} style={{ width: '100%' }} />
                    <span style={{ fontSize: 13, color: 'var(--text)', textAlign: 'right' }}>{eur((Number(i.qty) || 0) * (Number(i.cost) || 0))}</span>
                    {!readOnly && <button onClick={() => removeLine(idx)} title={$t("Rimuovi")} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger-text)', fontSize: 16 }}>×</button>}
                  </div>
                ))}
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12, padding: '10px 4px 0', fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>
                  <span>{$t("Totale ordine")}</span><span>{eur(orderTotal)}</span>
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={label}>{$t("Note")}</label>
                <textarea value={dataText(order.notes)} disabled={readOnly} onChange={e => setOrder(o => ({ ...o, notes: e.target.value }))} rows={2} style={{ width: '100%', resize: 'vertical' }} />
              </div>

              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                <button onClick={() => setOrderModal(false)} style={{ border: '0.5px solid var(--border)', borderRadius: 8, padding: '8px 16px', fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{readOnly ? $t("Chiudi") : $t("Annulla")}</button>
                {!readOnly && (
                  <>
                    <button onClick={() => saveOrder('bozza')} disabled={saving} style={{ border: '0.5px solid var(--border)', borderRadius: 8, padding: '8px 16px', fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Salva bozza")}</button>
                    <button onClick={() => saveOrder('ordinato')} disabled={saving} style={{ ...btnPrimary, padding: '8px 18px', fontSize: 13 }}>{saving ? $t("Salvataggio...") : $t("Salva come ordinato")}</button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </SectionLock>
    </Layout>
  )
}
