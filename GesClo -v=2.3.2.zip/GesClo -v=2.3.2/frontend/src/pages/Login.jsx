import React, { useState } from 'react'
import { login } from '../services/apiService'
import { $t } from '../i18n'
import LangSwitch from '../components/LangSwitch'

export default function Login({ onLogin, dark, setDark }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [serverUrl, setServerUrl] = useState(localStorage.getItem('gesclo_server') || 'http://localhost:3000')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handle = async () => {
    if (!username.trim() || password.length < 6) return setError($t("Username e password (min 6 caratteri) richiesti"))
    setLoading(true)
    setError('')
    try {
      localStorage.setItem('gesclo_server', serverUrl)
      const data = await login(username, password)
      onLogin({ username: data.username, role: data.role }, serverUrl)
    } catch(e) {
      setError(e.message || $t("Credenziali non valide"))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'var(--bg)'}}>
      <div style={{width:360,background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:16,padding:28}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:4}}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:34,height:34,borderRadius:9,background:'var(--accent)',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <i className="ti ti-box" style={{color:'#fff',fontSize:18}} aria-hidden="true"></i>
            </div>
            <span style={{fontWeight:600,fontSize:18,color:'var(--text)'}}>{$t("GesClo")}</span>
          </div>
          <div style={{display:'flex',gap:6}}>
            <LangSwitch />
            <button onClick={()=>setDark(!dark)} style={{width:32,height:32,borderRadius:8,border:'0.5px solid var(--border)',background:'transparent',cursor:'pointer',color:'var(--text3)',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <i className={`ti ${dark?'ti-sun':'ti-moon'}`} style={{fontSize:16}} aria-hidden="true"></i>
            </button>
          </div>
        </div>
        <p style={{fontSize:12,color:'var(--text3)',marginBottom:22}}>{$t("Accedi al gestionale")}</p>
        {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',fontSize:12,borderRadius:8,padding:'7px 10px',marginBottom:12}}>{error}</div>}
        {[
          [$t("Indirizzo server"), serverUrl, setServerUrl, 'text', 'http://192.168.1.1:3000'],
          [$t("Username"), username, setUsername, 'text', 'username'],
          [$t("Master password"), password, setPassword, 'password', '••••••••••••'],
        ].map(([label, val, set, type, ph]) => (
          <div key={label} style={{marginBottom:12}}>
            <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{label}</label>
            <input type={type} value={val} onChange={e=>set(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&handle()}
              placeholder={ph} style={{width:'100%'}} />
          </div>
        ))}
        <button onClick={handle} disabled={loading} style={{width:'100%',background:loading?'var(--bg3)':'var(--accent)',border:'none',borderRadius:9,padding:'10px',fontSize:13,color:loading?'var(--text3)':'#fff',cursor:loading?'default':'pointer',fontWeight:500,marginTop:4}}>
          {loading ? $t("Accesso in corso...") : $t("Accedi →")}
        </button>
      </div>
    </div>
  )
}
