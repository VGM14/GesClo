import React, { useState, useEffect } from 'react'
import Layout from '../components/Layout'
import { getStats, getMovements, getSales } from '../services/apiService'
import { $t, customerLabel } from '../i18n'

export default function Dashboard(props) {
  const [stats, setStats] = useState({})
  const [movements, setMovements] = useState([])
  const [sales, setSales] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    Promise.all([getStats(), getMovements(), getSales()])
      .then(([s, m, sl]) => { setStats(s); setMovements(m.slice(0,4)); setSales(sl.slice(0,4)) })
      .catch(e => setError(e?.message || $t("Errore caricamento dati")))
      .finally(() => setLoading(false))
  }, [])

  const metrics = [
    { label:$t("Articoli"), value: loading?'...':stats.totalProducts, icon:'ti-box', color:'var(--accent)' },
    { label:$t("Vendite oggi"), value: loading?'...':stats.todaySales, icon:'ti-shopping-cart', color:'var(--success-text)' },
    { label:$t("Incasso oggi"), value: loading?'...':`€${parseFloat(stats.todayRevenue||0).toFixed(2)}`, icon:'ti-cash', color:'var(--info-text)' },
    { label:$t("Alert"), value: loading?'...':(stats.outOfStock||0)+(stats.lowStock||0), icon:'ti-bell', color:'var(--warn-text)' },
  ]

  return (
    <Layout {...props} title={$t("Dashboard")}>
      {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',borderRadius:10,padding:'8px 12px',marginBottom:12,fontSize:12}}>{error}</div>}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:14}}>
        {metrics.map(m=>(
          <div key={m.label} style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',marginBottom:6,display:'flex',alignItems:'center',gap:6}}>
              <i className={`ti ${m.icon}`} style={{fontSize:14,color:m.color}} aria-hidden="true"></i>{m.label}
            </div>
            <div style={{fontSize:24,fontWeight:500,color:'var(--text)'}}>{m.value}</div>
          </div>
        ))}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10}}>{$t("Ultimi movimenti")}</div>
          {movements.length===0 ? <div style={{color:'var(--text3)',fontSize:13,textAlign:'center',padding:'16px 0'}}>{$t("Nessun movimento")}</div>
          : movements.map(m=>(
            <div key={m.id} style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'0.5px solid var(--border)',fontSize:12}}>
              <span style={{color:'var(--text)'}}>{m.product_name}</span>
              <span style={{color:m.type==='entrata'?'var(--success-text)':'var(--danger-text)',fontWeight:500}}>
                {m.type==='entrata'?'+':'-'}{m.qty}
              </span>
            </div>
          ))}
        </div>
        <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10}}>{$t("Ultime vendite")}</div>
          {sales.length===0 ? <div style={{color:'var(--text3)',fontSize:13,textAlign:'center',padding:'16px 0'}}>{$t("Nessuna vendita")}</div>
          : sales.map(s=>(
            <div key={s.id} style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'0.5px solid var(--border)',fontSize:12}}>
              <span style={{color:'var(--text)'}}>{customerLabel(s.customer_name)}</span>
              <span style={{color:'var(--accent)',fontWeight:500}}>€{parseFloat(s.total||0).toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  )
}
