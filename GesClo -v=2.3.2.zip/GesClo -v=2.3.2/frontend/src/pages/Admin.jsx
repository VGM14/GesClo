import React, { useState, useEffect, useRef } from 'react'
import Layout from '../components/Layout'
import { getAuthToken, getUsers, addUser, updateUser, deleteUser, getStats, getAIConfig, saveAIConfig, getCashRegister, updateCashRegister, checkHealth, stopServer, restartServer, closeAll, shutdownServer, checkLauncher, launchServer, getTerminalWsUrl, getSettings, saveSetting, clearSales, getMode, setOperatingMode, getNetworkInfo, OPERATING_MODES, downloadBackup, restoreBackup } from '../services/apiService'
import { $t, LOCALE } from '../i18n'

const TABS = ['Dashboard','Utenti','Cassa','AI Setup','Log','Sistema','Hardware']
// Modelli Groq verificati disponibili (agosto 2026) — llama-3.1-8b-instant e
// llama-3.3-70b-versatile sono stati dismessi da Groq, sostituiti dai modelli GPT-OSS.
const GROQ_MODELS = [
  { value: 'openai/gpt-oss-20b',  label: $t("GPT-OSS 20B — veloce (consigliato)") },
  { value: 'openai/gpt-oss-120b', label: $t("GPT-OSS 120B — più capace, più lento") },
  { value: '__custom__',          label: $t("Personalizzato...") },
]
const ALL_ROLES    = ['Super Admin','Admin','Manager','Operatore','Kiosk']
const NON_SA_ROLES = ['Admin','Manager','Operatore','Kiosk']

const DEFAULT_CASH = {
  name: '', address: '', vat_number: '',
  printer_type: 'a4',
  printer_ip: '', printer_port: '9100',
  header_text: '', footer_text: $t("Grazie!"),
  show_tax: false, tax_rate: 22, currency: 'EUR',
  auto_print: true
}

export default function Admin(props) {
  const [tab, setTab] = useState('Dashboard')
  const [users, setUsers] = useState([])
  const [stats, setStats] = useState({})
  const [modal, setModal] = useState(null)
  const [form, setForm] = useState({ username:'', password:'', role:'Operatore', email:'' })
  const [search, setSearch] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  // AI
  const [aiProvider, setAiProvider] = useState('groq')
  const [aiKey, setAiKey] = useState('')
  const [aiUrl, setAiUrl] = useState('')
  const [aiModel, setAiModel] = useState('')
  const [aiModelCustom, setAiModelCustom] = useState('')
  const [aiSaved, setAiSaved] = useState(false)
  // Cassa
  const [cashForm, setCashForm] = useState(DEFAULT_CASH)
  const [cashSaved, setCashSaved] = useState(false)
  // Server status
  const [serverHealth, setServerHealth] = useState(null)
  const [sysLogs, setSysLogs] = useState([])
  // Sistema
  const [sysAction, setSysAction] = useState(null)
  const [sysMsg, setSysMsg] = useState('')
  // Modalità operativa (Standalone / Network Server / Network Terminal)
  const [opMode, setOpMode] = useState(getMode())
  const [terminalIp, setTerminalIp] = useState(localStorage.getItem('gesclo_server') || '')
  const [lanIp, setLanIp] = useState('')
  const [modeSaved, setModeSaved] = useState(false)
  // Hardware / NFC
  const [nfcKey, setNfcKey]       = useState('')
  const [showNfcKey, setShowNfcKey] = useState(false)
  // Backup / ripristino
  const [backupMsg, setBackupMsg] = useState(null) // { ok: bool, text: string }
  const [backupBusy, setBackupBusy] = useState(false)
  const restoreInputRef = useRef(null)
  const [posPin, setPosPin]       = useState('')
  const [posWallpaper, setPosWallpaper] = useState('')
  const [nfcSaved, setNfcSaved]   = useState(false)
  const [hwLoaded, setHwLoaded]   = useState(false)
  // Launcher (porta 3002)
  const [launcherOk, setLauncherOk] = useState(null)
  const [launching, setLaunching] = useState(false)
  // Terminale PowerShell
  const [termOpen, setTermOpen] = useState(false)
  const [termOutput, setTermOutput] = useState([])
  const [termInput, setTermInput] = useState('')
  const termWsRef    = useRef(null)
  const termOutRef   = useRef(null)

  const addLog = (type, msg) => setSysLogs(p => [
    { time: new Date().toLocaleTimeString(LOCALE), type, msg },
    ...p.slice(0, 49)
  ])

  useEffect(() => {
    if (tab === 'Utenti')    loadUsers()
    if (tab === 'Dashboard') { loadStats(); loadUsers(); pingHealth() }
    if (tab === 'AI Setup')  loadAISettings()
    if (tab === 'Cassa')     loadCash()
    if (tab === 'Log')       pingHealth()
    if (tab === 'Sistema')   { pingHealth(); loadNetworkInfo() }
    if (tab === 'Hardware' && !hwLoaded) loadHardware()
  }, [tab])

  // Chiudi WS terminale se il componente viene smontato
  useEffect(() => () => { termWsRef.current?.close() }, [])

  const pingHealth = () => checkHealth()
    .then(h => {
      setServerHealth({ online: true, ...h })
      setLauncherOk(null)
      addLog('OK', $t("Server API online — uptime {0}s", [h.uptime]))
      addLog('OK', $t("Database: {0} articoli, {1} vendite", [h.db.products, h.db.sales]))
    })
    .catch(() => {
      setServerHealth({ online: false })
      addLog('ERR', $t("Server API non raggiungibile"))
      // Verifica se il launcher è disponibile per riavviare il server
      checkLauncher().then(() => setLauncherOk(true)).catch(() => setLauncherOk(false))
    })

  const loadNetworkInfo = () => getNetworkInfo().then(info => setLanIp(info.lanIp)).catch(() => setLanIp(''))

  const saveMode = () => {
    setOperatingMode(opMode, opMode === 'Network Terminal' ? terminalIp.trim() : '')
    setModeSaved(true)
    setSysMsg($t("Modalità salvata. Ricarica la pagina per applicarla."))
    setTimeout(() => setModeSaved(false), 3000)
  }

  const handleLaunch = async () => {
    setLaunching(true)
    try {
      await launchServer()
      setSysMsg($t("Server in avvio — attendi ~5 secondi poi premi \"Verifica stato\"."))
      setTimeout(() => { pingHealth(); setLaunching(false) }, 6000)
    } catch {
      setSysMsg($t("Launcher non raggiungibile. Esegui avvia.bat sul PC server."))
      setLaunching(false)
    }
  }

  const openTerminal = async () => {
    if (termWsRef.current) return
    const token = getAuthToken()
    const url   = `${getTerminalWsUrl()}?token=${encodeURIComponent(token)}`
    const ws    = new WebSocket(url)
    ws.onopen    = () => setTermOpen(true)
    ws.onmessage = e => {
      setTermOutput(p => [...p, e.data])
      setTimeout(() => { if (termOutRef.current) termOutRef.current.scrollTop = termOutRef.current.scrollHeight }, 20)
    }
    ws.onclose  = () => { termWsRef.current = null; setTermOpen(false) }
    ws.onerror  = () => { setTermOutput(p => [...p, '\n' + $t("[Errore connessione WebSocket]") + '\n']) }
    termWsRef.current = ws
  }

  const closeTerminal = () => {
    termWsRef.current?.close()
    termWsRef.current = null
    setTermOpen(false)
    setTermOutput([])
    setTermInput('')
  }

  const sendCommand = e => {
    e.preventDefault()
    if (!termWsRef.current || termWsRef.current.readyState !== 1 || !termInput.trim()) return
    termWsRef.current.send(termInput)
    setTermInput('')
  }

  const loadUsers     = () => getUsers().then(setUsers).catch(e=>setError(e?.message||String(e)))
  const loadStats     = () => getStats().then(setStats).catch(e=>setError(e?.message||String(e)))
  const loadAISettings = () => getAIConfig().then(cfg => {
    setAiProvider(cfg.provider || 'groq')
    setAiKey(cfg.key || '')
    setAiUrl(cfg.url || '')
    const known = GROQ_MODELS.some(m => m.value === cfg.model)
    if (cfg.model && !known) { setAiModel('__custom__'); setAiModelCustom(cfg.model) }
    else setAiModel(cfg.model || GROQ_MODELS[0].value)
  }).catch(()=>{})
  const loadCash = () => getCashRegister().then(cr => setCashForm({ ...DEFAULT_CASH, ...cr })).catch(()=>{})

  const loadHardware = () => getSettings().then(s => {
    setNfcKey(s.nfc_api_key || '')
    setPosPin(s.pos_pin || '')
    setPosWallpaper(s.pos_wallpaper || '')
    setHwLoaded(true)
  }).catch(()=>{})

  const saveHardware = async () => {
    try {
      await saveSetting('nfc_api_key', nfcKey.trim())
      await saveSetting('pos_pin', posPin.trim())
      await saveSetting('pos_wallpaper', posWallpaper.trim())
      setNfcSaved(true); setTimeout(() => setNfcSaved(false), 3000)
    } catch(e) { setError(e?.message || String(e)) }
  }

  const saveAI = async () => {
    try {
      const model = aiProvider === 'groq' ? (aiModel === '__custom__' ? aiModelCustom.trim() : aiModel) : ''
      await saveAIConfig({ provider: aiProvider, key: aiKey, url: aiUrl, model })
      setAiSaved(true); setTimeout(()=>setAiSaved(false), 3000)
    } catch(e) { setError(e?.message || String(e)) }
  }

  const saveCash = async () => {
    try {
      await updateCashRegister(cashForm)
      setCashSaved(true); setTimeout(()=>setCashSaved(false), 3000)
    } catch(e) { setError(e?.message || String(e)) }
  }

  const setCash = (field, value) => setCashForm(p => ({ ...p, [field]: value }))

  const generateNfcKey = () => {
    const bytes = crypto.getRandomValues(new Uint8Array(16))
    setNfcKey([...bytes].map(b => b.toString(16).padStart(2, '0')).join(''))
    setShowNfcKey(true)
  }

  const handleBackup = async () => {
    setBackupBusy(true); setBackupMsg(null)
    try {
      await downloadBackup()
      setBackupMsg({ ok: true, text: $t("Backup scaricato. Conservalo in un posto sicuro: contiene tutti i dati.") })
    } catch (e) { setBackupMsg({ ok: false, text: e?.message || String(e) }) }
    setBackupBusy(false)
  }

  const handleRestoreFile = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!window.confirm($t("Ripristinare il database dal file \"{0}\"?\n\nTUTTI i dati attuali (articoli, vendite, utenti) verranno sostituiti da quelli del backup. Ne viene comunque tenuta una copia di sicurezza sul server. Dopo il ripristino dovrai rifare l'accesso.", [file.name]))) return
    setBackupBusy(true); setBackupMsg(null)
    try {
      await restoreBackup(file)
      window.alert($t("Ripristino completato. Ora rifai l'accesso."))
      window.location.reload()
    } catch (err) {
      setBackupMsg({ ok: false, text: err?.message || String(err) })
      setBackupBusy(false)
    }
  }

  const openAdd = () => { setForm({ username:'', password:'', role:'Operatore', email:'' }); setModal('add') }
  const openEdit = (u) => { setForm({ username:u.username, password:'', role:u.role, email:u.email||'' }); setModal(u.id) }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (modal === 'add') {
        if (!form.username.trim()) { setError($t("Username obbligatorio")); setSaving(false); return }
        if (form.password.length < 8) { setError($t("Password minimo 8 caratteri")); setSaving(false); return }
        await addUser(form)
      } else {
        await updateUser(modal, form)
      }
      loadUsers(); setModal(null)
    } catch(e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const handleDelete = async (id) => {
    if (!window.confirm($t("Eliminare questo utente? L'azione è irreversibile."))) return
    try {
      await deleteUser(id)
      loadUsers()
    } catch(e) { setError(e?.message || String(e)) }
  }

  const roleColor = (r) => {
    if (!r) return {bg:'var(--bg3)',cl:'var(--text3)'}
    const rl = r.toLowerCase()
    if (rl.includes('super')) return {bg:'var(--accent-bg)',cl:'var(--accent-text)'}
    if (rl.includes('admin')) return {bg:'var(--info-bg)',cl:'var(--info-text)'}
    if (rl.includes('manager')) return {bg:'var(--warn-bg)',cl:'var(--warn-text)'}
    if (rl.includes('operatore')||rl.includes('operator')) return {bg:'var(--success-bg)',cl:'var(--success-text)'}
    return {bg:'var(--bg3)',cl:'var(--text3)'}
  }

  const filtered = users.filter(u => u.username?.toLowerCase().includes(search.toLowerCase()))

  return (
    <Layout {...props} title={$t("Pannello Admin")}>
      {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',borderRadius:10,padding:'8px 12px',marginBottom:12,fontSize:12}}>{error} <button onClick={()=>setError('')} style={{background:'none',border:'none',cursor:'pointer',color:'var(--danger-text)'}}>×</button></div>}

      <div style={{display:'flex',gap:6,marginBottom:14,flexWrap:'wrap'}}>
        {TABS.map(t=>(
          <button key={t} onClick={()=>setTab(t)} style={{
            padding:'5px 14px',borderRadius:20,fontSize:12,cursor:'pointer',
            border:`0.5px solid ${tab===t?'var(--accent)':'var(--border)'}`,
            background:tab===t?'var(--accent-bg)':'transparent',
            color:tab===t?'var(--accent-text)':'var(--text3)',
          }}>{$t(t)}</button>
        ))}
      </div>

      {tab==='Dashboard' && (
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12}}>
          {/* Stato server — reale */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-server" style={{fontSize:14}} aria-hidden="true"></i>{$t("Stato server")}<button onClick={pingHealth} title={$t("Aggiorna")} style={{marginLeft:'auto',background:'none',border:'none',cursor:'pointer',color:'var(--text3)',padding:'0 4px'}}>
                <i className="ti ti-refresh" style={{fontSize:13}} aria-hidden="true"></i>
              </button>
            </div>
            {[
              [$t("API Server"),  serverHealth == null ? '...' : serverHealth.online ? $t("Online") : $t("Offline"),  serverHealth?.online ? 'green' : serverHealth == null ? 'gray' : 'red'],
              [$t("Database"),    serverHealth?.online ? $t("OK ({0} art.)", [serverHealth.db?.products||0]) : serverHealth == null ? '...' : 'N/D', serverHealth?.online ? 'green' : serverHealth == null ? 'gray' : 'red'],
              [$t("Uptime"),      serverHealth?.online ? `${serverHealth.uptime}s` : '—', 'blue'],
              [$t("Frontend"),    $t("Online"), 'green'],
            ].map(([l,v,c])=>(
              <div key={l} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'7px 0',borderBottom:'0.5px solid var(--border)'}}>
                <span style={{fontSize:13,color:'var(--text)'}}>{l}</span>
                <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,
                  background:c==='green'?'var(--success-bg)':c==='blue'?'var(--info-bg)':c==='red'?'var(--danger-bg)':'var(--bg3)',
                  color:c==='green'?'var(--success-text)':c==='blue'?'var(--info-text)':c==='red'?'var(--danger-text)':'var(--text3)',
                }}>{v}</span>
              </div>
            ))}
          </div>

          {/* Inventario */}
          {[
            [$t("Inventario"),'ti-box',[[$t("Articoli totali"),String(stats.totalProducts||0),'blue'],[$t("Stock basso"),String(stats.lowStock||0),'warn'],[$t("Esauriti"),String(stats.outOfStock||0),'red']]],
            [$t("Movimenti"),'ti-arrows-exchange',[[$t("Oggi"),String(stats.todayMovements||0),'green'],[$t("Utenti"),String(users.length||0),'purple']]],
          ].map(([title,icon,rows])=>(
            <div key={title} style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
              <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10,display:'flex',alignItems:'center',gap:6}}>
                <i className={`ti ${icon}`} style={{fontSize:14}} aria-hidden="true"></i>{title}
              </div>
              {rows.map(([l,v,c])=>(
                <div key={l} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'7px 0',borderBottom:'0.5px solid var(--border)'}}>
                  <span style={{fontSize:13,color:'var(--text)'}}>{l}</span>
                  <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,
                    background:c==='green'?'var(--success-bg)':c==='purple'?'var(--accent-bg)':c==='warn'?'var(--warn-bg)':c==='blue'?'var(--info-bg)':c==='red'?'var(--danger-bg)':'var(--bg3)',
                    color:c==='green'?'var(--success-text)':c==='purple'?'var(--accent-text)':c==='warn'?'var(--warn-text)':c==='blue'?'var(--info-text)':c==='red'?'var(--danger-text)':'var(--text3)',
                  }}>{v}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {tab==='Utenti' && (
        <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={$t("Cerca utente...")} style={{flex:1}} />
            <button onClick={openAdd} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'7px 14px',fontSize:12,color:'#fff',cursor:'pointer',fontWeight:500,flexShrink:0}}>
              <i className="ti ti-plus" aria-hidden="true"></i>{" "}{$t("Nuovo utente")}</button>
          </div>
          {filtered.length === 0 ? (
            <div style={{textAlign:'center',padding:'32px 0',color:'var(--text3)',fontSize:13}}>
              {users.length === 0 ? $t("Nessun utente") : $t("Nessun risultato")}
            </div>
          ) : filtered.map(u=>(
            <div key={u.id} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 0',borderBottom:'0.5px solid var(--border)'}}>
              <div style={{width:32,height:32,borderRadius:'50%',background:'var(--accent-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:500,color:'var(--accent-text)',flexShrink:0}}>
                {u.username?.[0]?.toUpperCase()||'U'}
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:500,color:'var(--text)'}}>{u.username}</div>
                {u.email && <div style={{fontSize:11,color:'var(--text3)'}}>{u.email}</div>}
              </div>
              <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,background:roleColor(u.role).bg,color:roleColor(u.role).cl}}>{$t(u.role)}</span>
              <button onClick={()=>openEdit(u)} style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:7,padding:'4px 10px',fontSize:11,color:'var(--text)',cursor:'pointer'}}>{$t("Modifica")}</button>
              <button onClick={()=>handleDelete(u.id)} style={{background:'var(--danger-bg)',border:'0.5px solid var(--danger-text)',borderRadius:7,padding:'4px 10px',fontSize:11,color:'var(--danger-text)',cursor:'pointer'}}>{$t("Elimina")}</button>
            </div>
          ))}
        </div>
      )}

      {tab==='Cassa' && (
        <div style={{maxWidth:560,display:'flex',flexDirection:'column',gap:12}}>
          {/* Dati azienda */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:12,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-building-store" style={{fontSize:14}} aria-hidden="true"></i>{$t("Intestazione documenti")}</div>
            {[[$t("Nome azienda / punto vendita"),'text','name',$t("Es: Mario Rossi — Ferramenta")],[$t("Indirizzo"),'text','address',$t("Via Roma 1, 00100 Roma")],[$t("P.IVA / C.F. (opzionale)"),'text','vat_number',$t("IT12345678901")],[$t("Testo header scontrino"),'text','header_text',$t("Testo sopra lo scontrino")],[$t("Testo footer scontrino"),'text','footer_text',$t("Grazie per il tuo acquisto!")]].map(([label,type,field,ph])=>(
              <div key={field} style={{marginBottom:10}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{label}</label>
                <input type={type} value={cashForm[field]||''} onChange={e=>setCash(field,e.target.value)} placeholder={ph} style={{width:'100%'}} />
              </div>
            ))}
          </div>

          {/* Stampante */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:12,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-printer" style={{fontSize:14}} aria-hidden="true"></i>{$t("Stampante / Registratore di cassa")}</div>
            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:6}}>{$t("Tipo stampante")}</label>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6}}>
                {[['a4','ti-file-text',$t("Stampante A4"),$t("Stampa su foglio A4 normale")],['thermal_80','ti-receipt',$t("Termica 80mm"),$t("Stampante scontrini standard")],['thermal_58','ti-receipt-2',$t("Termica 58mm"),$t("Scontrini piccoli")]].map(([val,icon,label,desc])=>(
                  <button key={val} onClick={()=>setCash('printer_type',val)} style={{
                    padding:'10px 8px',borderRadius:10,cursor:'pointer',textAlign:'center',
                    border:`0.5px solid ${cashForm.printer_type===val?'var(--accent)':'var(--border)'}`,
                    background:cashForm.printer_type===val?'var(--accent-bg)':'transparent',
                  }}>
                    <i className={`ti ${icon}`} style={{fontSize:20,display:'block',marginBottom:4,color:cashForm.printer_type===val?'var(--accent-text)':'var(--text3)'}} aria-hidden="true"></i>
                    <div style={{fontSize:12,fontWeight:500,color:cashForm.printer_type===val?'var(--accent-text)':'var(--text)'}}>{label}</div>
                    <div style={{fontSize:10,color:'var(--text3)',marginTop:2}}>{desc}</div>
                  </button>
                ))}
              </div>
            </div>
            <label style={{display:'flex',alignItems:'flex-start',gap:8,cursor:'pointer',fontSize:13,color:'var(--text)',marginBottom:12}}>
              <input type="checkbox" checked={cashForm.auto_print !== false} onChange={e=>setCash('auto_print',e.target.checked)} style={{marginTop:3}} />
              <span>{$t("Stampa lo scontrino automaticamente a fine vendita")}<span style={{display:'block',fontSize:11,color:'var(--text3)',marginTop:2}}>{$t("Si apre la finestra di stampa del browser. Per stampare senza finestra, avvia il browser con l'opzione")}{" "}<code>{$t("--kiosk-printing")}</code>{" "}{$t("(usa la stampante predefinita di Windows).")}</span>
              </span>
            </label>
            <div style={{background:'var(--info-bg)',color:'var(--info-text)',borderRadius:8,padding:'8px 10px',fontSize:12,marginBottom:10}}>
              <b>{$t("Stampante di rete (opzionale):")}</b>{" "}{$t("se hai una stampante termica con IP fisso, inserisci i dati sotto per stampa diretta futura.")}</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr auto',gap:8}}>
              <div>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("IP stampante (opzionale)")}</label>
                <input value={cashForm.printer_ip||''} onChange={e=>setCash('printer_ip',e.target.value)} placeholder="192.168.1.100" style={{width:'100%'}} />
              </div>
              <div>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Porta")}</label>
                <input value={cashForm.printer_port||'9100'} onChange={e=>setCash('printer_port',e.target.value)} placeholder="9100" style={{width:72}} />
              </div>
            </div>
          </div>

          {/* IVA */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:12,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-percentage" style={{fontSize:14}} aria-hidden="true"></i>{$t("IVA e valuta")}</div>
            <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:10}}>
              <label style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',fontSize:13,color:'var(--text)'}}>
                <input type="checkbox" checked={!!cashForm.show_tax} onChange={e=>setCash('show_tax',e.target.checked)} />{$t("Mostra IVA sullo scontrino")}</label>
            </div>
            {cashForm.show_tax && (
              <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:10}}>
                <label style={{fontSize:11,color:'var(--text2)'}}>{$t("Aliquota IVA %")}</label>
                <input type="number" value={cashForm.tax_rate||22} onChange={e=>setCash('tax_rate',parseFloat(e.target.value)||22)} min="0" max="100" style={{width:70}} />
              </div>
            )}
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <label style={{fontSize:11,color:'var(--text2)'}}>{$t("Valuta")}</label>
              <select value={cashForm.currency||'EUR'} onChange={e=>setCash('currency',e.target.value)} style={{width:100}}>
                <option value="EUR">{$t("EUR (€)")}</option>
                <option value="USD">{$t("USD ($)")}</option>
                <option value="GBP">{$t("GBP (£)")}</option>
                <option value="CHF">{$t("CHF")}</option>
              </select>
            </div>
          </div>

          <div style={{display:'flex',gap:8,alignItems:'center'}}>
            <button onClick={saveCash} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'8px 20px',fontSize:13,color:'#fff',cursor:'pointer',fontWeight:500}}>{$t("Salva configurazione")}</button>
            {cashSaved && <span style={{fontSize:12,background:'var(--success-bg)',color:'var(--success-text)',padding:'4px 10px',borderRadius:20}}>{$t("Salvato!")}</span>}
          </div>
        </div>
      )}

      {tab==='AI Setup' && (
        <div style={{maxWidth:480,background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10,display:'flex',alignItems:'center',gap:6}}>
            <i className="ti ti-sparkles" style={{fontSize:14}} aria-hidden="true"></i>{$t("Configurazione AI")}</div>
          <div style={{background:'var(--info-bg)',color:'var(--info-text)',borderRadius:8,padding:'8px 10px',fontSize:12,marginBottom:14}}>{$t("La configurazione viene salvata sul server — tutti i dispositivi la useranno automaticamente.")}</div>
          <div style={{marginBottom:10}}>
            <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Provider")}</label>
            <select value={aiProvider} onChange={e=>setAiProvider(e.target.value)} style={{width:'100%'}}>
              <option value="groq">{$t("Groq (gratuito, consigliato)")}</option>
              <option value="gemini">{$t("Google Gemini (gratuito)")}</option>
              <option value="local">{$t("PC AI locale (Ollama)")}</option>
            </select>
          </div>
          {aiProvider==='local' ? (
            <div style={{marginBottom:10}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("URL PC AI")}</label>
              <input value={aiUrl} onChange={e=>setAiUrl(e.target.value)} placeholder="http://192.168.1.5:11434" style={{width:'100%'}} />
            </div>
          ) : (
            <div style={{marginBottom:10}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("API Key")}</label>
              <input type="password" value={aiKey} onChange={e=>setAiKey(e.target.value)} placeholder={$t("Incolla la tua API key...")} style={{width:'100%'}} />
              <p style={{fontSize:11,color:'var(--text3)',marginTop:4}}>
                {aiProvider==='groq' && <a href="https://console.groq.com" target="_blank" rel="noreferrer" style={{color:'var(--info-text)'}}>{$t("Ottieni chiave Groq gratuita →")}</a>}
                {aiProvider==='gemini' && <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" style={{color:'var(--info-text)'}}>{$t("Ottieni chiave Gemini gratuita →")}</a>}
              </p>
            </div>
          )}
          {aiProvider==='groq' && (
            <div style={{marginBottom:10}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Modello")}</label>
              <select value={aiModel} onChange={e=>setAiModel(e.target.value)} style={{width:'100%'}}>
                {GROQ_MODELS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
              {aiModel==='__custom__' && (
                <input value={aiModelCustom} onChange={e=>setAiModelCustom(e.target.value)} placeholder={$t("es: openai/gpt-oss-120b")}
                  style={{width:'100%',marginTop:6}} />
              )}
              <p style={{fontSize:11,color:'var(--text3)',marginTop:4}}>{$t("Groq dismette periodicamente i modelli — se GesBot smette di rispondere, controlla i modelli attivi su")}{' '}
                <a href="https://console.groq.com/docs/models" target="_blank" rel="noreferrer" style={{color:'var(--info-text)'}}>{$t("console.groq.com/docs/models")}</a>.
              </p>
            </div>
          )}
          <div style={{display:'flex',gap:8,alignItems:'center'}}>
            <button onClick={saveAI} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'7px 16px',fontSize:13,color:'#fff',cursor:'pointer',fontWeight:500}}>{$t("Salva configurazione")}</button>
            {aiSaved && <span style={{fontSize:12,background:'var(--success-bg)',color:'var(--success-text)',padding:'4px 10px',borderRadius:20}}>{$t("Salvato sul server!")}</span>}
          </div>
        </div>
      )}

      {tab==='Log' && (
        <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
          <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10,display:'flex',alignItems:'center',gap:6}}>{$t("Log di sistema")}<button onClick={pingHealth} style={{marginLeft:'auto',background:'none',border:'none',cursor:'pointer',color:'var(--text3)',fontSize:11,display:'flex',alignItems:'center',gap:4}}>
              <i className="ti ti-refresh" style={{fontSize:12}} aria-hidden="true"></i>{" "}{$t("Aggiorna")}</button>
          </div>
          {sysLogs.length === 0 ? (
            <div style={{textAlign:'center',padding:'24px 0',color:'var(--text3)',fontSize:13}}>{$t("Nessun evento registrato")}</div>
          ) : sysLogs.map((log, i) => (
            <div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'7px 0',borderBottom:'0.5px solid var(--border)',fontSize:12}}>
              <span style={{color:'var(--text3)',minWidth:56,flexShrink:0}}>{log.time}</span>
              <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,flexShrink:0,
                background:log.type==='OK'?'var(--success-bg)':log.type==='ERR'?'var(--danger-bg)':'var(--info-bg)',
                color:log.type==='OK'?'var(--success-text)':log.type==='ERR'?'var(--danger-text)':'var(--info-text)',
              }}>{log.type}</span>
              <span style={{color:'var(--text)'}}>{log.msg}</span>
            </div>
          ))}
        </div>
      )}

      {tab==='Sistema' && (
        <div style={{maxWidth:580}}>

          {/* Modalità operativa */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px',marginBottom:16}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:12,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-network" style={{fontSize:14}} aria-hidden="true"></i>{$t("Modalità operativa")}</div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6,marginBottom:12}}>
              {OPERATING_MODES.map(m => (
                <button key={m} onClick={()=>setOpMode(m)} style={{
                  padding:'10px 8px',borderRadius:10,cursor:'pointer',textAlign:'center',
                  border:`0.5px solid ${opMode===m?'var(--accent)':'var(--border)'}`,
                  background:opMode===m?'var(--accent-bg)':'transparent',
                  color:opMode===m?'var(--accent-text)':'var(--text)',fontSize:12,fontWeight:500,
                }}>
                  {m.replace(' Point of Sale','').replace('Network ','')}
                </button>
              ))}
            </div>
            {opMode === 'Network Server' && (
              <p style={{fontSize:12,color:'var(--text3)',margin:'0 0 4px'}}>{$t("I terminali devono collegarsi a")}{" "}<b style={{color:'var(--text)'}}>{lanIp || '...'}</b>{" "}{$t("sulla porta 3001.")}</p>
            )}
            {opMode === 'Network Terminal' && (
              <div style={{marginBottom:8}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Indirizzo del server")}</label>
                <input value={terminalIp} onChange={e=>setTerminalIp(e.target.value)} placeholder="192.168.1.10" style={{width:'100%'}} />
              </div>
            )}
            {opMode === 'Standalone' && (
              <p style={{fontSize:12,color:'var(--text3)',margin:'0 0 4px'}}>{$t("Server e interfaccia girano solo su questo PC, nessun accesso da altri dispositivi previsto.")}</p>
            )}
            <button onClick={saveMode} style={{marginTop:8,background:modeSaved?'var(--success-bg)':'var(--accent)',border:'none',borderRadius:8,padding:'7px 16px',fontSize:12,color:modeSaved?'var(--success-text)':'#fff',cursor:'pointer',fontWeight:500}}>
              {modeSaved ? $t("Salvato ✓") : $t("Salva modalità")}
            </button>
          </div>

          {/* Backup e ripristino */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px',marginBottom:16}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:12,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-database-export" style={{fontSize:14}} aria-hidden="true"></i>{$t("Backup e ripristino")}</div>
            {props.user?.role !== 'Super Admin' ? (
              <p style={{fontSize:12,color:'var(--text3)',margin:0}}>{$t("Riservato al Super Admin: il backup contiene anche gli account degli utenti.")}</p>
            ) : (
              <>
                <p style={{fontSize:12,color:'var(--text3)',margin:'0 0 10px',lineHeight:1.6}}>{$t("Il backup è un unico file con tutti i dati (articoli, vendite, clienti, utenti, impostazioni). Contiene anche le password cifrate e la chiave AI: conservalo con cura.")}</p>
                <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                  <button onClick={handleBackup} disabled={backupBusy} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'7px 16px',fontSize:12,color:'#fff',cursor:backupBusy?'default':'pointer',fontWeight:500,opacity:backupBusy?0.6:1}}>{$t("Scarica backup")}</button>
                  <button onClick={()=>restoreInputRef.current?.click()} disabled={backupBusy} style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:8,padding:'7px 16px',fontSize:12,color:'var(--text)',cursor:backupBusy?'default':'pointer',opacity:backupBusy?0.6:1}}>{$t("Ripristina da file...")}</button>
                  <input ref={restoreInputRef} type="file" accept=".sqlite,.db,application/octet-stream" onChange={handleRestoreFile} style={{display:'none'}} />
                </div>
                {backupMsg && (
                  <div style={{marginTop:10,fontSize:12,borderRadius:8,padding:'7px 10px',background:backupMsg.ok?'var(--success-bg)':'var(--danger-bg)',color:backupMsg.ok?'var(--success-text)':'var(--danger-text)'}}>
                    {backupMsg.text}
                  </div>
                )}
              </>
            )}
          </div>

          {/* Banner server offline + launcher */}
          {serverHealth !== null && !serverHealth.online && (
            <div style={{background:'var(--danger-bg)',border:'0.5px solid var(--danger-text)',borderRadius:10,padding:'12px 16px',marginBottom:16}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                <i className="ti ti-server-off" style={{fontSize:18,color:'var(--danger-text)',flexShrink:0}} aria-hidden="true"></i>
                <span style={{fontWeight:600,fontSize:14,color:'var(--danger-text)'}}>{$t("Server API offline")}</span>
                <button onClick={pingHealth} style={{marginLeft:'auto',background:'none',border:'0.5px solid var(--danger-text)',borderRadius:6,padding:'3px 10px',fontSize:11,color:'var(--danger-text)',cursor:'pointer'}}>{$t("Verifica stato")}</button>
              </div>
              {launcherOk === null && (
                <div style={{fontSize:13,color:'var(--danger-text)',opacity:0.8}}>{$t("Verifica launcher in corso...")}</div>
              )}
              {launcherOk === true && (
                <div style={{display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
                  <span style={{fontSize:13,color:'var(--danger-text)'}}>{$t("Il launcher è attivo — puoi avviare il server da qui:")}</span>
                  <button
                    onClick={handleLaunch}
                    disabled={launching}
                    style={{background:launching?'var(--bg3)':'var(--success-bg)',border:'none',borderRadius:8,padding:'6px 16px',fontSize:13,color:launching?'var(--text3)':'var(--success-text)',cursor:launching?'default':'pointer',fontWeight:600}}
                  >
                    {launching ? $t("Avvio in corso...") : $t("Avvia server")}
                  </button>
                </div>
              )}
              {launcherOk === false && (
                <div style={{fontSize:13,color:'var(--danger-text)'}}>{$t("Launcher non raggiungibile — esegui")}{" "}<b>{$t("avvia.bat")}</b>{" "}{$t("sul PC server per ripristinare il servizio.")}</div>
              )}
            </div>
          )}

          <div style={{background:'var(--warn-bg)',color:'var(--warn-text)',borderRadius:10,padding:'10px 14px',fontSize:12,marginBottom:16,display:'flex',alignItems:'center',gap:8}}>
            <i className="ti ti-alert-triangle" style={{fontSize:16,flexShrink:0}} aria-hidden="true"></i>{$t("Queste azioni interrompono il servizio per tutti i dispositivi connessi. Usare con cautela.")}</div>

          {sysMsg && (
            <div style={{background:'var(--info-bg)',color:'var(--info-text)',borderRadius:10,padding:'10px 14px',fontSize:13,marginBottom:16,display:'flex',alignItems:'center',gap:8}}>
              <i className="ti ti-info-circle" style={{fontSize:16,flexShrink:0}} aria-hidden="true"></i>
              {sysMsg}
            </div>
          )}

          {[
            {
              id: 'close',
              icon: 'ti-door-exit',
              label: $t("Chiudi GesClo"),
              desc: $t("Chiude il gestionale: ferma server API, frontend e tutti i processi GesClo."),
              color: 'var(--warn-text)',
              bg: 'var(--warn-bg)',
              confirm: $t("Chiudere GesClo? Verranno terminati tutti i servizi (equivale a ferma.bat)."),
              action: async () => {
                setSysMsg($t("Chiusura in corso..."))
                try { await closeAll() } catch {}
                setSysMsg($t("GesClo chiuso. Puoi chiudere questa finestra."))
              }
            },
            {
              id: 'restart',
              icon: 'ti-refresh',
              label: $t("Riavvia GesClo"),
              desc: $t("Riavvia il gestionale senza spegnere il PC. Il servizio torna online entro ~5 secondi."),
              color: 'var(--accent-text)',
              bg: 'var(--accent-bg)',
              confirm: $t("Riavviare GesClo? Sarà offline per ~5 secondi."),
              action: async () => {
                setSysMsg($t("Riavvio in corso..."))
                try {
                  await restartServer()
                  setSysMsg($t("GesClo si sta riavviando. Attendi ~5 secondi poi aggiorna la pagina."))
                } catch { setSysMsg($t("Server già offline o comando fallito.")) }
              }
            },
            {
              id: 'shutdown',
              icon: 'ti-power',
              label: $t("Spegni server"),
              desc: $t("Spegne il PC / server. Il gestionale e tutti i servizi verranno chiusi."),
              color: 'var(--danger-text)',
              bg: 'var(--danger-bg)',
              confirm: $t("ATTENZIONE: Spegnere il PC server? Il computer si spegnerà entro 5 secondi!"),
              action: async () => {
                setSysMsg($t("Spegnimento PC in corso..."))
                try { await shutdownServer() } catch {}
                setSysMsg($t("Il PC si spegnerà tra pochi secondi."))
              }
            },
          ].map(item => (
            <div key={item.id} style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px',marginBottom:10,display:'flex',alignItems:'center',gap:14}}>
              <div style={{width:40,height:40,borderRadius:10,background:item.bg,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                <i className={`ti ${item.icon}`} style={{fontSize:20,color:item.color}} aria-hidden="true"></i>
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontWeight:500,fontSize:14,color:'var(--text)',marginBottom:2}}>{item.label}</div>
                <div style={{fontSize:12,color:'var(--text3)'}}>{item.desc}</div>
              </div>
              <button
                onClick={() => { if (window.confirm(item.confirm)) item.action() }}
                style={{flexShrink:0,background:item.bg,border:'none',borderRadius:8,padding:'8px 16px',fontSize:12,color:item.color,cursor:'pointer',fontWeight:600}}
              >
                {item.label}
              </button>
            </div>
          ))}

          {/* Svuota storico vendite */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px',marginBottom:10,display:'flex',alignItems:'center',gap:14}}>
            <div style={{width:40,height:40,borderRadius:10,background:'var(--danger-bg)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
              <i className="ti ti-trash" style={{fontSize:20,color:'var(--danger-text)'}} aria-hidden="true"></i>
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:500,fontSize:14,color:'var(--text)',marginBottom:2}}>{$t("Svuota storico vendite")}</div>
              <div style={{fontSize:12,color:'var(--text3)'}}>{$t("Elimina tutte le vendite registrate e azzera il contatore.")}</div>
            </div>
            <button
              onClick={() => { if (window.confirm($t("Eliminare TUTTE le vendite? Questa azione è irreversibile."))) { clearSales().then(() => setSysMsg($t("Storico vendite svuotato"))).catch(e => setSysMsg($t("Errore: {0}", [e.message]))); setTimeout(() => setSysMsg(''), 3000) }}}
              style={{flexShrink:0,background:'var(--danger-bg)',border:'none',borderRadius:8,padding:'8px 16px',fontSize:12,color:'var(--danger-text)',cursor:'pointer',fontWeight:600}}
            >{$t("Svuota")}</button>
          </div>

          {/* Terminale PowerShell — solo quando il backend è online */}
          {serverHealth?.online && (
            <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px',marginTop:6}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:termOpen?12:0}}>
                <i className="ti ti-terminal-2" style={{fontSize:16,color:'var(--text3)',flexShrink:0}} aria-hidden="true"></i>
                <span style={{fontWeight:500,fontSize:14,color:'var(--text)',flex:1}}>{$t("Terminale PowerShell")}</span>
                {!termOpen ? (
                  <button onClick={openTerminal} style={{background:'var(--accent-bg)',border:'none',borderRadius:8,padding:'6px 14px',fontSize:12,color:'var(--accent-text)',cursor:'pointer',fontWeight:500}}>{$t("Apri terminale")}</button>
                ) : (
                  <button onClick={closeTerminal} style={{background:'var(--danger-bg)',border:'none',borderRadius:8,padding:'6px 14px',fontSize:12,color:'var(--danger-text)',cursor:'pointer',fontWeight:500}}>{$t("Chiudi")}</button>
                )}
              </div>

              {termOpen && (
                <>
                  <div
                    ref={termOutRef}
                    style={{
                      background:'#0d1117',color:'#e6edf3',
                      borderRadius:8,padding:'10px 12px',
                      height:320,overflowY:'auto',
                      fontFamily:'Consolas,monospace',fontSize:12,
                      whiteSpace:'pre-wrap',wordBreak:'break-all',
                      marginBottom:8,lineHeight:1.5
                    }}
                  >
                    {termOutput.join('')}
                  </div>
                  <form onSubmit={sendCommand} style={{display:'flex',gap:8,alignItems:'center'}}>
                    <span style={{fontFamily:'Consolas,monospace',fontSize:13,color:'var(--text3)',flexShrink:0}}>{$t("PS>")}</span>
                    <input
                      value={termInput}
                      onChange={e=>setTermInput(e.target.value)}
                      placeholder={$t("Comando PowerShell...")}
                      style={{flex:1,fontFamily:'Consolas,monospace',fontSize:13}}
                      autoFocus
                    />
                    <button type="submit" style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'6px 14px',fontSize:12,color:'#fff',cursor:'pointer',flexShrink:0}}>{$t("Invia")}</button>
                  </form>
                </>
              )}
            </div>
          )}

        </div>
      )}

      {tab==='Hardware' && (
        <div style={{maxWidth:560,display:'flex',flexDirection:'column',gap:14}}>

          {/* NFC / Smart card */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:12,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-wifi" style={{fontSize:14}} aria-hidden="true"></i>{$t("NFC / Smart card")}</div>

            {/* Info IP */}
            <div style={{background:'var(--info-bg)',color:'var(--info-text)',borderRadius:8,padding:'8px 10px',fontSize:12,marginBottom:14,lineHeight:1.6}}>
              <b>{$t("IP del server GesClo")}</b>{" "}{$t("da inserire nell'app Android:")}{" "}<code style={{background:'rgba(0,0,0,0.15)',padding:'1px 5px',borderRadius:4}}>{window.location.hostname}:3001</code><br/>{$t("L'app Android legge i tag NFC e invia l'UID a questo indirizzo.")}</div>

            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("API Key NFC / POS")}</label>
              <div style={{display:'flex',gap:6}}>
                <input
                  type={showNfcKey ? 'text' : 'password'}
                  value={nfcKey}
                  onChange={e=>setNfcKey(e.target.value)}
                  placeholder={$t("chiave segreta condivisa con l'app Android")}
                  style={{flex:1,fontFamily:showNfcKey?'monospace':undefined}}
                />
                <button type="button" onClick={()=>setShowNfcKey(s=>!s)} style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:8,padding:'0 10px',fontSize:12,color:'var(--text2)',cursor:'pointer'}}>{showNfcKey ? $t("Nascondi") : $t("Mostra")}</button>
                <button type="button" onClick={generateNfcKey} style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:8,padding:'0 10px',fontSize:12,color:'var(--text2)',cursor:'pointer'}}>{$t("Genera")}</button>
              </div>
              {nfcKey.trim() ? (
                <div style={{fontSize:11,color:'var(--text3)',marginTop:4}}>{$t("L'app Android e nfc-service.js devono usare la stessa chiave. Premi")}{" "}<b>{$t("Salva")}</b>{" "}{$t("dopo averla modificata.")}</div>
              ) : (
                <div style={{background:'var(--warn-bg)',color:'var(--warn-text)',borderRadius:8,padding:'6px 10px',fontSize:11,marginTop:6}}>
                  <b>{$t("Nessuna chiave impostata:")}</b>{" "}{$t("chiunque sulla tua rete può inviare scansioni NFC, registrare vendite POS e leggere il PIN. Premi")}{" "}<b>{$t("Genera")}</b>{" "}{$t("e poi")}{" "}<b>{$t("Salva")}</b>.
                </div>
              )}
            </div>

            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("PIN POS")}{" "}<span style={{color:'var(--text3)'}}>{$t("(per accedere alle impostazioni Android dal POS)")}</span>
              </label>
              <input
                type="password"
                value={posPin}
                onChange={e=>setPosPin(e.target.value)}
                placeholder={$t("es: 1234")}
                style={{width:'100%',fontFamily:'monospace'}}
              />
            </div>

            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Sfondo Launcher POS")}{" "}<span style={{color:'var(--text3)'}}>{$t("(URL immagine o base64)")}</span>
              </label>
              <input
                value={posWallpaper}
                onChange={e=>setPosWallpaper(e.target.value)}
                placeholder="https://esempio.com/sfondo.jpg"
                style={{width:'100%'}}
              />
              {posWallpaper && <img src={posWallpaper} style={{marginTop:6,maxHeight:80,borderRadius:8,border:'0.5px solid var(--border)'}} alt="" onError={e=>{e.target.style.display='none'}} />}
            </div>

            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              <button onClick={saveHardware} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'7px 16px',fontSize:13,color:'#fff',cursor:'pointer',fontWeight:500}}>{$t("Salva")}</button>
              {nfcSaved && <span style={{fontSize:12,background:'var(--success-bg)',color:'var(--success-text)',padding:'4px 10px',borderRadius:20}}>{$t("Salvato!")}</span>}
            </div>
          </div>

          {/* Lettore USB HID (es. ACR barcode) */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-usb" style={{fontSize:14}} aria-hidden="true"></i>{$t("Lettore NFC/barcode USB (HID tastiera)")}</div>
            <div style={{fontSize:13,color:'var(--text)',lineHeight:1.7}}>{$t("I lettori USB che si comportano come")}{" "}<b>{$t("tastiera HID")}</b>{" "}{$t("(la maggior parte dei lettori barcode e molti lettori NFC/RFID USB) funzionano")}{" "}<b>{$t("già senza configurazione")}</b>:<br/>{$t("basta aprire la pagina")}{" "}<b>{$t("Scanner")}</b>{$t(", selezionare la modalità")}{" "}<b>{$t("Tastiera")}</b>{" "}{$t("e avvicinare la carta al lettore. Il codice viene digitato automaticamente nell'input.")}</div>
          </div>

          {/* Lettore USB PC/SC (smart card ISO 7816) */}
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10,display:'flex',alignItems:'center',gap:6}}>
              <i className="ti ti-credit-card" style={{fontSize:14}} aria-hidden="true"></i>{$t("Lettore USB PC/SC (smart card con chip ISO 7816)")}</div>
            <div style={{fontSize:13,color:'var(--text)',lineHeight:1.7,marginBottom:10}}>{$t("Lettori come ACR122U, SCM, Identiv, ecc. usano il protocollo PC/SC. Per integrarli, avvia il servizio bridge dal server:")}</div>
            <div style={{background:'#0d1117',borderRadius:8,padding:'10px 12px',fontFamily:'Consolas,monospace',fontSize:12,color:'#e6edf3',marginBottom:10}}>
              <div style={{color:'#8b949e',marginBottom:4}}>{$t("# nella cartella server/")}</div>
              <div>{$t("npm install nfc-pcsc")}</div>
              <div>{$t("node nfc-service.js")}</div>
            </div>
            <div style={{fontSize:11,color:'var(--text3)'}}>{$t("Il file")}{" "}<code>{$t("server/nfc-service.js")}</code>{" "}{$t("è già incluso nel progetto. Richiede il servizio Windows Smart Card (abilitato per default su Win 10/11).")}</div>
          </div>


        </div>
      )}

      {modal && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:100}}>
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:14,padding:22,width:320}}>
            <div style={{fontWeight:500,fontSize:15,color:'var(--text)',marginBottom:14,display:'flex',alignItems:'center',gap:8}}>
              <i className={`ti ${modal==='add'?'ti-user-plus':'ti-pencil'}`} style={{color:'var(--accent)'}} aria-hidden="true"></i>
              {modal==='add' ? $t("Nuovo utente") : $t("Modifica utente")}
            </div>
            {(modal==='add'
              ? [[$t("Email *"),'email','email',$t("email@esempio.it")],[$t("Nome visualizzato"),'text','username',$t("Es: Mario Rossi")],[$t("Password (min 8) *"),'password','password','••••••••']]
              : [[$t("Nome visualizzato"),'text','username',$t("Es: Mario Rossi")],[$t("Nuova password (vuoto = invariata)"),'password','password','••••••••']]
            ).map(([label,type,field,ph])=>(
              <div key={field} style={{marginBottom:10}}>
                <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{label}</label>
                <input type={type} value={form[field]} onChange={e=>setForm(p=>({...p,[field]:e.target.value}))} placeholder={ph} style={{width:'100%'}} />
              </div>
            ))}
            {modal!=='add' && form.email && (
              <div style={{marginBottom:10,fontSize:11,color:'var(--text3)'}}>{$t("Email:")}{" "}{form.email}</div>
            )}
            <div style={{marginBottom:14}}>
              <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{$t("Ruolo")}</label>
              <select value={form.role} onChange={e=>setForm(p=>({...p,role:e.target.value}))} style={{width:'100%'}}>
                {ROLES.map(r=><option key={r} value={r}>{$t(r)}</option>)}
              </select>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button onClick={()=>setModal(null)} style={{flex:1,border:'0.5px solid var(--border)',borderRadius:8,padding:8,fontSize:13,background:'transparent',color:'var(--text)',cursor:'pointer'}}>{$t("Annulla")}</button>
              <button onClick={handleSave} disabled={saving} style={{flex:2,background:saving?'var(--bg3)':'var(--accent)',border:'none',borderRadius:8,padding:8,fontSize:13,color:saving?'var(--text3)':'#fff',cursor:'pointer',fontWeight:500}}>
                {saving?$t("Salvataggio..."):$t("Salva")}
              </button>
            </div>
          </div>
        </div>
      )}

    </Layout>
  )
}
