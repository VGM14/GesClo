import React, { useState } from 'react'
import { setupAdmin } from '../services/apiService'
import { $t } from '../i18n'
import LangSwitch from '../components/LangSwitch'

export default function Setup({ onDone, dark, setDark }) {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handle = async () => {
    if (!username.trim()) return setError($t("Inserisci un nome utente"))
    if (password.length < 8) return setError($t("La password deve avere almeno 8 caratteri"))
    if (password !== confirm) return setError($t("Le due password non coincidono"))
    setLoading(true)
    setError('')
    try {
      const data = await setupAdmin(username.trim(), email.trim(), password)
      onDone({ username: data.username, role: data.role })
    } catch (e) {
      setError(e.message || $t("Impossibile creare l'account"))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'var(--bg)'}}>
      <div style={{width:380,background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:16,padding:28}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:4}}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:34,height:34,borderRadius:9,background:'var(--accent)',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <i className="ti ti-box" style={{color:'#fff',fontSize:18}} aria-hidden="true"></i>
            </div>
            <span style={{fontWeight:600,fontSize:18,color:'var(--text)'}}>{$t("GesClo")}</span>
          </div>
          <div style={{display:'flex',gap:6}}>
            <LangSwitch />
            <button onClick={()=>setDark(!dark)} style={{width:32,height:32,borderRadius:8,border:'0.5px solid var(--border)',background:'transparent',cursor:'pointer',color:'var(--text3)',display:'flex',alignItems:'center',justifyContent:'center'}}>
              <i className={`ti ${dark?'ti-sun':'ti-moon'}`} style={{fontSize:16}} aria-hidden="true"></i>
            </button>
          </div>
        </div>
        <p style={{fontSize:15,fontWeight:600,color:'var(--text)',marginTop:14,marginBottom:4}}>{$t("Benvenuto! Crea l'account amministratore")}</p>
        <p style={{fontSize:12,color:'var(--text3)',marginBottom:20}}>{$t("È il primo avvio: scegli le credenziali con cui accederai a GesClo. Potrai aggiungere altri utenti dal pannello Admin.")}</p>
        {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',fontSize:12,borderRadius:8,padding:'7px 10px',marginBottom:12}}>{error}</div>}
        {[
          [$t("Nome utente"), username, setUsername, 'text', $t("es. mario"), 'username'],
          [$t("Email (facoltativa)"), email, setEmail, 'email', $t("mario@esempio.it"), 'email'],
          [$t("Password (min. 8 caratteri)"), password, setPassword, 'password', '••••••••', 'new-password'],
          [$t("Conferma password"), confirm, setConfirm, 'password', '••••••••', 'new-password'],
        ].map(([label, val, set, type, ph, ac]) => (
          <div key={label} style={{marginBottom:12}}>
            <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{label}</label>
            <input type={type} value={val} onChange={e=>set(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&handle()}
              placeholder={ph} autoComplete={ac} style={{width:'100%'}} />
          </div>
        ))}
        <button onClick={handle} disabled={loading} style={{width:'100%',background:loading?'var(--bg3)':'var(--accent)',border:'none',borderRadius:9,padding:'10px',fontSize:13,color:loading?'var(--text3)':'#fff',cursor:loading?'default':'pointer',fontWeight:500,marginTop:4}}>
          {loading ? $t("Creazione in corso...") : $t("Crea account e accedi →")}
        </button>
      </div>
    </div>
  )
}
