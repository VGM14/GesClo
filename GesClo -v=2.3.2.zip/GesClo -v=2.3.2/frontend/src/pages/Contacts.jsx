import React, { useState, useEffect, useMemo } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import {
  getCustomers, addCustomer, updateCustomer, deleteCustomer,
  getSuppliers, addSupplier, updateSupplier, deleteSupplier,
  getCustomerHistory, getSupplierHistory,
} from '../services/apiService'
import CsvTools from '../components/CsvTools'
import { $t, LOCALE, payLabel, poStatusLabel, dataText } from '../i18n'

const eur = (n) => Number(n || 0).toLocaleString(LOCALE, { style: 'currency', currency: 'EUR' })

// Le due anagrafiche hanno gli stessi campi e la stessa interfaccia: cambiano l'API e il
// riepilogo dei rapporti (vendite per i clienti, ordini d'acquisto per i fornitori).
const KINDS = {
  clienti: {
    tab: $t("Clienti"), singular: $t("cliente"), newLabel: $t("Nuovo cliente"), icon: 'ti-users',
    hint: $t("Anagrafica dei clienti: compaiono nella cassa e nello storico delle vendite."),
    empty: $t("Nessun cliente — clicca \"Nuovo cliente\""),
    api: { list: getCustomers, add: addCustomer, update: updateCustomer, remove: deleteCustomer },
    confirmDelete: (r) => $t("Eliminare il cliente \"{0}\"? Le vendite già registrate restano nello storico.", [r.name]),
    summary: (r) => r.sales_count > 0
      ? { main: `${r.sales_count} ${r.sales_count === 1 ? $t("vendita") : $t("vendite")} · ${eur(r.sales_total)}`, sub: r.last_sale ? $t("ultima il {0}", [r.last_sale]) : '' }
      : { main: $t("Nessuna vendita"), sub: '' },
  },
  fornitori: {
    tab: $t("Fornitori"), singular: $t("fornitore"), newLabel: $t("Nuovo fornitore"), icon: 'ti-truck',
    hint: $t("Anagrafica dei fornitori da cui acquisti: si usano negli ordini d'acquisto (sezione Acquisti)."),
    empty: $t("Nessun fornitore — clicca \"Nuovo fornitore\""),
    api: { list: getSuppliers, add: addSupplier, update: updateSupplier, remove: deleteSupplier },
    confirmDelete: (r) => $t("Eliminare il fornitore \"{0}\"? Gli ordini già fatti restano nello storico.", [r.name]),
    summary: (r) => r.orders_count > 0
      ? { main: $t("{0} {1} · {2} ricevuti", [r.orders_count, r.orders_count === 1 ? $t("ordine") : $t("ordini"), eur(r.received_total)]), sub: [r.open_orders > 0 ? `${r.open_orders} ${r.open_orders === 1 ? $t("aperto") : $t("aperti")}` : '', r.last_order ? $t("ultimo il {0}", [r.last_order]) : ''].filter(Boolean).join(' · ') }
      : { main: $t("Nessun ordine"), sub: '' },
  },
}

const EMPTY = { name: '', vat_number: '', phone: '', email: '', address: '', notes: '', payment_days: '' }
const FIELDS = [
  ['name',       $t("Nome / ragione sociale *"), 'text',  ''],
  ['vat_number', $t("P.IVA / Codice fiscale"),   'text',  ''],
  ['phone',      $t("Telefono"),                 'tel',   ''],
  ['email',      $t("Email"),                    'email', ''],
  ['address',    $t("Indirizzo"),                'text',  $t("Via, numero, CAP, città")],
]

const card = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px' }
const label = { fontSize: 11, color: 'var(--text2)', display: 'block', marginBottom: 4 }
const btnGhost = { background: 'transparent', border: '0.5px solid var(--border)', borderRadius: 6, padding: '3px 9px', fontSize: 11, color: 'var(--text)', cursor: 'pointer' }

export default function Contacts(props) {
  const [kind, setKind] = useState('clienti')
  const [lists, setLists] = useState({ clienti: [], fornitori: [] })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState(null) // null | 'add' | id
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)
  const [detail, setDetail] = useState(null)   // { kind, row }
  const [history, setHistory] = useState(null) // null = in caricamento

  const cfg = KINDS[kind]
  const rows = lists[kind]

  const load = () => {
    setLoading(true)
    return Promise.all([getCustomers(), getSuppliers()])
      .then(([c, s]) => setLists({ clienti: c, fornitori: s }))
      .catch(e => setError(e?.message || String(e)))
      .finally(() => setLoading(false))
  }
  useEffect(() => { load() }, [])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return rows
    return rows.filter(r => [r.name, r.vat_number, r.phone, r.email, r.address].some(v => (v || '').toLowerCase().includes(q)))
  }, [rows, search])

  const switchKind = (k) => { setKind(k); setSearch(''); setError('') }

  const openForm = (r) => {
    setForm(r ? { name: r.name, vat_number: r.vat_number || '', phone: r.phone || '', email: r.email || '', address: r.address || '', notes: r.notes || '', payment_days: r.payment_days != null ? String(r.payment_days) : '' } : EMPTY)
    setModal(r ? r.id : 'add')
  }

  const save = async () => {
    if (!form.name.trim()) return setError($t("Il nome è obbligatorio"))
    setSaving(true); setError('')
    try {
      const payload = kind === 'fornitori'
        ? { ...form, payment_days: form.payment_days !== '' ? parseInt(form.payment_days) : null }
        : (({ payment_days, ...rest }) => rest)(form)
      if (modal === 'add') await cfg.api.add(payload)
      else await cfg.api.update(modal, payload)
      setModal(null)
      await load()
    } catch (e) { setError(e?.message || String(e)) }
    setSaving(false)
  }

  const openDetail = (r) => {
    setDetail({ kind, row: r }); setHistory(null)
    const fetcher = kind === 'clienti' ? getCustomerHistory : getSupplierHistory
    fetcher(r.id).then(setHistory).catch(e => { setError(e?.message || String(e)); setDetail(null) })
  }

  const csvConfig = {
    kind: kind === 'clienti' ? 'customers' : 'suppliers', label: cfg.tab.toLowerCase(), filename: `${cfg.tab.toLowerCase()}.csv`,
    importNote: $t("I {0} già presenti (stessa P.IVA/CF, oppure stesso nome se manca) vengono aggiornati con i campi compilati.", [cfg.tab.toLowerCase()]),
    columns: [
      { key: 'name', label: $t("Nome"), aliases: ['ragione sociale', 'cliente', 'fornitore'], value: r => r.name },
      { key: 'vat_number', label: $t("P.IVA/CF"), aliases: ['piva', 'partita iva', 'codice fiscale', 'cf'], value: r => r.vat_number },
      { key: 'phone', label: $t("Telefono"), aliases: ['tel', 'cellulare'], value: r => r.phone },
      { key: 'email', label: $t("Email"), aliases: ['mail'], value: r => r.email },
      { key: 'address', label: $t("Indirizzo"), value: r => r.address },
      { key: 'notes', label: $t("Note"), value: r => r.notes },
      ...(kind === 'fornitori' ? [{ key: 'payment_days', label: $t("Giorni di pagamento"), aliases: ['giorni pagamento', 'termini'], value: r => r.payment_days }] : []),
    ],
    exportRows: () => filtered,
    onDone: load,
  }

  const remove = async (r) => {
    if (!window.confirm(cfg.confirmDelete(r))) return
    try { await cfg.api.remove(r.id); await load() } catch (e) { setError(e?.message || String(e)) }
  }

  const tabBtn = (k) => (
    <button key={k} onClick={() => switchKind(k)} style={{
      padding: '5px 14px', borderRadius: 20, fontSize: 12, cursor: 'pointer',
      border: `0.5px solid ${kind === k ? 'var(--accent)' : 'var(--border)'}`,
      background: kind === k ? 'var(--accent-bg)' : 'transparent',
      color: kind === k ? 'var(--accent-text)' : 'var(--text3)',
    }}>{KINDS[k].tab} ({lists[k].length})</button>
  )

  return (
    <Layout {...props} title={$t("Anagrafiche")}>
      <SectionLock section="contacts" {...props}>
        {error && <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{error} <button onClick={() => setError('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger-text)' }}>×</button></div>}

        <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
          {Object.keys(KINDS).map(tabBtn)}
        </div>

        <div style={card}>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10 }}>{cfg.hint}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder={$t("Cerca per nome, P.IVA, telefono, email o indirizzo...")} style={{ flex: 1 }} />
            <CsvTools key={kind} config={csvConfig} />
            <button onClick={() => openForm(null)} style={{ background: 'var(--accent)', border: 'none', borderRadius: 8, padding: '7px 14px', fontSize: 12, color: '#fff', cursor: 'pointer', fontWeight: 500, flexShrink: 0 }}>
              <i className="ti ti-plus" aria-hidden="true"></i> {cfg.newLabel}
            </button>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Caricamento...")}</div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>
              {rows.length === 0 ? cfg.empty : $t("Nessun risultato per \"{0}\"", [search])}
            </div>
          ) : (
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.2fr 1.2fr 112px', gap: 8, padding: '6px 8px', fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '0.5px solid var(--border)', marginBottom: 4 }}>
                <span>{$t("Nome")}</span><span>{$t("Contatti")}</span><span>{kind === 'clienti' ? $t("Acquisti") : $t("Ordini")}</span><span></span>
              </div>
              {filtered.map(r => {
                const s = cfg.summary(r)
                return (
                  <div key={r.id} style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.2fr 1.2fr 112px', gap: 8, padding: '9px 8px', borderBottom: '0.5px solid var(--border)', alignItems: 'center' }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.name}</div>
                      {r.vat_number && <div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("P.IVA/CF")}{" "}{r.vat_number}</div>}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text2)', minWidth: 0 }}>
                      {r.phone && <div><a href={`tel:${r.phone}`} style={{ color: 'inherit', textDecoration: 'none' }}>{r.phone}</a></div>}
                      {r.email && <div style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}><a href={`mailto:${r.email}`} style={{ color: 'inherit', textDecoration: 'none' }}>{r.email}</a></div>}
                      {!r.phone && !r.email && '—'}
                      {r.address && <div style={{ fontSize: 11, color: 'var(--text3)' }}>{r.address}</div>}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, color: 'var(--text)' }}>{s.main}</div>
                      {s.sub && <div style={{ fontSize: 11, color: 'var(--text3)' }}>{s.sub}</div>}
                    </div>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                      <button onClick={() => openDetail(r)} title={$t("Scheda e storico")} style={btnGhost}><i className="ti ti-eye" aria-hidden="true"></i></button>
                      <button onClick={() => openForm(r)} title={$t("Modifica")} style={btnGhost}><i className="ti ti-pencil" aria-hidden="true"></i></button>
                      <button onClick={() => remove(r)} title={$t("Elimina")} style={{ ...btnGhost, background: 'var(--danger-bg)', color: 'var(--danger-text)', border: '0.5px solid var(--danger-text)' }}><i className="ti ti-trash" aria-hidden="true"></i></button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {modal && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
            <div style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 14, padding: 22, width: 400, maxWidth: '94vw', maxHeight: '90vh', overflow: 'auto' }}>
              <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                <i className={`ti ${cfg.icon}`} style={{ color: 'var(--accent)' }} aria-hidden="true"></i>
                {modal === 'add' ? cfg.newLabel : $t("Modifica {0}", [cfg.singular])}
              </div>
              {FIELDS.map(([f, l, type, ph]) => (
                <div key={f} style={{ marginBottom: 10 }}>
                  <label style={label}>{l}</label>
                  <input type={type} value={form[f]} onChange={e => setForm(p => ({ ...p, [f]: e.target.value }))} onKeyDown={e => e.key === 'Enter' && f === 'name' && save()} placeholder={ph} autoFocus={f === 'name'} style={{ width: '100%' }} />
                </div>
              ))}
              {kind === 'fornitori' && (
                <div style={{ marginBottom: 10 }}>
                  <label style={label}>{$t("Giorni di pagamento")}{" "}<span style={{ color: 'var(--text3)' }}>{$t("(per la scadenza degli ordini ricevuti; vuoto = 30)")}</span></label>
                  <input type="number" min="0" step="1" value={form.payment_days} onChange={e => setForm(f => ({ ...f, payment_days: e.target.value }))} placeholder={$t("Es: 60")} style={{ width: '100%' }} />
                </div>
              )}
              <div style={{ marginBottom: 14 }}>
                <label style={label}>{$t("Note")}</label>
                <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} style={{ width: '100%', resize: 'vertical' }} />
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setModal(null)} style={{ flex: 1, border: '0.5px solid var(--border)', borderRadius: 8, padding: 8, fontSize: 13, background: 'transparent', color: 'var(--text)', cursor: 'pointer' }}>{$t("Annulla")}</button>
                <button onClick={save} disabled={saving} style={{ flex: 2, background: saving ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8, padding: 8, fontSize: 13, color: saving ? 'var(--text3)' : '#fff', cursor: saving ? 'default' : 'pointer', fontWeight: 500 }}>{saving ? $t("Salvataggio...") : $t("Salva")}</button>
              </div>
            </div>
          </div>
        )}
        {detail && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 16 }} onClick={() => setDetail(null)}>
            <div onClick={e => e.stopPropagation()} style={{ background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 14, padding: 22, width: 640, maxWidth: '100%', maxHeight: '90vh', overflow: 'auto' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{detail.row.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
                    {[detail.row.vat_number && $t("P.IVA/CF {0}", [detail.row.vat_number]), detail.row.phone, detail.row.email, detail.row.address].filter(Boolean).join(' · ') || $t("Nessun contatto inserito")}
                  </div>
                  {detail.row.notes && <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4 }}>{detail.row.notes}</div>}
                </div>
                <button onClick={() => setDetail(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 20, lineHeight: 1 }}>×</button>
              </div>

              {!history ? (
                <div style={{ textAlign: 'center', padding: '30px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Caricamento...")}</div>
              ) : (() => {
                const isCust = detail.kind === 'clienti'
                const openDues = history.dues.filter(d => d.status !== 'saldata')
                const openTotal = openDues.reduce((s, d) => s + d.residual, 0)
                const late = openDues.filter(d => d.status === 'scaduta').reduce((s, d) => s + d.residual, 0)
                const list = isCust ? history.sales : history.orders
                const total = list.filter(x => isCust || x.status === 'ricevuto').reduce((s, x) => s + (x.total || 0), 0)
                return (
                  <>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 14 }}>
                      {[
                        [isCust ? $t("Vendite") : $t("Ordini"), list.length, isCust ? eur(total) + $t(" in totale") : eur(total) + $t(" ricevuti")],
                        [isCust ? $t("Da incassare") : $t("Da pagare"), eur(openTotal), openDues.length + (openDues.length === 1 ? $t(" scadenza") : $t(" scadenze"))],
                        [$t("Scaduto"), eur(late), late > 0 ? $t("da sollecitare") : $t("nulla in ritardo")],
                      ].map(([l, v, sub], i) => (
                        <div key={l} style={{ border: '0.5px solid var(--border)', borderRadius: 10, padding: '9px 12px' }}>
                          <div style={{ fontSize: 11, color: 'var(--text3)' }}>{l}</div>
                          <div style={{ fontSize: 17, fontWeight: 600, color: i === 2 && late > 0 ? 'var(--danger-text)' : 'var(--text)' }}>{v}</div>
                          <div style={{ fontSize: 11, color: 'var(--text3)' }}>{sub}</div>
                        </div>
                      ))}
                    </div>

                    {openDues.length > 0 && (
                      <div style={{ marginBottom: 14 }}>
                        <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>{$t("Scadenze aperte")}</div>
                        {openDues.map(d => (
                          <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 8, padding: '6px 0', borderBottom: '0.5px solid var(--border)', fontSize: 13 }}>
                            <span style={{ color: 'var(--text2)' }}>{dataText(d.ref_label) || d.description || $t("Scadenza")} · <span style={{ color: d.status === 'scaduta' ? 'var(--danger-text)' : 'var(--text3)' }}>{d.due_date}{d.status === 'scaduta' ? $t(" (scaduta)") : ''}</span></span>
                            <b style={{ color: 'var(--text)' }}>{eur(d.residual)}</b>
                          </div>
                        ))}
                      </div>
                    )}

                    <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>{isCust ? $t("Storico vendite") : $t("Storico ordini d'acquisto")}{" "}{$t("(ultimi 100)")}</div>
                    {list.length === 0 ? (
                      <div style={{ color: 'var(--text3)', fontSize: 13, padding: '10px 0' }}>{isCust ? $t("Nessuna vendita registrata per questo cliente.") : $t("Nessun ordine per questo fornitore.")}</div>
                    ) : list.map(x => (
                      <div key={x.id} style={{ display: 'grid', gridTemplateColumns: '90px 60px 1fr 90px', gap: 8, padding: '6px 0', borderBottom: '0.5px solid var(--border)', fontSize: 13, alignItems: 'center' }}>
                        <span style={{ color: 'var(--text2)' }}>{x.date}</span>
                        <span style={{ color: 'var(--text)' }}>#{x.number}</span>
                        <span style={{ color: 'var(--text3)', fontSize: 12 }}>{isCust ? payLabel(x.payment_method) : poStatusLabel(x.status)}</span>
                        <span style={{ textAlign: 'right', color: 'var(--text)' }}>{eur(x.total)}</span>
                      </div>
                    ))}
                  </>
                )
              })()}
            </div>
          </div>
        )}
      </SectionLock>
    </Layout>
  )
}
