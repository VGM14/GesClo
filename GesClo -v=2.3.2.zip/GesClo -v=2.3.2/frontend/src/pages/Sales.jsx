import React, { useState, useEffect, useRef, useCallback } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import { getProducts, getCustomers, addCustomer, addSale, getSales, getCashRegister, findByBarcode, posRequest, posCancel } from '../services/apiService'
import { $t, payLabel, customerLabel } from '../i18n'

export default function Sales(props) {
  const { lastNfcScan, setLastNfcScan } = props

  const [products, setProducts] = useState([])
  const [customers, setCustomers] = useState([])
  const [sales, setSales] = useState([])
  const [cashReg, setCashReg] = useState(null)
  const [cart, setCart] = useState([])
  const [customer, setCustomer] = useState(null)
  const [customerSearch, setCustomerSearch] = useState('')
  const [productSearch, setProductSearch] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('contanti')
  const [paymentOther, setPaymentOther] = useState('')
  const [dueDate, setDueDate] = useState(() => { const d = new Date(); d.setUTCDate(d.getUTCDate() + 30); return d.toISOString().split('T')[0] })
  const [scanCode, setScanCode]     = useState('')
  const [scanError, setScanError]   = useState('')
  const scanInputRef = useRef()
  const [discount, setDiscount] = useState(0)
  const [notes, setNotes] = useState('')
  const [tab, setTab] = useState('cassa')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [lastSale, setLastSale] = useState(null)
  const [newCustomerModal, setNewCustomerModal] = useState(false)
  const [newCustomerForm, setNewCustomerForm] = useState({ name:'', email:'', phone:'', address:'' })
  const receiptRef = useRef()
  // NFC / POS
  const [nfcCard, setNfcCard] = useState(null)
  const [posWaiting, setPosWaiting] = useState(false)

  useEffect(() => {
    Promise.all([getProducts(), getCustomers(), getSales(), getCashRegister()])
      .then(([p, c, s, cr]) => { setProducts(p); setCustomers(c); setSales(s); setCashReg(cr) })
      .catch(e => setError(e.message))
  }, [])

  // Il campo del lettore di codici a barre è già selezionato all'apertura della cassa:
  // basta passare il codice, senza cliccare prima nel campo.
  useEffect(() => {
    if (tab === 'cassa') scanInputRef.current?.focus()
  }, [tab])

  // Gestione eventi NFC ricevuti via SSE
  useEffect(() => {
    if (!lastNfcScan) return
    if (lastNfcScan.type === 'pos_cancelled') {
      if (posWaiting) {
        setPosWaiting(false)
        setError($t("Operazione annullata dal POS"))
        setTimeout(() => setError(''), 4000)
      }
      if (setLastNfcScan) setLastNfcScan(null)
      return
    }
    if (lastNfcScan.source === 'payment_card') {
      setPaymentMethod('pos_nfc')
      setNfcCard({ brand: lastNfcScan.cardBrand || 'Contactless', uid: lastNfcScan.uid })
      setTab('cassa')
      if (posWaiting) {
        setPosWaiting(false)
        handleSale(true) // pagamento già incassato dal POS: niente domande sulla giacenza
      }
    } else if (lastNfcScan.product) {
      addToCart(lastNfcScan.product)
      setTab('cassa')
    }
    if (setLastNfcScan) setLastNfcScan(null)
  }, [lastNfcScan])

  const filteredProducts = products.filter(p =>
    p.name?.toLowerCase().includes(productSearch.toLowerCase()) ||
    (p.barcodes || [p.barcode]).some(b => b?.includes(productSearch))
  )

  const filteredCustomers = customers.filter(c =>
    c.name?.toLowerCase().includes(customerSearch.toLowerCase()) ||
    c.phone?.includes(customerSearch)
  )

  const addToCart = (product) => {
    scanInputRef.current?.focus()
    setCart(prev => {
      const existing = prev.find(i => i.product_id === product.id)
      if (existing) return prev.map(i => i.product_id === product.id ? { ...i, qty: i.qty + 1, subtotal: (i.qty + 1) * i.price } : i)
      return [...prev, { product_id: product.id, name: product.name, price: product.price || 0, qty: 1, subtotal: product.price || 0 }]
    })
  }

  const updateCartItem = (idx, field, value) => {
    setCart(prev => prev.map((item, i) => {
      if (i !== idx) return item
      const updated = { ...item, [field]: field === 'price' || field === 'qty' ? parseFloat(value) || 0 : value }
      updated.subtotal = updated.price * updated.qty
      return updated
    }))
  }

  const removeFromCart = (idx) => setCart(prev => prev.filter((_, i) => i !== idx))

  const subtotal = cart.reduce((sum, i) => sum + (i.subtotal || 0), 0)
  const discountAmt = (subtotal * discount) / 100
  const tax = cashReg?.show_tax ? ((subtotal - discountAmt) * (cashReg?.tax_rate || 22)) / 100 : 0
  const total = subtotal - discountAmt + tax

  const handleSendToPOS = async () => {
    if (cart.length === 0) return setError($t("Aggiungi almeno un articolo"))
    try {
      await posRequest(total, null, cart.map(i => ({ name: i.name, qty: i.qty, price: i.price })))
      setPosWaiting(true)
      setSuccess($t("Richiesta inviata al POS — in attesa del pagamento contactless..."))
    } catch(e) { setError($t("Errore invio al POS: {0}", [e.message])) }
  }

  const handleCancelPOS = async () => {
    try { await posCancel() } catch {}
    setPosWaiting(false)
    setSuccess('')
  }

  const handleSale = async (paymentAlreadyTaken = false) => {
    if (cart.length === 0) return setError($t("Aggiungi almeno un articolo"))
    if (cart.some(i => !(i.qty > 0) || i.price < 0)) return setError($t("Controlla quantità e prezzi: devono essere maggiori di zero"))
    if (paymentMethod === 'credito' && !customer) return setError($t("Per vendere a credito scegli prima un cliente"))
    if (paymentMethod === 'credito' && !dueDate) return setError($t("Indica entro quando il cliente deve pagare"))

    // Avviso se si vende più di quanto risulta in magazzino (il server porterebbe la giacenza a 0)
    if (!paymentAlreadyTaken) {
      const short = cart
        .map(i => { const p = products.find(x => x.id === i.product_id); return p && i.qty > p.qty ? $t("• {0}: richiesti {1}, disponibili {2}", [i.name, i.qty, p.qty]) : null })
        .filter(Boolean)
      if (short.length && !window.confirm($t("Giacenza insufficiente:\n\n{0}\n\nRegistrare comunque la vendita?", [short.join('\n')]))) return
    }

    setLoading(true); setError(''); setPosWaiting(false)
    try {
      const sale = await addSale({
        customer_id: customer?.id || '',
        customer_name: customer?.name || $t("Cliente generico"),
        items: cart,
        subtotal, discount: discountAmt, tax, total,
        payment_method: paymentMethod,
        payment_other: paymentOther,
        due_date: paymentMethod === 'credito' ? dueDate : undefined,
        notes,
      })
      sale.items = cart
      sale.cashReg = cashReg
      setLastSale(sale)
      setCart([]); setCustomer(null); setCustomerSearch(''); setDiscount(0); setNotes(''); setNfcCard(null)
      setSuccess($t("Vendita #{0} registrata!", [sale.number]))
      setTimeout(() => setSuccess(''), 4000)
      getSales().then(setSales)
      getProducts().then(setProducts)
      scanInputRef.current?.focus()
      // Scontrino automatico a fine vendita (disattivabile da Admin → Cassa)
      if (cashReg?.auto_print !== false) printReceipt(sale)
    } catch(e) { setError(e.message) }
    setLoading(false)
  }

  // Stampa tramite iframe nascosto invece di window.open: non viene bloccato come popup
  // (anche quando la vendita parte da un pagamento NFC, senza click dell'utente) e non
  // sposta l'utente dalla cassa.
  const printReceipt = (sale) => {
    const frame = document.createElement('iframe')
    frame.setAttribute('aria-hidden', 'true')
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;'
    document.body.appendChild(frame)
    const cleanup = () => setTimeout(() => { frame.remove(); window.focus(); scanInputRef.current?.focus() }, 1000)
    frame.contentWindow.addEventListener('afterprint', cleanup)
    frame.contentDocument.open()
    frame.contentDocument.write(generateReceipt(sale))
    frame.contentDocument.close()
    setTimeout(() => {
      frame.contentWindow.focus()
      frame.contentWindow.print()
      setTimeout(() => frame.remove(), 120000)
    }, 250)
  }

  const handlePrint = () => { if (lastSale) printReceipt(lastSale) }

  const generateReceipt = (sale) => {
    const cr = sale.cashReg || cashReg || {}
    const items = Array.isArray(sale.items) ? sale.items : []
    const cur = cr.currency === 'USD' ? '$' : cr.currency === 'GBP' ? '£' : cr.currency === 'CHF' ? 'CHF ' : '€'
    const fmt = (n) => cur + parseFloat(n||0).toFixed(2)
    const ptype = cr.printer_type || 'a4'
    const isNarrow = ptype === 'thermal_80' || ptype === 'thermal_58'
    const width = ptype === 'thermal_58' ? '58mm' : ptype === 'thermal_80' ? '80mm' : '210mm'
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]))
    const payment = esc(sale.payment_method === 'altro' ? (sale.payment_other || $t("Altro")) : payLabel(sale.payment_method))
    // Diciture della ricevuta nella lingua corrente
    const L = {
      saleDoc: $t('DOCUMENTO DI VENDITA'), saleDocA4: $t('Documento di vendita'), no: $t('N°'), customer: $t('Cliente'),
      date: $t('Data'), notes: $t('Note'), vatNo: $t('P.IVA'), vat: $t('IVA'), subtotal: $t('Subtotale'), discount: $t('Sconto'),
      total: $t('TOTALE'), totalCol: $t('Totale'), payment: $t('Pagamento'), item: $t('Articolo'), qty: $t('Qtà'), unitPrice: $t('Prezzo unit.'),
    }
    const bizName = esc(cr.name || cr.header_text || 'GesClo')

    if (isNarrow) {
      // ── Formato termica ────────────────────────────────────────
      // Allineamento via CSS flexbox (justify-content: space-between), non spazi
      // contati a mano: il vecchio approccio a "padding di spazi" presumeva un
      // monospace a larghezza fissa, ma nel browser (print preview compreso)
      // white-space:pre-wrap manda a capo quelle righe dentro una larghezza in mm,
      // spezzando ogni riga importo in due e rovinando l'allineamento.
      return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Courier New', monospace; font-size: 12px; line-height: 1.4; width: ${width}; margin: 0 auto; padding: 3mm; color: #000; }
  .center { text-align: center; }
  .name { font-size: 15px; font-weight: 700; margin-bottom: 2px; }
  .muted { font-size: 10px; }
  .sep { border: none; border-top: 1px dashed #000; margin: 7px 0; }
  .row { display: flex; justify-content: space-between; gap: 8px; }
  .item { margin-bottom: 5px; }
  .item-name { font-weight: 700; word-break: break-word; }
  .item-detail { font-size: 11px; }
  .grand-total { font-size: 15px; font-weight: 700; border-top: 1px solid #000; margin-top: 5px; padding-top: 5px; }
  @media print { body { margin: 0; padding: 2mm; } @page { margin: 0; size: ${width} auto; } }
</style></head><body>
  <div class="center name">${bizName}</div>
  ${cr.address ? `<div class="center muted">${esc(cr.address)}</div>` : ''}
  ${cr.vat_number ? `<div class="center muted">${L.vatNo}: ${esc(cr.vat_number)}</div>` : ''}
  <hr class="sep">
  <div class="center" style="font-weight:700">${L.saleDoc}</div>
  <hr class="sep">
  <div class="row"><span>${L.no} ${sale.number}</span><span>${esc(sale.date)}</span></div>
  <div>${L.customer}: ${esc(customerLabel(sale.customer_name) || $t("Generico"))}</div>
  <hr class="sep">
  ${items.map(i => `
  <div class="item">
    <div class="item-name">${esc(i.name)}</div>
    <div class="row item-detail"><span>${i.qty} x ${fmt(i.price)}</span><span>${fmt(i.subtotal)}</span></div>
  </div>`).join('')}
  <hr class="sep">
  <div class="row"><span>${L.subtotal}</span><span>${fmt(sale.subtotal)}</span></div>
  ${sale.discount > 0 ? `<div class="row"><span>${L.discount}</span><span>-${fmt(sale.discount)}</span></div>` : ''}
  ${sale.tax > 0 ? `<div class="row"><span>${L.vat} ${cr.tax_rate||22}%</span><span>${fmt(sale.tax)}</span></div>` : ''}
  <div class="row grand-total"><span>${L.total}</span><span>${fmt(sale.total)}</span></div>
  <div class="row"><span>${L.payment}</span><span>${payment}</span></div>
  <hr class="sep">
  <div class="center muted">${esc(cr.footer_text || $t("Grazie!"))}</div>
</body></html>`
    }

    // ── Formato A4 ────────────────────────────────────────────
    return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; font-size: 13px; color: #222; padding: 30px; max-width: 210mm; margin: 0 auto; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; padding-bottom: 16px; border-bottom: 2px solid #222; }
  .company h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
  .company p  { font-size: 12px; color: #555; line-height: 1.5; }
  .doc-info   { text-align: right; }
  .doc-info h2 { font-size: 15px; font-weight: 600; color: #444; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px; }
  .doc-info p  { font-size: 12px; color: #555; }
  .customer-box { background: #f7f7f7; border-radius: 6px; padding: 12px 16px; margin-bottom: 20px; font-size: 12px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
  th { background: #222; color: #fff; padding: 8px 10px; font-size: 12px; text-align: left; }
  th.r, td.r { text-align: right; }
  td { padding: 7px 10px; border-bottom: 1px solid #eee; font-size: 13px; }
  tr:nth-child(even) td { background: #fafafa; }
  .totals { width: 240px; margin-left: auto; }
  .totals td { border: none; padding: 4px 10px; }
  .totals .total-row td { font-size: 15px; font-weight: 700; border-top: 2px solid #222; padding-top: 8px; }
  .footer { margin-top: 32px; padding-top: 14px; border-top: 1px solid #ddd; text-align: center; font-size: 11px; color: #888; }
  @media print { body { padding: 15px; } @page { margin: 10mm; } }
</style></head><body>
<div class="header">
  <div class="company">
    <h1>${bizName}</h1>
    ${cr.address ? `<p>${esc(cr.address)}</p>` : ''}
    ${cr.vat_number ? `<p>${L.vatNo}: ${esc(cr.vat_number)}</p>` : ''}
  </div>
  <div class="doc-info">
    <h2>${L.saleDocA4}</h2>
    <p>${L.no} ${sale.number}</p>
    <p>${L.date}: ${esc(sale.date)}</p>
  </div>
</div>
<div class="customer-box">
  <b>${L.customer}:</b> ${esc(customerLabel(sale.customer_name) || $t("Cliente generico"))}
  &nbsp;&nbsp;|&nbsp;&nbsp;<b>${L.payment}:</b> ${payment}
  ${sale.notes ? `&nbsp;&nbsp;|&nbsp;&nbsp;<b>${L.notes}:</b> ${esc(sale.notes)}` : ''}
</div>
<table>
  <thead><tr><th>${L.item}</th><th class="r">${L.qty}</th><th class="r">${L.unitPrice}</th><th class="r">${L.totalCol}</th></tr></thead>
  <tbody>
    ${items.map(i => `<tr><td>${esc(i.name)}</td><td class="r">${i.qty}</td><td class="r">${fmt(i.price)}</td><td class="r">${fmt(i.subtotal)}</td></tr>`).join('')}
  </tbody>
</table>
<table class="totals">
  <tr><td>${L.subtotal}</td><td class="r">${fmt(sale.subtotal)}</td></tr>
  ${sale.discount > 0 ? `<tr><td>${L.discount}</td><td class="r">-${fmt(sale.discount)}</td></tr>` : ''}
  ${sale.tax > 0 ? `<tr><td>${L.vat} ${cr.tax_rate||22}%</td><td class="r">${fmt(sale.tax)}</td></tr>` : ''}
  <tr class="total-row"><td>${L.total}</td><td class="r">${fmt(sale.total)}</td></tr>
</table>
<div class="footer">${esc(cr.footer_text || $t("Grazie per il tuo acquisto!"))}</div>
</body></html>`
  }

  const handleAddCustomer = async () => {
    if (!newCustomerForm.name.trim()) return
    try {
      const c = await addCustomer(newCustomerForm)
      setCustomers(prev => [...prev, c])
      setCustomer(c); setCustomerSearch(c.name)
      setNewCustomerModal(false)
      setNewCustomerForm({ name:'', email:'', phone:'', address:'' })
    } catch(e) { setError(e.message) }
  }

  const addByBarcode = useCallback(async (bc) => {
    if (!bc.trim()) return
    setScanError('')
    try {
      const p = await findByBarcode(bc.trim())
      addToCart(p)
      setScanCode('')
      scanInputRef.current?.focus()
    } catch {
      setScanError($t("Codice \"{0}\" non trovato", [bc]))
      setTimeout(() => setScanError(''), 2500)
    }
  }, [])

  return (
    <Layout {...props} title={$t("Vendite")}>
      <SectionLock section="sales" {...props}>
        {error && <div style={{background:'var(--danger-bg)',color:'var(--danger-text)',borderRadius:10,padding:'8px 12px',marginBottom:12,fontSize:12}}>{error} <button onClick={()=>setError('')} style={{background:'none',border:'none',cursor:'pointer',color:'var(--danger-text)'}}>×</button></div>}
        {success && <div style={{background:'var(--success-bg)',color:'var(--success-text)',borderRadius:10,padding:'8px 12px',marginBottom:12,fontSize:12,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          {success}
          {lastSale && <button onClick={handlePrint} style={{background:'var(--success-text)',border:'none',borderRadius:6,padding:'3px 10px',fontSize:11,color:'#fff',cursor:'pointer'}}>
            <i className="ti ti-printer" aria-hidden="true"></i>{" "}{$t("Stampa scontrino")}</button>}
        </div>}

        <div style={{display:'flex',gap:4,marginBottom:12}}>
          {[['cassa','ti-shopping-cart',$t("Cassa")],['storico','ti-history',$t("Storico vendite")],['clienti','ti-users',$t("Clienti")]].map(([t,icon,label])=>(
            <button key={t} onClick={()=>setTab(t)} style={{padding:'5px 14px',borderRadius:20,fontSize:12,cursor:'pointer',border:`0.5px solid ${tab===t?'var(--accent)':'var(--border)'}`,background:tab===t?'var(--accent-bg)':'transparent',color:tab===t?'var(--accent-text)':'var(--text3)'}}>
              <i className={`ti ${icon}`} style={{marginRight:4}} aria-hidden="true"></i>{label}
            </button>
          ))}
        </div>

        {tab==='cassa' && (
          <div style={{display:'grid',gridTemplateColumns:'1fr 340px',gap:12,height:'calc(100vh - 200px)'}}>
            {/* Sinistra - prodotti */}
            <div style={{display:'flex',flexDirection:'column',gap:10,overflow:'hidden'}}>
              {/* Scanner barcode + indicatore NFC */}
              <div style={{display:'flex',gap:6,alignItems:'center'}}>
                <div style={{position:'relative',flex:1}}>
                  <i className="ti ti-barcode" style={{position:'absolute',left:9,top:'50%',transform:'translateY(-50%)',fontSize:15,color:'var(--text3)',pointerEvents:'none'}} aria-hidden="true" />
                  <input
                    ref={scanInputRef}
                    value={scanCode}
                    onChange={e => setScanCode(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && addByBarcode(scanCode)}
                    placeholder={$t("Scansiona barcode o avvicina tag NFC prodotto...")}
                    style={{width:'100%', paddingLeft:30, fontSize:12,
                      borderColor: scanError ? 'var(--danger-text)' : undefined}}
                  />
                </div>
                {/* Badge NFC attivo */}
                <div title={$t("NFC attivo — avvicina tag prodotto o carta")} style={{flexShrink:0,width:32,height:32,borderRadius:8,background:'var(--info-bg)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'default'}}>
                  <i className="ti ti-wifi" style={{fontSize:16,color:'var(--info-text)'}} aria-hidden="true" />
                </div>
              </div>
              {scanError && <div style={{fontSize:11,color:'var(--danger-text)',marginTop:-6}}>{scanError}</div>}
              <input value={productSearch} onChange={e=>setProductSearch(e.target.value)}
                placeholder={$t("Cerca prodotto per nome...")} style={{width:'100%'}} />
              <div style={{flex:1,overflow:'auto',background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12}}>
                {filteredProducts.length === 0 ? (
                  <div style={{textAlign:'center',padding:'30px',color:'var(--text3)',fontSize:13}}>{$t("Nessun prodotto trovato")}</div>
                ) : (
                  <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))',gap:8,padding:10}}>
                    {filteredProducts.map(p=>(
                      <button key={p.id} onClick={()=>addToCart(p)} disabled={p.qty<=0} style={{
                        background: p.qty<=0?'var(--bg3)':'var(--bg2)',
                        border:`0.5px solid ${p.qty<=0?'var(--border)':'var(--accent)'}`,
                        borderRadius:10,padding:10,cursor:p.qty<=0?'default':'pointer',
                        textAlign:'left',transition:'background 0.1s',
                      }}>
                        <div style={{fontSize:13,fontWeight:500,color:p.qty<=0?'var(--text3)':'var(--text)',marginBottom:2}}>{p.name}</div>
                        <div style={{fontSize:12,color:'var(--accent)',fontWeight:500}}>€{parseFloat(p.price||0).toFixed(2)}</div>
                        <div style={{fontSize:11,color:p.qty<=0?'var(--danger-text)':p.qty<=5?'var(--warn-text)':'var(--text3)'}}>
                          {p.qty<=0?$t("Esaurito"):`${p.qty} ${p.unit}`}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Destra - carrello */}
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              {/* Cliente */}
              <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:10}}>
                <div style={{fontSize:11,color:'var(--text3)',marginBottom:6}}>{$t("CLIENTE")}</div>
                <div style={{display:'flex',gap:6}}>
                  <input value={customerSearch} onChange={e=>{setCustomerSearch(e.target.value);if(!e.target.value){setCustomer(null)}}}
                    placeholder={$t("Cerca cliente...")} style={{flex:1,fontSize:12}} />
                  <button onClick={()=>setNewCustomerModal(true)} style={{background:'var(--accent)',border:'none',borderRadius:6,padding:'0 8px',color:'#fff',cursor:'pointer',fontSize:12}}>+</button>
                </div>
                {customerSearch && !customer && filteredCustomers.length > 0 && (
                  <div style={{background:'var(--bg3)',borderRadius:8,marginTop:4,maxHeight:100,overflow:'auto'}}>
                    {filteredCustomers.map(c=>(
                      <div key={c.id} onClick={()=>{setCustomer(c);setCustomerSearch(c.name)}}
                        style={{padding:'6px 8px',cursor:'pointer',fontSize:12,color:'var(--text)',borderBottom:'0.5px solid var(--border)'}}>
                        {c.name} {c.phone&&<span style={{color:'var(--text3)'}}>— {c.phone}</span>}
                      </div>
                    ))}
                  </div>
                )}
                {customer && <div style={{fontSize:11,color:'var(--success-text)',marginTop:4}}><i className="ti ti-check" aria-hidden="true"></i> {customer.name}</div>}
              </div>

              {/* Carrello */}
              <div style={{flex:1,background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,overflow:'auto'}}>
                {cart.length === 0 ? (
                  <div style={{textAlign:'center',padding:'30px',color:'var(--text3)',fontSize:13}}>{$t("Aggiungi articoli dalla lista")}</div>
                ) : cart.map((item, idx)=>(
                  <div key={idx} style={{display:'flex',alignItems:'center',gap:6,padding:'8px 10px',borderBottom:'0.5px solid var(--border)'}}>
                    <div style={{flex:1,fontSize:12,fontWeight:500,color:'var(--text)'}}>{item.name}</div>
                    <input type="number" value={item.qty} onChange={e=>updateCartItem(idx,'qty',e.target.value)}
                      min="1" style={{width:44,fontSize:12,padding:'3px 5px',textAlign:'center'}} />
                    <span style={{fontSize:11,color:'var(--text3)'}}>×</span>
                    <div style={{position:'relative'}}>
                      <span style={{position:'absolute',left:6,top:'50%',transform:'translateY(-50%)',fontSize:11,color:'var(--text3)'}}>€</span>
                      <input type="number" value={item.price} onChange={e=>updateCartItem(idx,'price',e.target.value)}
                        min="0" step="0.01" style={{width:60,fontSize:12,padding:'3px 5px 3px 16px'}} />
                    </div>
                    <span style={{fontSize:12,fontWeight:500,color:'var(--accent)',minWidth:50,textAlign:'right'}}>€{(item.subtotal||0).toFixed(2)}</span>
                    <button onClick={()=>removeFromCart(idx)} style={{background:'var(--danger-bg)',border:'none',borderRadius:4,padding:'2px 6px',cursor:'pointer',color:'var(--danger-text)',fontSize:11}}>×</button>
                  </div>
                ))}
              </div>

              {/* Totali e pagamento */}
              <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:10}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:12,marginBottom:4}}>
                  <span style={{color:'var(--text3)'}}>{$t("Subtotale")}</span>
                  <span>€{subtotal.toFixed(2)}</span>
                </div>
                <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:4}}>
                  <span style={{fontSize:12,color:'var(--text3)'}}>{$t("Sconto %")}</span>
                  <input type="number" value={discount} onChange={e=>setDiscount(parseFloat(e.target.value)||0)}
                    min="0" max="100" style={{width:50,fontSize:12,padding:'2px 5px'}} />
                  {discount>0 && <span style={{fontSize:12,color:'var(--danger-text)'}}>-€{discountAmt.toFixed(2)}</span>}
                </div>
                {tax>0 && <div style={{display:'flex',justifyContent:'space-between',fontSize:12,marginBottom:4}}>
                  <span style={{color:'var(--text3)'}}>{$t("IVA")}{" "}{cashReg?.tax_rate||22}%</span>
                  <span>€{tax.toFixed(2)}</span>
                </div>}
                <div style={{display:'flex',justifyContent:'space-between',fontSize:16,fontWeight:600,color:'var(--text)',marginBottom:8,paddingTop:6,borderTop:'0.5px solid var(--border)'}}>
                  <span>{$t("TOTALE")}</span><span style={{color:'var(--accent)'}}>€{total.toFixed(2)}</span>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:4,marginBottom:8}}>
                  {[
                    ['contanti',  'ti-cash',         $t("Contanti")],
                    ['carta',     'ti-credit-card',  $t("Carta")],
                    ['pos_nfc',   'ti-device-mobile',$t("POS / NFC")],
                    ['bonifico',  'ti-building-bank',$t("Bonifico")],
                    ['assegno',   'ti-writing',      $t("Assegno")],
                    ['altro',     'ti-dots',         $t("Altro")],
                    ['credito',   'ti-hourglass',    $t("A credito (paga più avanti)")],
                  ].map(([val,icon,label])=>(
                    <button key={val} onClick={()=>setPaymentMethod(val)} style={{
                      gridColumn: val==='credito' ? '1 / -1' : undefined,
                      padding:'6px 4px',borderRadius:8,fontSize:11,cursor:'pointer',
                      border:`0.5px solid ${paymentMethod===val?'var(--accent)':'var(--border)'}`,
                      background:paymentMethod===val?'var(--accent-bg)':'transparent',
                      color:paymentMethod===val?'var(--accent-text)':'var(--text3)',
                    }}>
                      <i className={`ti ${icon}`} style={{display:'block',fontSize:16,marginBottom:2}} aria-hidden="true"></i>{label}
                    </button>
                  ))}
                </div>
                {paymentMethod === 'pos_nfc' && !nfcCard && (
                  <div style={{background:'var(--info-bg)',color:'var(--info-text)',borderRadius:8,padding:'7px 10px',fontSize:11,marginBottom:6,display:'flex',alignItems:'center',gap:6}}>
                    <i className="ti ti-wifi" aria-hidden="true"></i>{$t("Avvicina la carta al lettore NFC o telefono — poi conferma")}</div>
                )}
                {nfcCard && (
                  <div style={{background:'var(--success-bg)',color:'var(--success-text)',borderRadius:8,padding:'8px 10px',fontSize:12,marginBottom:6,display:'flex',alignItems:'center',gap:8}}>
                    <i className="ti ti-credit-card" style={{fontSize:18,flexShrink:0}} aria-hidden="true"></i>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600}}>{nfcCard.brand}{" "}{$t("contactless rilevata")}</div>
                      <div style={{fontSize:11,opacity:0.8}}>{$t("Conferma il pagamento sul POS poi clicca \"Completa vendita\"")}</div>
                    </div>
                    <button onClick={()=>setNfcCard(null)} style={{background:'none',border:'none',cursor:'pointer',color:'inherit',fontSize:16,padding:0}}>×</button>
                  </div>
                )}
                {paymentMethod==='credito' && (
                  <div style={{background:'var(--warn-bg)',color:'var(--warn-text)',borderRadius:8,padding:'8px 10px',fontSize:11,marginBottom:6}}>
                    {customer ? <>{$t("Il cliente")}{" "}<b>{customer.name}</b>{" "}{$t("dovrà pagare")}{" "}<b>€{total.toFixed(2)}</b>{$t(": finirà nello Scadenzario.")}</> : <b>{$t("Scegli un cliente per vendere a credito.")}</b>}
                    <div style={{display:'flex',alignItems:'center',gap:8,marginTop:6}}>
                      <span>{$t("Scadenza")}</span>
                      <input type="date" value={dueDate} onChange={e=>setDueDate(e.target.value)} style={{fontSize:12,flex:1}} />
                    </div>
                  </div>
                )}
                {paymentMethod==='altro' && <input value={paymentOther} onChange={e=>setPaymentOther(e.target.value)} placeholder={$t("Specifica metodo...")} style={{width:'100%',marginBottom:6,fontSize:12}} />}
                {posWaiting && (
                  <div style={{background:'var(--info-bg)',color:'var(--info-text)',borderRadius:8,padding:'10px 14px',fontSize:12,marginBottom:6,display:'flex',alignItems:'center',gap:8}}>
                    <i className="ti ti-device-mobile" style={{fontSize:18,flexShrink:0}} aria-hidden="true"></i>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600}}>{$t("In attesa del POS Android...")}</div>
                      <div style={{fontSize:11,opacity:0.8}}>{$t("Il cliente deve avvicinare la carta al telefono POS")}</div>
                    </div>
                    <button onClick={handleCancelPOS} style={{background:'none',border:'0.5px solid var(--info-text)',borderRadius:6,padding:'3px 10px',fontSize:11,color:'var(--info-text)',cursor:'pointer'}}>{$t("Annulla")}</button>
                  </div>
                )}
                <input value={notes} onChange={e=>setNotes(e.target.value)} placeholder={$t("Note vendita...")} style={{width:'100%',marginBottom:8,fontSize:12}} />
                {paymentMethod==='pos_nfc' && !nfcCard && !posWaiting ? (
                  <button onClick={handleSendToPOS} disabled={loading||cart.length===0} style={{
                    width:'100%',background:loading||cart.length===0?'var(--bg3)':'#58a6ff',
                    border:'none',borderRadius:8,padding:'10px',fontSize:14,fontWeight:600,
                    color:loading||cart.length===0?'var(--text3)':'#fff',cursor:loading||cart.length===0?'default':'pointer',
                  }}>
                    <i className="ti ti-device-mobile" style={{marginRight:6}} aria-hidden="true"></i>{$t("Invia al POS — €")}{total.toFixed(2)}
                  </button>
                ) : (
                  <button onClick={() => handleSale()} disabled={loading||cart.length===0||posWaiting} style={{
                    width:'100%',background:loading||cart.length===0||posWaiting?'var(--bg3)':'var(--accent)',
                    border:'none',borderRadius:8,padding:'10px',fontSize:14,fontWeight:600,
                    color:loading||cart.length===0||posWaiting?'var(--text3)':'#fff',cursor:loading||cart.length===0||posWaiting?'default':'pointer',
                  }}>
                    {loading?$t("Registrazione..."):posWaiting?$t("In attesa POS..."):$t("✓ Completa vendita")}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {tab==='storico' && (
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:10}}>{$t("Storico vendite")}</div>
            {sales.length===0 ? (
              <div style={{textAlign:'center',padding:'30px',color:'var(--text3)',fontSize:13}}>{$t("Nessuna vendita")}</div>
            ) : sales.map(s=>(
              <div key={s.id} style={{display:'flex',alignItems:'center',gap:10,padding:'9px 0',borderBottom:'0.5px solid var(--border)'}}>
                <span style={{fontSize:12,fontWeight:500,color:'var(--accent)',minWidth:40}}>#{s.number}</span>
                <span style={{fontSize:12,color:'var(--text3)',minWidth:80}}>{s.date}</span>
                <span style={{flex:1,fontSize:13,color:'var(--text)'}}>{customerLabel(s.customer_name)}</span>
                <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,background:'var(--info-bg)',color:'var(--info-text)'}}>{payLabel(s.payment_method)}</span>
                <span style={{fontSize:13,fontWeight:600,color:'var(--accent)'}}>€{parseFloat(s.total||0).toFixed(2)}</span>
                <button onClick={()=>{setLastSale({...s,items:Array.isArray(s.items)?s.items:[],cashReg:cashReg});handlePrint()}}
                  style={{background:'transparent',border:'0.5px solid var(--border)',borderRadius:6,padding:'3px 8px',fontSize:11,color:'var(--text)',cursor:'pointer'}}>
                  <i className="ti ti-printer" aria-hidden="true"></i>
                </button>
              </div>
            ))}
          </div>
        )}

        {tab==='clienti' && (
          <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:12,padding:'14px 16px'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
              <div style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'0.06em'}}>{$t("Clienti")}</div>
              <button onClick={()=>setNewCustomerModal(true)} style={{background:'var(--accent)',border:'none',borderRadius:8,padding:'6px 12px',fontSize:12,color:'#fff',cursor:'pointer',fontWeight:500}}>
                <i className="ti ti-plus" aria-hidden="true"></i>{" "}{$t("Nuovo cliente")}</button>
            </div>
            {customers.length===0 ? (
              <div style={{textAlign:'center',padding:'30px',color:'var(--text3)',fontSize:13}}>{$t("Nessun cliente")}</div>
            ) : customers.map(c=>(
              <div key={c.id} style={{display:'flex',alignItems:'center',gap:10,padding:'9px 0',borderBottom:'0.5px solid var(--border)'}}>
                <div style={{width:32,height:32,borderRadius:'50%',background:'var(--accent-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:500,color:'var(--accent-text)',flexShrink:0}}>
                  {c.name?.[0]?.toUpperCase()||'C'}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:500,color:'var(--text)'}}>{c.name}</div>
                  <div style={{fontSize:11,color:'var(--text3)'}}>{[c.email,c.phone].filter(Boolean).join(' — ')}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal nuovo cliente */}
        {newCustomerModal && (
          <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:100}}>
            <div style={{background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:14,padding:22,width:320}}>
              <div style={{fontWeight:500,fontSize:15,color:'var(--text)',marginBottom:14}}>{$t("Nuovo cliente")}</div>
              {[[$t("Nome *"),'text','name',$t("Mario Rossi")],[$t("Email"),'email','email',$t("email@esempio.it")],[$t("Telefono"),'text','phone','+39 333 1234567'],[$t("Indirizzo"),'text','address',$t("Via Roma 1")]].map(([label,type,field,ph])=>(
                <div key={field} style={{marginBottom:10}}>
                  <label style={{fontSize:11,color:'var(--text2)',display:'block',marginBottom:4}}>{label}</label>
                  <input type={type} value={newCustomerForm[field]} onChange={e=>setNewCustomerForm(p=>({...p,[field]:e.target.value}))} placeholder={ph} style={{width:'100%'}} />
                </div>
              ))}
              <div style={{display:'flex',gap:8,marginTop:4}}>
                <button onClick={()=>setNewCustomerModal(false)} style={{flex:1,border:'0.5px solid var(--border)',borderRadius:8,padding:8,fontSize:13,background:'transparent',color:'var(--text)',cursor:'pointer'}}>{$t("Annulla")}</button>
                <button onClick={handleAddCustomer} style={{flex:2,background:'var(--accent)',border:'none',borderRadius:8,padding:8,fontSize:13,color:'#fff',cursor:'pointer',fontWeight:500}}>{$t("Salva")}</button>
              </div>
            </div>
          </div>
        )}
      </SectionLock>
    </Layout>
  )
}
