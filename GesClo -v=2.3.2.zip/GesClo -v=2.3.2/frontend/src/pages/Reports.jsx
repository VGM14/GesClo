import React, { useState, useEffect, useCallback } from 'react'
import Layout from '../components/Layout'
import SectionLock from '../components/SectionLock'
import { getReportSummary } from '../services/apiService'
import { $t, LOCALE, payLabel } from '../i18n'

const eur = (n) => Number(n || 0).toLocaleString(LOCALE, { style: 'currency', currency: 'EUR' })
const pct = (n) => (n == null ? '—' : `${n.toFixed(1).replace('.', ',')}%`)

// Le date delle vendite sono salvate come data UTC (toISOString): i preset usano lo stesso
// criterio così coincidono con quelle del server.
const isoDay = (d) => d.toISOString().split('T')[0]
const daysAgo = (n) => { const d = new Date(); d.setUTCDate(d.getUTCDate() - n); return isoDay(d) }

const PRESETS = [
  [$t("Oggi"),        () => [isoDay(new Date()), isoDay(new Date())]],
  [$t("7 giorni"), () => [daysAgo(6),  isoDay(new Date())]],
  [$t("30 giorni"), () => [daysAgo(29), isoDay(new Date())]],
  [$t("Mese corrente"), () => { const n = new Date(); return [isoDay(new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), 1))), isoDay(n)] }],
  [$t("Anno corrente"), () => { const n = new Date(); return [isoDay(new Date(Date.UTC(n.getUTCFullYear(), 0, 1))), isoDay(n)] }],
]

const card  = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px' }
const title = { fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }

function Kpi({ label, value, sub, tone }) {
  return (
    <div style={{ ...card, padding: '12px 14px' }}>
      <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 600, color: tone || 'var(--text)' }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{sub}</div>}
    </div>
  )
}

export default function Reports(props) {
  const [from, setFrom] = useState(daysAgo(29))
  const [to, setTo] = useState(isoDay(new Date()))
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback((f, t) => {
    setLoading(true); setError('')
    getReportSummary(f, t)
      .then(d => { setData(d); setFrom(d.range.from); setTo(d.range.to) })
      .catch(e => setError(e?.message || String(e)))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => { load(from, to) }, [])

  const applyPreset = (fn) => { const [f, t] = fn(); load(f, t) }

  const maxDay = data ? Math.max(1, ...data.byDay.map(d => d.revenue)) : 1
  const coveredShare = data && data.revenueNet > 0 ? (data.coveredRevenue / data.revenueNet) * 100 : null
  const maxPay = data ? Math.max(1, ...data.byPayment.map(p => p.total)) : 1
  const marginTone = data && data.margin < 0 ? 'var(--danger-text)' : 'var(--success-text)'

  return (
    <Layout {...props} title={$t("Report")}>
      <SectionLock section="reports" {...props}>
        {error && <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{error}</div>}

        {/* Periodo */}
        <div style={{ ...card, marginBottom: 12, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {PRESETS.map(([name, fn]) => (
            <button key={name} onClick={() => applyPreset(fn)} style={{ padding: '5px 12px', borderRadius: 20, fontSize: 12, cursor: 'pointer', border: '0.5px solid var(--border)', background: 'transparent', color: 'var(--text2)' }}>{name}</button>
          ))}
          <span style={{ flex: 1 }} />
          <input type="date" value={from} max={to} onChange={e => setFrom(e.target.value)} style={{ width: 138 }} />
          <span style={{ fontSize: 12, color: 'var(--text3)' }}>→</span>
          <input type="date" value={to} min={from} onChange={e => setTo(e.target.value)} style={{ width: 138 }} />
          <button onClick={() => load(from, to)} style={{ background: 'var(--accent)', border: 'none', borderRadius: 8, padding: '7px 14px', fontSize: 12, color: '#fff', cursor: 'pointer', fontWeight: 500 }}>{$t("Applica")}</button>
        </div>

        {loading && !data ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Caricamento...")}</div>
        ) : data && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, opacity: loading ? 0.6 : 1 }}>
            {/* KPI */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: 10 }}>
              <Kpi label={$t("Ricavi netti")} value={eur(data.revenueNet)} sub={$t("senza IVA, al netto degli sconti")} />
              <Kpi label={$t("Margine")} value={data.marginPct == null ? '—' : eur(data.margin)} sub={data.marginPct == null ? $t("costi non impostati") : $t("{0} sul venduto con costo", [pct(data.marginPct)])} tone={data.marginPct == null ? undefined : marginTone} />
              <Kpi label={$t("Vendite")} value={data.salesCount} sub={$t("scontrino medio {0}", [eur(data.avgTicket)])} />
              <Kpi label={$t("Incasso lordo")} value={eur(data.revenueGross)} sub={$t("di cui IVA {0}", [eur(data.tax)])} />
              <Kpi label={$t("Sconti concessi")} value={eur(data.discounts)} />
            </div>

            {data.salesCount > 0 && data.uncoveredRevenue > 0.005 && (
              <div style={{ background: 'var(--warn-bg)', color: 'var(--warn-text)', borderRadius: 10, padding: '9px 12px', fontSize: 12, lineHeight: 1.5 }}>{$t("Il margine considera solo il")}{" "}<b>{coveredShare == null ? '0' : coveredShare.toFixed(0)}%</b>{" "}{$t("dei ricavi: per il resto (")}{eur(data.uncoveredRevenue)}{$t(") manca il costo d'acquisto (articoli senza costo impostato o vendite POS). Imposta il costo degli articoli in")}{" "}<b>{$t("Stock")}</b>{$t(", oppure ricevi gli ordini d'acquisto da")}{" "}<b>{$t("Acquisti")}</b>{$t(": il costo si aggiorna da solo.")}</div>
            )}

            {/* Andamento */}
            <div style={card}>
              <div style={title}>{$t("Andamento giornaliero dei ricavi netti")}</div>
              {data.salesCount === 0 ? (
                <div style={{ textAlign: 'center', padding: '28px 0', color: 'var(--text3)', fontSize: 13 }}>{$t("Nessuna vendita nel periodo")}</div>
              ) : (
                <>
                  <div style={{ display: 'flex', alignItems: 'flex-end', gap: data.byDay.length > 60 ? 1 : 3, height: 130, borderBottom: '0.5px solid var(--border)' }}>
                    {data.byDay.map(d => (
                      <div key={d.date} title={$t("{0}\nRicavi netti: {1}\nMargine: {2}\nVendite: {3}", [d.date, eur(d.revenue), eur(d.margin), d.sales])}
                        style={{ flex: 1, minWidth: 1, height: `${Math.max(d.revenue > 0 ? 3 : 0, (d.revenue / maxDay) * 100)}%`, background: 'var(--accent)', borderRadius: '3px 3px 0 0', opacity: d.revenue > 0 ? 1 : 0.15 }} />
                    ))}
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>
                    <span>{data.byDay[0]?.date}</span>
                    <span>{$t("massimo giornaliero")}{" "}{eur(maxDay)}</span>
                    <span>{data.byDay[data.byDay.length - 1]?.date}</span>
                  </div>
                </>
              )}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 12 }}>
              {/* Top articoli */}
              <div style={card}>
                <div style={title}>{$t("Articoli più venduti (per ricavo)")}</div>
                {data.topProducts.length === 0 ? (
                  <div style={{ color: 'var(--text3)', fontSize: 13, padding: '12px 0' }}>{$t("Nessun dato nel periodo")}</div>
                ) : (
                  <div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 44px 84px 84px', gap: 8, fontSize: 11, color: 'var(--text3)', padding: '0 0 6px', borderBottom: '0.5px solid var(--border)' }}>
                      <span>{$t("Articolo")}</span><span style={{ textAlign: 'right' }}>{$t("Pz")}</span><span style={{ textAlign: 'right' }}>{$t("Ricavo")}</span><span style={{ textAlign: 'right' }}>{$t("Margine")}</span>
                    </div>
                    {data.topProducts.map((p, i) => (
                      <div key={(p.product_id || p.name) + i} style={{ display: 'grid', gridTemplateColumns: '1fr 44px 84px 84px', gap: 8, padding: '7px 0', borderBottom: '0.5px solid var(--border)', fontSize: 13, alignItems: 'center' }}>
                        <span style={{ color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={p.name}>{p.name}</span>
                        <span style={{ textAlign: 'right', color: 'var(--text2)' }}>{p.qty}</span>
                        <span style={{ textAlign: 'right', color: 'var(--text)' }}>{eur(p.revenue)}</span>
                        <span style={{ textAlign: 'right', color: p.margin == null ? 'var(--text3)' : p.margin < 0 ? 'var(--danger-text)' : 'var(--success-text)' }}>
                          {p.margin == null ? '—' : <>{eur(p.margin)}<div style={{ fontSize: 10, color: 'var(--text3)' }}>{pct(p.marginPct)}</div></>}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {/* Pagamenti */}
                <div style={card}>
                  <div style={title}>{$t("Metodi di pagamento")}</div>
                  {data.byPayment.length === 0 ? (
                    <div style={{ color: 'var(--text3)', fontSize: 13 }}>{$t("Nessun dato nel periodo")}</div>
                  ) : data.byPayment.map(p => (
                    <div key={p.method} style={{ marginBottom: 8 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text)', marginBottom: 3 }}>
                        <span style={{ textTransform: 'capitalize' }}>{payLabel(p.method)} <span style={{ color: 'var(--text3)' }}>· {p.count}</span></span>
                        <span>{eur(p.total)}</span>
                      </div>
                      <div style={{ background: 'var(--bg3)', borderRadius: 4, height: 6 }}>
                        <div style={{ width: `${(p.total / maxPay) * 100}%`, height: '100%', background: 'var(--accent)', borderRadius: 4 }} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Magazzino */}
                <div style={card}>
                  <div style={title}>{$t("Valore del magazzino (oggi)")}</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    <div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("A costo")}</div><div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{eur(data.stock.costValue)}</div></div>
                    <div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("A prezzo di vendita")}</div><div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{eur(data.stock.retailValue)}</div></div>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 8 }}>
                    {data.stock.units}{" "}{$t("pezzi in")}{" "}{data.stock.products}{" "}{$t("articoli")}{data.stock.withoutCost > 0 && <span style={{ color: 'var(--warn-text)' }}> · {data.stock.withoutCost}{" "}{$t("articoli in giacenza senza costo (non inclusi nel valore a costo)")}</span>}
                  </div>
                </div>

                {/* Scadenzario */}
                <div style={card}>
                  <div style={title}>{$t("Scadenzario (oggi)")}</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("Da incassare")}</div>
                      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{eur(data.dues.creditOpen)}</div>
                      <div style={{ fontSize: 11, color: data.dues.creditOverdue > 0 ? 'var(--danger-text)' : 'var(--text3)' }}>{data.dues.creditOverdue > 0 ? $t("di cui scaduti {0}", [eur(data.dues.creditOverdue)]) : $t("nulla in ritardo")}</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("Da pagare")}</div>
                      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{eur(data.dues.debitOpen)}</div>
                      <div style={{ fontSize: 11, color: data.dues.debitOverdue > 0 ? 'var(--danger-text)' : 'var(--text3)' }}>{data.dues.debitOverdue > 0 ? $t("di cui scaduti {0}", [eur(data.dues.debitOverdue)]) : $t("nulla in ritardo")}</div>
                    </div>
                  </div>
                </div>

                {/* Acquisti */}
                <div style={card}>
                  <div style={title}>{$t("Acquisti")}</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    <div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("Ricevuti nel periodo")}</div><div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{eur(data.purchases.receivedTotal)}</div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{data.purchases.receivedCount} {data.purchases.receivedCount === 1 ? $t("ordine") : $t("ordini")}</div></div>
                    <div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{$t("Ordini aperti")}</div><div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{eur(data.purchases.openTotal)}</div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{data.purchases.openCount}{" "}{$t("da ricevere")}</div></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </SectionLock>
    </Layout>
  )
}
