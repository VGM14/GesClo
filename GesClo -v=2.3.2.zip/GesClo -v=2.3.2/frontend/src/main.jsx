import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import App from './App'
import './index.css'

// HashRouter (non BrowserRouter): la UI e caricata da file://, non da un server HTTP,
// quindi non c'e nessuno che possa risolvere percorsi come /stock su reload o deep-link.
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HashRouter>
      <App />
    </HashRouter>
  </React.StrictMode>
)
