import { $t } from './i18n'
// Novità di ogni versione, mostrate in un popup al primo accesso dopo un aggiornamento.
// Per una nuova release: aggiungere una voce IN CIMA alla lista (la prima è la versione
// corrente) e tenere allineate AppVersion in installer-webapp/GesClo.iss e la versione
// restituita da /health in server/server.js.
export const CHANGELOG = [
  {
    version: '2.3.2',
    date: '2026-11-13',
    title: $t('Più codici a barre e cassa più veloce'),
    items: [
      $t('Più codici a barre per articolo: aggiungi quanti ne servono (confezioni o fornitori diversi) e ogni codice trova lo stesso articolo.'),
      $t('Alla cassa il cursore è già nel campo del lettore di codici a barre: basta passare il codice.'),
      $t('Corretta la barra «Risorse dispositivo»: ora mostra davvero CPU, RAM e spazio su disco del server.'),
    ],
  },
  {
    version: '2.3.1',
    date: '2026-09-26',
    title: $t('GesClo parla anche inglese'),
    items: [
      $t('Nuovo selettore lingua Italiano / English: si cambia dal menu laterale o dalla schermata di accesso e la scelta viene ricordata.'),
      $t('Anche i messaggi d’errore del server, lo scontrino, l’assistente GesBot e l’installer sono disponibili in inglese.'),
      $t('Le intestazioni dei file CSV si riconoscono in entrambe le lingue.'),
    ],
  },
  {
    version: '2.3',
    date: '2026-09-23',
    title: $t('Scorte, inventario, scadenzario e importazioni'),
    items: [
      $t('Scorta minima e riordino: imposta per ogni articolo la scorta minima, la quantità di riordino e il fornitore abituale; in Acquisti compare l’elenco degli articoli da riordinare e un pulsante crea le bozze d’ordine per fornitore.'),
      $t('Inventario (Stock → Inventario): conta i pezzi, applica le rettifiche in un colpo solo e ogni differenza finisce nei Movimenti. Il conteggio si può interrompere e riprendere.'),
      $t('Scadenzario: vendite «A credito», debiti verso i fornitori generati dagli ordini ricevuti, scadenze inserite a mano, pagamenti anche parziali e segnalazione dei ritardi.'),
      $t('Esporta e importa CSV per articoli, clienti e fornitori (si apre con Excel), con anteprima prima di importare.'),
      $t('Scheda di dettaglio di clienti e fornitori con storico di vendite o ordini e scadenze aperte.'),
      $t('Nel Report compare il riepilogo di crediti e debiti aperti.'),
    ],
  },
  {
    version: '2.2',
    date: '2026-09-22',
    title: $t('Fornitori, acquisti e margini'),
    items: [
      $t('Nuova sezione Anagrafiche: clienti e fornitori in un unico posto, con ricerca, P.IVA, contatti e riepilogo di vendite e ordini.'),
      $t('Nuova sezione Acquisti: ordini d’acquisto ai fornitori (bozza, ordinato, ricevuto).'),
      $t('Quando la merce arriva basta premere “Ricevi”: il magazzino si carica da solo e viene registrato il movimento di entrata.'),
      $t('Ogni articolo ha ora un costo d’acquisto, aggiornato in automatico (costo medio) a ogni ordine ricevuto; in Stock vedi il margine.'),
      $t('Report completamente nuovo: ricavi, margine, andamento giornaliero, articoli più venduti, metodi di pagamento, valore del magazzino e acquisti, per il periodo che scegli.'),
      $t('Correzione: il codice NFC inserito nel form di un nuovo articolo ora viene salvato.'),
    ],
  },
  {
    version: '2.1',
    date: '2026-09-21',
    title: $t('Scontrino automatico, backup e più sicurezza'),
    items: [
      $t('Lo scontrino viene stampato automaticamente a fine vendita (si disattiva da Admin → Cassa).'),
      $t('Avviso quando vendi più pezzi di quelli in magazzino.'),
      $t('Backup e ripristino del database da Admin → Sistema (solo Super Admin).'),
      $t('Chiave di sicurezza per POS e NFC generata in automatico, gestibile da Admin → Hardware.'),
      $t('Salvataggio dei dati più robusto in caso di blackout o chiusura improvvisa.'),
      $t('Correzioni: schermata bianca aprendo lo Scanner, identificativi univoci per vendite e articoli, stampa corretta dei nomi con caratteri speciali.'),
      $t('Se una pagina va in errore ora compare un messaggio con il pulsante per ricaricare, invece dello schermo bianco.'),
    ],
  },
  {
    version: '2.0',
    date: '2026-09-19',
    title: $t('Installer Windows e primo avvio guidato'),
    items: [
      $t('Installer con procedura guidata, senza bisogno di diritti di amministratore.'),
      $t('Al primo avvio si crea l’account amministratore: niente più utente predefinito.'),
      $t('Database SQLite integrato e modalità Standalone / Server / Terminal per la rete locale.'),
    ],
  },
]

export const APP_VERSION = CHANGELOG[0].version

const toParts = (v) => String(v).split('.').map(n => parseInt(n, 10) || 0)

function compareVersions(a, b) {
  const pa = toParts(a), pb = toParts(b)
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0)
    if (d !== 0) return d
  }
  return 0
}

// Voci più recenti dell'ultima versione vista (dalla più nuova alla più vecchia).
// Se non si sa cosa l'utente abbia già visto, si mostra solo la versione corrente.
export function getUnseenChangelog(lastSeen) {
  if (!lastSeen) return CHANGELOG.slice(0, 1)
  return CHANGELOG.filter(e => compareVersions(e.version, lastSeen) > 0)
}
