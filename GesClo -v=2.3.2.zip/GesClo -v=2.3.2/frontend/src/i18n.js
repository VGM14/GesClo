// Traduzione dell'interfaccia (italiano / inglese).
//
// Il testo italiano originale è la chiave: $t('Nuovo articolo') restituisce lo stesso testo
// in italiano e la traduzione in inglese se la lingua è EN (dizionario in locales/en.js).
// Le parti variabili si scrivono come {0}, {1}... e si passano in un array:
//   $t('Vendita #{0} registrata!', [sale.number])
// Se manca la traduzione si mostra il testo italiano, così un errore di dizionario non
// lascia mai un campo vuoto.
//
// Cambiare lingua ricarica la pagina: la lingua non cambia mai mentre l'app è aperta,
// quindi $t si può usare anche fuori dai componenti (costanti a livello di modulo).
import EN from './locales/en'

const KEY = 'gesclo_lang'

function detectLang() {
  try {
    const saved = localStorage.getItem(KEY)
    if (saved === 'it' || saved === 'en') return saved
  } catch {}
  // Prima apertura: lingua del browser (italiano → IT, tutto il resto → EN)
  return String(navigator.language || 'it').toLowerCase().startsWith('it') ? 'it' : 'en'
}

export const LANG = detectLang()
export const LOCALE = LANG === 'it' ? 'it-IT' : 'en-GB'

// Lingua del documento (correttore ortografico, sintesi vocale, formati dei campi data)
try { document.documentElement.lang = LANG } catch {}

export function setLang(lang) {
  try { localStorage.setItem(KEY, lang) } catch {}
  window.location.reload()
}

export function $t(text, args) {
  let out = LANG === 'en' ? (EN[text] ?? text) : text
  if (args) out = out.replace(/\{(\d+)\}/g, (_, i) => (args[i] === undefined || args[i] === null ? '' : args[i]))
  return out
}

// Testi italiani che in inglese diventano `text` (serve a riconoscere nei file CSV le
// intestazioni scritte nell'altra lingua).
let REVERSE = null
export function sourcesOf(text) {
  if (LANG === 'it') return [text]
  if (!REVERSE) {
    REVERSE = {}
    for (const [it, en] of Object.entries(EN)) (REVERSE[en] ||= []).push(it)
  }
  return REVERSE[text] || []
}

// Diciture che il server salva nei dati (es. l'etichetta di una scadenza creata da una vendita):
// restano in italiano nel database e vengono tradotte solo quando si mostrano.
export function dataText(text) {
  if (LANG === 'it' || typeof text !== 'string') return text
  return text
    .replace(/^Vendita N°(.*)$/, 'Sale No. $1')
    .replace(/^Ordine acquisto N°(.*)$/, 'Purchase order No. $1')
    .replace(/^Inserita a mano$/, 'Entered by hand')
    .replace(/^Riordino automatico (scorta minima)$/, 'Automatic reorder (minimum stock)')
}

// Nome cliente generico salvato nei dati (le vendite fatte senza cliente lo registrano in italiano)
export const customerLabel = (name) => (name === 'Cliente generico' ? $t('Cliente generico') : name)

// Nei dati (database) i metodi di pagamento e gli stati sono salvati come codici italiani
// (es. 'contanti', 'ricevuto'): questi helper li mostrano nella lingua corrente.
const PAY = { contanti: 'Contanti', carta: 'Carta', pos_nfc: 'POS / NFC', bonifico: 'Bonifico', assegno: 'Assegno', altro: 'Altro', credito: 'A credito' }
export const payLabel = (id) => (PAY[id] ? $t(PAY[id]) : id)

const PO_STATUS = { bozza: 'Bozza', ordinato: 'Ordinato', ricevuto: 'Ricevuto', annullato: 'Annullato' }
const QUOTE_STATUS = { bozza: 'Bozza', inviato: 'Inviato', accettato: 'Accettato', rifiutato: 'Rifiutato', scaduto: 'Scaduto', convertito: 'Convertito' }
export const poStatusLabel = (s) => (PO_STATUS[s] ? $t(PO_STATUS[s]) : s)
export const quoteStatusLabel = (s) => (QUOTE_STATUS[s] ? $t(QUOTE_STATUS[s]) : s)
