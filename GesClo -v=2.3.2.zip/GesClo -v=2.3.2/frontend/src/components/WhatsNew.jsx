import React, { useEffect } from 'react'
import { $t } from '../i18n'

export default function WhatsNew({ entries, onClose }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  if (!entries?.length) return null

  return (
    <div
      role="dialog" aria-modal="true" aria-labelledby="whatsnew-title"
      style={{position:'fixed',inset:0,zIndex:10000,background:'rgba(0,0,0,0.55)',display:'flex',alignItems:'center',justifyContent:'center',padding:16}}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{width:'100%',maxWidth:480,maxHeight:'85vh',overflowY:'auto',background:'var(--bg2)',border:'0.5px solid var(--border)',borderRadius:16,padding:'22px 24px',boxShadow:'0 12px 40px rgba(0,0,0,0.35)'}}
      >
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
          <div style={{width:34,height:34,borderRadius:9,background:'var(--accent)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
            <i className="ti ti-sparkles" style={{color:'#fff',fontSize:18}} aria-hidden="true"></i>
          </div>
          <h2 id="whatsnew-title" style={{margin:0,fontSize:17,fontWeight:600,color:'var(--text)'}}>{$t("GesClo si è aggiornato")}</h2>
        </div>
        <p style={{fontSize:12,color:'var(--text3)',margin:'0 0 16px 44px'}}>{$t("Ecco cosa c'è di nuovo.")}</p>

        {entries.map((e, idx) => (
          <div key={e.version} style={{marginBottom: idx === entries.length - 1 ? 0 : 18}}>
            <div style={{display:'flex',alignItems:'baseline',gap:8,marginBottom:6}}>
              <span style={{fontSize:11,fontWeight:600,background:'var(--accent-bg)',color:'var(--accent-text)',borderRadius:20,padding:'2px 9px'}}>v{e.version}</span>
              <span style={{fontSize:14,fontWeight:600,color:'var(--text)'}}>{e.title}</span>
            </div>
            <ul style={{margin:0,paddingLeft:18,listStyle:'disc',fontSize:13,color:'var(--text2)',lineHeight:1.6}}>
              {e.items.map((it, i) => <li key={i} style={{marginBottom:3}}>{it}</li>)}
            </ul>
          </div>
        ))}

        <div style={{display:'flex',justifyContent:'flex-end',marginTop:20}}>
          <button
            onClick={onClose} autoFocus
            style={{background:'var(--accent)',border:'none',borderRadius:9,padding:'9px 22px',fontSize:13,color:'#fff',cursor:'pointer',fontWeight:500}}
          >{$t("Ho capito")}</button>
        </div>
      </div>
    </div>
  )
}
