import React, { useState, useEffect, useRef } from 'react'
import { Link, useLocation } from 'react-router-dom'
import AIStatus from './AIStatus'
import { getSystemResources } from '../services/apiService'
import { $t, LANG, setLang } from '../i18n'

const NAV = [
  { path: '/',          icon: 'ti-home',            label: 'Dashboard' },
  { path: '/scanner',   icon: 'ti-barcode',          label: 'Scanner'   },
  { path: '/stock',     icon: 'ti-box',              label: 'Stock'     },
  { path: '/sales',     icon: 'ti-shopping-cart',    label: 'Vendite'   },
  { path: '/purchases', icon: 'ti-truck-delivery',   label: 'Acquisti'  },
  { path: '/contacts',  icon: 'ti-address-book',     label: 'Anagrafiche' },
  { path: '/dues',      icon: 'ti-calendar-dollar',  label: 'Scadenzario' },
  { path: '/movements', icon: 'ti-arrows-exchange',  label: 'Movimenti' },
  { path: '/reports',   icon: 'ti-chart-bar',        label: 'Report'    },
  { path: '/ai',        icon: 'ti-sparkles',         label: 'AI'        },
]

function ResourceBar() {
  const [open, setOpen] = useState(false)
  const [res, setRes] = useState(null)
  const timerRef = useRef(null)

  useEffect(() => {
    if (!open) { clearInterval(timerRef.current); return }
    const fetchResources = () => getSystemResources().then(setRes).catch(() => {})
    fetchResources()
    timerRef.current = setInterval(fetchResources, 5000)
    return () => clearInterval(timerRef.current)
  }, [open])

  const cpu    = res ? `${res.cpu}%`     : '—'
  const ram    = res ? res.ramLabel      : '—'
  const cpuW   = res ? `${res.cpu}%`    : '0%'
  const ramW   = res ? `${res.ram}%`    : '0%'

  const metrics = [
    [$t("CPU"),   cpu,   cpuW,  '#534AB7'],
    [$t("RAM"),   ram,   ramW,  '#BA7517'],
    [$t("Disco"), res?.diskLabel || 'N/D', res?.disk != null ? `${res.disk}%` : '0%',  '#639922'],
    [$t("Temp"),  'N/D', '0%',  '#2176B5'],
    [$t("Rete"),  'N/D', '0%',  '#534AB7'],
  ]

  return (
    <div style={{ background: 'var(--bg2)', borderTop: '0.5px solid var(--border)' }}>
      <button onClick={() => setOpen(!open)} style={{ width: '100%', height: 34, display: 'flex', alignItems: 'center', padding: '0 16px', gap: 10, border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--text3)' }}>
        <i className="ti ti-cpu" style={{ fontSize: 14 }} aria-hidden="true"></i>
        <span style={{ flex: 1, textAlign: 'left', fontSize: 12 }}>{$t("Risorse dispositivo")}</span>
        <i className={`ti ${open ? 'ti-chevron-down' : 'ti-chevron-up'}`} style={{ fontSize: 13 }} aria-hidden="true"></i>
      </button>
      {open && (
        <div style={{ padding: '10px 16px 12px', display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 10 }}>
          {metrics.map(([l, v, w, c]) => (
            <div key={l}>
              <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>{l}</div>
              <div style={{ background: 'var(--bg3)', borderRadius: 4, height: 6, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: w, background: c, borderRadius: 4, transition: 'width 0.4s ease' }}></div>
              </div>
              <div style={{ fontSize: 12, marginTop: 3, color: c }}>{v}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function Layout({ children, user, dark, setDark, isAdmin, title, uiConfig = {}, onLogout }) {
  const location  = useLocation()
  const [collapsed, setCollapsed] = useState(false)

  const hiddenTabs   = new Set(uiConfig.hiddenTabs || [])
  const tabAliases   = uiConfig.tabAliases   || {}
  const businessName = uiConfig.businessName || 'GesClo'

  const visibleNav = NAV.filter(n => !hiddenTabs.has(n.label))

  return (
    <div style={{ display: 'flex', height: '100vh', background: 'var(--bg)' }}>
      {/* Sidebar */}
      <div style={{ width: collapsed ? 52 : 196, transition: 'width 0.2s', background: 'var(--bg2)', borderRight: '0.5px solid var(--border)', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
        <div style={{ height: 52, display: 'flex', alignItems: 'center', gap: 10, padding: collapsed ? '0 11px' : '0 14px', borderBottom: '0.5px solid var(--border)' }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <i className="ti ti-box" style={{ color: '#fff', fontSize: 16 }} aria-hidden="true"></i>
          </div>
          {!collapsed && <span style={{ fontWeight: 600, fontSize: 14, color: 'var(--text)' }}>{businessName}</span>}
        </div>

        <nav style={{ flex: 1, padding: '10px 6px', display: 'flex', flexDirection: 'column', gap: 2, overflowY: 'auto' }}>
          {visibleNav.map(n => (
            <Link key={n.path} to={n.path} title={collapsed ? (tabAliases[n.label] || $t(n.label)) : ''} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', borderRadius: 8,
              fontSize: 13, textDecoration: 'none', transition: 'background 0.15s',
              justifyContent: collapsed ? 'center' : 'flex-start',
              background: location.pathname === n.path ? 'var(--accent-bg)' : 'transparent',
              color: location.pathname === n.path ? 'var(--accent-text)' : 'var(--text2)',
            }}>
              <i className={`ti ${n.icon}`} style={{ fontSize: 18, flexShrink: 0 }} aria-hidden="true"></i>
              {!collapsed && <span>{tabAliases[n.label] || $t(n.label)}</span>}
            </Link>
          ))}
        </nav>

        <div style={{ padding: '8px 6px', borderTop: '0.5px solid var(--border)', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {isAdmin && !hiddenTabs.has('Admin') && (
            <Link to="/admin" title={collapsed ? (tabAliases['Admin'] || $t("Admin")) : ''} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', borderRadius: 8,
              fontSize: 13, textDecoration: 'none', justifyContent: collapsed ? 'center' : 'flex-start',
              background: location.pathname.startsWith('/admin') ? 'var(--accent-bg)' : 'transparent',
              color: location.pathname.startsWith('/admin') ? 'var(--accent-text)' : 'var(--text2)',
            }}>
              <i className="ti ti-shield" style={{ fontSize: 18, flexShrink: 0 }} aria-hidden="true"></i>
              {!collapsed && <span>{tabAliases['Admin'] || $t("Admin")}</span>}
            </Link>
          )}
          <button onClick={() => setDark(!dark)} title={collapsed ? (dark ? $t("Tema chiaro") : $t("Tema scuro")) : ''} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', borderRadius: 8, fontSize: 13, border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--text3)', justifyContent: collapsed ? 'center' : 'flex-start' }}>
            <i className={`ti ${dark ? 'ti-sun' : 'ti-moon'}`} style={{ fontSize: 18, flexShrink: 0 }} aria-hidden="true"></i>
            {!collapsed && <span>{dark ? $t("Tema chiaro") : $t("Tema scuro")}</span>}
          </button>
          <button onClick={() => setLang(LANG === 'it' ? 'en' : 'it')} title={LANG === 'it' ? 'Switch to English' : 'Passa all’italiano'} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', borderRadius: 8, fontSize: 13, border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--text3)', justifyContent: collapsed ? 'center' : 'flex-start' }}>
            <i className="ti ti-language" style={{ fontSize: 18, flexShrink: 0 }} aria-hidden="true"></i>
            {!collapsed && <span>{LANG === 'it' ? 'English' : 'Italiano'}</span>}
          </button>
          <button onClick={() => setCollapsed(!collapsed)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', borderRadius: 8, fontSize: 13, border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--text3)', justifyContent: collapsed ? 'center' : 'flex-start' }}>
            <i className={`ti ${collapsed ? 'ti-chevron-right' : 'ti-chevron-left'}`} style={{ fontSize: 16 }} aria-hidden="true"></i>
            {!collapsed && <span style={{ fontSize: 11 }}>{$t("Comprimi")}</span>}
          </button>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        <div style={{ height: 52, background: 'var(--bg2)', borderBottom: '0.5px solid var(--border)', display: 'flex', alignItems: 'center', padding: '0 16px', gap: 10, flexShrink: 0 }}>
          <span style={{ fontWeight: 500, fontSize: 14, color: 'var(--text)', flex: 1 }}>{title}</span>
          <AIStatus />
          <span style={{ fontSize: 12, color: 'var(--text2)' }}>{user?.username}</span>
          <button onClick={onLogout} title={$t("Esci")} style={{ width: 30, height: 30, borderRadius: 8, border: '0.5px solid var(--border)', background: 'transparent', cursor: 'pointer', color: 'var(--text3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <i className="ti ti-logout" style={{ fontSize: 15 }} aria-hidden="true"></i>
          </button>
        </div>
        <div style={{ flex: 1, overflow: 'auto', padding: 16 }}>{children}</div>
        <ResourceBar />
      </div>
    </div>
  )
}
