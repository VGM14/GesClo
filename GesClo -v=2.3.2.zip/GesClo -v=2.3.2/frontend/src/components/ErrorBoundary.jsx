import React from 'react'
import { $t } from '../i18n'

// Un errore di rendering in una pagina non deve lasciare l'utente davanti a uno schermo
// bianco: mostra un messaggio e permette di riprovare. Si azzera da solo cambiando pagina
// (resetKey).
export default class ErrorBoundary extends React.Component {
  state = { error: null }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    console.error('Errore in una pagina di GesClo:', error, info?.componentStack)
  }

  componentDidUpdate(prev) {
    if (this.state.error && prev.resetKey !== this.props.resetKey) this.setState({ error: null })
  }

  render() {
    if (!this.state.error) return this.props.children
    const btn = { borderRadius: 9, padding: '8px 18px', fontSize: 13, cursor: 'pointer', fontWeight: 500 }
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, background: 'var(--bg)' }}>
        <div style={{ maxWidth: 420, background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 16, padding: '24px 26px', textAlign: 'center' }}>
          <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)', marginBottom: 6 }}>{$t("Qualcosa è andato storto in questa pagina")}</div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6 }}>{$t("I tuoi dati non sono stati toccati.")}</div>
          <div style={{ fontSize: 11, fontFamily: 'monospace', color: 'var(--danger-text)', background: 'var(--danger-bg)', borderRadius: 8, padding: '6px 10px', marginBottom: 16, wordBreak: 'break-word' }}>
            {String(this.state.error?.message || this.state.error)}
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            <button onClick={() => window.location.reload()} style={{ ...btn, background: 'var(--accent)', border: 'none', color: '#fff' }}>{$t("Ricarica")}</button>
            <button onClick={() => { window.location.hash = '#/'; this.setState({ error: null }) }} style={{ ...btn, background: 'transparent', border: '0.5px solid var(--border)', color: 'var(--text)' }}>{$t("Torna alla dashboard")}</button>
          </div>
        </div>
      </div>
    )
  }
}
