import React, { useState, useEffect } from 'react'
import { getAIConfig } from '../services/apiService'
import { $t } from '../i18n'

export default function AIStatus() {
  const [status, setStatus] = useState({ available: false, reason: $t("AI non configurata") })

  useEffect(() => {
    check()
    const i = setInterval(check, 30000)
    return () => clearInterval(i)
  }, [])

  async function check() {
    try {
      const { provider, key, url } = await getAIConfig()
      if (provider === 'local' && url) {
        try {
          const r = await fetch(`${url}/api/tags`, { signal: AbortSignal.timeout(2000) })
          setStatus({ available: r.ok, reason: r.ok ? $t("AI locale") : $t("PC AI spento"), source: 'local' })
        } catch {
          setStatus({ available: false, reason: $t("PC AI non raggiungibile") })
        }
        return
      }
      if (key) setStatus({ available: true, reason: provider, source: 'cloud' })
      else      setStatus({ available: false, reason: $t("AI non configurata") })
    } catch {
      setStatus({ available: false, reason: $t("AI non configurata") })
    }
  }

  const bg = status.available ? (status.source === 'local' ? 'var(--warn-bg)' : 'var(--info-bg)') : 'var(--bg3)'
  const cl = status.available ? (status.source === 'local' ? 'var(--warn-text)' : 'var(--info-text)') : 'var(--text3)'
  return (
    <span style={{fontSize:11,padding:'2px 8px',borderRadius:20,background:bg,color:cl,display:'inline-flex',alignItems:'center',gap:4}}>
      <i className={`ti ${status.available?'ti-sparkles':'ti-sparkles-off'}`} style={{fontSize:11}} aria-hidden="true"></i>
      {status.reason}
    </span>
  )
}
