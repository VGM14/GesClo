import React, { useRef, useState } from 'react'
import { importRows } from '../services/apiService'
import { $t, sourcesOf } from '../i18n'

// ── CSV ──────────────────────────────────────────────────────
// Separatore ';' (come lo esporta Excel in italiano) e BOM UTF-8 così Excel apre subito
// il file con le lettere accentate corrette.
const SEP = ';'

const csvCell = (v) => {
  const s = v == null ? '' : String(v)
  return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

export function downloadCsv(filename, columns, rows) {
  const head = columns.map(c => csvCell(c.label)).join(SEP)
  const body = rows.map(r => columns.map(c => csvCell(typeof c.value === 'function' ? c.value(r) : r[c.key])).join(SEP))
  const blob = new Blob(['﻿' + [head, ...body].join('\r\n')], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename
  document.body.appendChild(a); a.click(); a.remove()
  URL.revokeObjectURL(url)
}

// Legge un CSV riconoscendo il separatore (; , o tab) e le celle tra virgolette.
export function parseCsv(text) {
  text = text.replace(/^﻿/, '')
  const firstLine = text.split(/\r?\n/, 1)[0] || ''
  const sep = [';', ',', '\t'].map(s => [s, firstLine.split(s).length]).sort((a, b) => b[1] - a[1])[0][0]
  const rows = []
  let row = [], cell = '', quoted = false
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]
    if (quoted) {
      if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++ } else quoted = false }
      else cell += ch
    } else if (ch === '"') quoted = true
    else if (ch === sep) { row.push(cell); cell = '' }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++
      row.push(cell); cell = ''
      if (row.some(c => c.trim() !== '')) rows.push(row)
      row = []
    } else cell += ch
  }
  row.push(cell)
  if (row.some(c => c.trim() !== '')) rows.push(row)
  return rows
}

// Confronto dei titoli di colonna ignorando maiuscole, accenti e simboli.
const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '')

const card = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 14, padding: 22 }
const btnGhost = { background: 'transparent', border: '0.5px solid var(--border)', borderRadius: 8, padding: '7px 12px', fontSize: 12, color: 'var(--text)', cursor: 'pointer' }

// Pulsanti "Esporta" / "Importa" con la finestra di anteprima e conferma dell'importazione.
// config: { kind, label, filename, columns: [{key, label, aliases?[], value?}], exportRows, onDone }
export default function CsvTools({ config }) {
  const fileRef = useRef(null)
  const [preview, setPreview] = useState(null) // { rows, unknown, fileName }
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')

  const exportNow = () => downloadCsv(config.filename, config.columns, config.exportRows())

  const template = () => downloadCsv(`modello-${config.filename}`, config.columns, [])

  const onFile = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setError(''); setResult(null)
    try {
      const table = parseCsv(await file.text())
      if (table.length < 2) throw new Error($t("Il file non contiene righe di dati (serve la riga dei titoli e almeno una riga)."))
      const headers = table[0].map(norm)
      const map = {}, used = new Set()
      for (const c of config.columns) {
        const names = [c.key, c.label, ...sourcesOf(c.label), ...(c.aliases || [])].map(norm)
        const idx = headers.findIndex((h, i) => !used.has(i) && names.includes(h))
        if (idx >= 0) { map[c.key] = idx; used.add(idx) }
      }
      if (map.name === undefined) throw new Error($t("Manca la colonna \"Nome\": controlla la riga dei titoli o scarica il modello."))
      const rows = table.slice(1).map(r => Object.fromEntries(Object.entries(map).map(([k, i]) => [k, (r[i] ?? '').trim()])))
      const unknown = table[0].filter((_, i) => !used.has(i) && table[0][i].trim())
      setPreview({ rows, unknown, fileName: file.name })
    } catch (err) { setError(err.message || String(err)) }
  }

  const doImport = async () => {
    setBusy(true); setError('')
    try {
      const res = await importRows(config.kind, preview.rows)
      setResult(res)
      config.onDone && config.onDone()
    } catch (err) { setError(err.message || String(err)) }
    setBusy(false)
  }

  const close = () => { setPreview(null); setResult(null); setError('') }
  const shown = preview ? preview.rows.slice(0, 6) : []
  const cols = config.columns.filter(c => preview && preview.rows.some(r => r[c.key] !== undefined))

  return (
    <>
      <button onClick={exportNow} style={btnGhost} title={$t("Scarica l'elenco in formato CSV (si apre con Excel)")}>
        <i className="ti ti-download" aria-hidden="true"></i>{" "}{$t("Esporta CSV")}</button>
      <button onClick={() => { setError(''); fileRef.current?.click() }} style={btnGhost} title={$t("Carica un file CSV")}>
        <i className="ti ti-upload" aria-hidden="true"></i>{" "}{$t("Importa CSV")}</button>
      <input ref={fileRef} type="file" accept=".csv,.txt,text/csv" onChange={onFile} style={{ display: 'none' }} />

      {(preview || (error && !preview)) && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 110, padding: 16 }}>
          <div style={{ ...card, width: 720, maxWidth: '100%', maxHeight: '90vh', overflow: 'auto' }}>
            <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--text)', marginBottom: 4 }}>{$t("Importa")}{" "}{config.label}</div>
            {preview && <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 12 }}>{preview.fileName} · {preview.rows.length}{" "}{$t("righe")}</div>}

            {error && <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 8, padding: '8px 10px', fontSize: 12, marginBottom: 12 }}>{error}</div>}

            {preview && !result && (
              <>
                <div style={{ fontSize: 12, color: 'var(--text2)', marginBottom: 8 }}>{$t("Anteprima delle prime righe.")}{" "}{config.importNote}
                  {preview.unknown.length > 0 && <div style={{ color: 'var(--warn-text)', marginTop: 4 }}>{$t("Colonne non riconosciute (ignorate):")}{" "}{preview.unknown.join(', ')}</div>}
                </div>
                <div style={{ overflowX: 'auto', border: '0.5px solid var(--border)', borderRadius: 8, marginBottom: 14 }}>
                  <table style={{ borderCollapse: 'collapse', width: '100%', fontSize: 12 }}>
                    <thead><tr>{cols.map(c => <th key={c.key} style={{ textAlign: 'left', padding: '6px 8px', color: 'var(--text3)', borderBottom: '0.5px solid var(--border)', whiteSpace: 'nowrap' }}>{c.label}</th>)}</tr></thead>
                    <tbody>{shown.map((r, i) => <tr key={i}>{cols.map(c => <td key={c.key} style={{ padding: '5px 8px', color: 'var(--text)', borderBottom: '0.5px solid var(--border)', whiteSpace: 'nowrap', maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[c.key]}</td>)}</tr>)}</tbody>
                  </table>
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between', flexWrap: 'wrap' }}>
                  <button onClick={template} style={{ ...btnGhost, fontSize: 11 }}>{$t("Scarica il modello")}</button>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={close} style={btnGhost}>{$t("Annulla")}</button>
                    <button onClick={doImport} disabled={busy} style={{ background: busy ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8, padding: '7px 18px', fontSize: 13, color: busy ? 'var(--text3)' : '#fff', cursor: busy ? 'default' : 'pointer', fontWeight: 500 }}>
                      {busy ? $t("Importazione...") : $t("Importa {0} righe", [preview.rows.length])}
                    </button>
                  </div>
                </div>
              </>
            )}

            {result && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 12 }}>
                  {[[$t("Creati"), result.created, 'var(--success-text)'], [$t("Aggiornati"), result.updated, 'var(--info-text)'], [$t("Invariati"), result.skipped, 'var(--text3)']].map(([l, v, c]) => (
                    <div key={l} style={{ border: '0.5px solid var(--border)', borderRadius: 10, padding: '10px 12px', textAlign: 'center' }}>
                      <div style={{ fontSize: 20, fontWeight: 600, color: c }}>{v}</div><div style={{ fontSize: 11, color: 'var(--text3)' }}>{l}</div>
                    </div>
                  ))}
                </div>
                {result.errors.length > 0 && (
                  <div style={{ background: 'var(--warn-bg)', color: 'var(--warn-text)', borderRadius: 8, padding: '8px 10px', fontSize: 12, marginBottom: 12, maxHeight: 160, overflow: 'auto' }}>
                    <b>{result.errors.length}{" "}{$t("righe non importate:")}</b>
                    {result.errors.slice(0, 50).map((e, i) => <div key={i}>{$t("Riga")}{" "}{e.row + 1}: {e.error}</div>)}
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button onClick={close} style={{ background: 'var(--accent)', border: 'none', borderRadius: 8, padding: '8px 22px', fontSize: 13, color: '#fff', cursor: 'pointer', fontWeight: 500 }}>{$t("Chiudi")}</button>
                </div>
              </>
            )}

            {!preview && error && (
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <button onClick={close} style={btnGhost}>{$t("Chiudi")}</button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}
