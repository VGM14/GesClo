import React, { useState, useMemo, useEffect } from 'react'
import { applyInventory } from '../services/apiService'
import { $t, LOCALE } from '../i18n'

const STORAGE_KEY = 'gesclo_inventory_counts'
const eur = (n) => Number(n || 0).toLocaleString(LOCALE, { style: 'currency', currency: 'EUR' })

const loadDraft = () => { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') } catch { return {} } }
const saveDraft = (d) => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(d)) } catch {} }

const card = { background: 'var(--bg2)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '14px 16px' }
const btnGhost = { background: 'transparent', border: '0.5px solid var(--border)', borderRadius: 8, padding: '6px 12px', fontSize: 12, color: 'var(--text)', cursor: 'pointer' }

// Conteggio fisico: si scrive la quantità contata accanto a ogni articolo e alla fine si applicano
// le rettifiche. La bozza del conteggio resta salvata sul dispositivo, così un inventario lungo
// può essere interrotto e ripreso (anche ricaricando la pagina).
export default function Inventory({ products, onApplied }) {
  const [counts, setCounts] = useState(loadDraft)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all') // all | diff | todo
  const [notes, setNotes] = useState('')
  const [applying, setApplying] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState(null)

  useEffect(() => { saveDraft(counts) }, [counts])

  const rows = useMemo(() => products.map(p => {
    const raw = counts[p.id]
    const counted = raw === undefined || raw === '' ? null : Number(raw)
    const valid = counted !== null && Number.isInteger(counted) && counted >= 0
    return { p, raw, counted: valid ? counted : null, invalid: counted !== null && !valid, diff: valid ? counted - (p.qty || 0) : null }
  }), [products, counts])

  const shown = rows.filter(r => {
    const q = search.trim().toLowerCase()
    if (q && !(r.p.name?.toLowerCase().includes(q) || (r.p.barcodes || [r.p.barcode]).some(b => b?.toLowerCase().includes(q)) || r.p.category?.toLowerCase().includes(q))) return false
    if (filter === 'diff') return r.diff !== null && r.diff !== 0
    if (filter === 'todo') return r.counted === null
    return true
  })

  const countedRows = rows.filter(r => r.counted !== null)
  const diffRows = countedRows.filter(r => r.diff !== 0)
  const invalidCount = rows.filter(r => r.invalid).length
  const valueDiff = diffRows.reduce((s, r) => s + (r.p.cost != null ? r.diff * r.p.cost : 0), 0)

  const setCount = (id, v) => setCounts(c => ({ ...c, [id]: v }))

  const apply = async () => {
    if (invalidCount) return setError($t("Ci sono quantità non valide: usa solo numeri interi da zero in su."))
    if (diffRows.length === 0) return setError($t("Nessuna differenza da applicare."))
    const list = diffRows.slice(0, 12).map(r => `• ${r.p.name}: ${r.p.qty || 0} → ${r.counted}`).join('\n')
    if (!window.confirm($t("Applicare {0} rettifiche di magazzino?\n\n{1}{2}\n\nLe giacenze verranno sostituite dai valori contati e ogni differenza sarà registrata nei Movimenti.", [diffRows.length, list, diffRows.length > 12 ? $t("\n… e altre {0}", [diffRows.length - 12]) : '']))) return
    setApplying(true); setError('')
    try {
      const res = await applyInventory(countedRows.map(r => ({ product_id: r.p.id, counted: r.counted })), notes)
      setResult(res)
      setCounts(c => { const n = { ...c }; countedRows.forEach(r => delete n[r.p.id]); return n })
      setNotes('')
      onApplied && onApplied()
    } catch (e) { setError(e?.message || String(e)) }
    setApplying(false)
  }

  const reset = () => {
    if (Object.keys(counts).length && !window.confirm($t("Cancellare tutti i conteggi inseriti finora?"))) return
    setCounts({}); setResult(null); setError('')
  }

  const chip = (id, text) => (
    <button key={id} onClick={() => setFilter(id)} style={{
      padding: '4px 12px', borderRadius: 20, fontSize: 11, cursor: 'pointer',
      border: `0.5px solid ${filter === id ? 'var(--accent)' : 'var(--border)'}`,
      background: filter === id ? 'var(--accent-bg)' : 'transparent',
      color: filter === id ? 'var(--accent-text)' : 'var(--text3)',
    }}>{text}</button>
  )

  return (
    <div style={card}>
      <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10, lineHeight: 1.5 }}>{$t("Conta i pezzi in magazzino e scrivi la quantità accanto a ogni articolo; lascia vuoto ciò che non hai contato. Poi applica le rettifiche: le giacenze si allineano al conteggio e ogni differenza finisce nei Movimenti.")}</div>

      {result && (
        <div style={{ background: 'var(--success-bg)', color: 'var(--success-text)', borderRadius: 10, padding: '10px 12px', fontSize: 12, marginBottom: 12 }}>
          <b>{$t("Inventario applicato:")}</b> {result.adjusted}{" "}{$t("articoli rettificati")}{result.unchanged ? $t(", {0} già corretti", [result.unchanged]) : ''}
          {result.adjusted > 0 && <>{" "}{$t("· differenza a costo")}{" "}<b>{eur(result.valueDiff)}</b></>}
          <button onClick={() => setResult(null)} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer', color: 'inherit' }}>×</button>
        </div>
      )}
      {error && <div style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', borderRadius: 10, padding: '8px 12px', marginBottom: 12, fontSize: 12 }}>{error} <button onClick={() => setError('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger-text)' }}>×</button></div>}

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder={$t("Cerca per nome, barcode o categoria...")} style={{ flex: 1, minWidth: 200 }} />
        {chip('all', $t("Tutti"))}{chip('todo', $t("Da contare"))}{chip('diff', $t("Con differenze"))}
      </div>

      <div style={{ display: 'flex', gap: 14, fontSize: 12, color: 'var(--text2)', marginBottom: 10, flexWrap: 'wrap' }}>
        <span>{$t("Contati:")}{" "}<b style={{ color: 'var(--text)' }}>{countedRows.length}</b> / {products.length}</span>
        <span>{$t("Con differenza:")}{" "}<b style={{ color: diffRows.length ? 'var(--warn-text)' : 'var(--text)' }}>{diffRows.length}</b></span>
        {diffRows.length > 0 && <span>{$t("Effetto a costo:")}{" "}<b style={{ color: valueDiff < 0 ? 'var(--danger-text)' : 'var(--success-text)' }}>{eur(valueDiff)}</b></span>}
      </div>

      {shown.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '30px 0', color: 'var(--text3)', fontSize: 13 }}>
          {products.length === 0 ? $t("Nessun articolo in magazzino") : $t("Nessun articolo con questo filtro")}
        </div>
      ) : (
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 90px 120px 90px', gap: 8, padding: '6px 8px', fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em', borderBottom: '0.5px solid var(--border)' }}>
            <span>{$t("Articolo")}</span><span style={{ textAlign: 'right' }}>{$t("A sistema")}</span><span>{$t("Contati")}</span><span style={{ textAlign: 'right' }}>{$t("Differenza")}</span>
          </div>
          {shown.map(({ p, raw, invalid, diff }) => (
            <div key={p.id} style={{ display: 'grid', gridTemplateColumns: '1fr 90px 120px 90px', gap: 8, padding: '7px 8px', borderBottom: '0.5px solid var(--border)', alignItems: 'center' }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, color: 'var(--text)', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)' }}>{[p.barcode && `#${p.barcode}`, p.category].filter(Boolean).join(' · ') || ' '}</div>
              </div>
              <div style={{ textAlign: 'right', fontSize: 13, color: 'var(--text2)' }}>{p.qty || 0} {p.unit}</div>
              <div style={{ display: 'flex', gap: 4 }}>
                <input type="number" min="0" step="1" value={raw ?? ''} onChange={e => setCount(p.id, e.target.value)} placeholder="—"
                  style={{ width: '100%', borderColor: invalid ? 'var(--danger-text)' : undefined }} />
                <button onClick={() => setCount(p.id, String(p.qty || 0))} title={$t("Conferma: contati uguali al sistema")} style={{ ...btnGhost, padding: '0 8px' }}>=</button>
              </div>
              <div style={{ textAlign: 'right', fontSize: 13, fontWeight: 600, color: diff === null ? 'var(--text3)' : diff === 0 ? 'var(--text3)' : diff > 0 ? 'var(--success-text)' : 'var(--danger-text)' }}>
                {diff === null ? '' : diff === 0 ? $t("ok") : (diff > 0 ? '+' : '') + diff}
              </div>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 14, flexWrap: 'wrap' }}>
        <input value={notes} onChange={e => setNotes(e.target.value)} placeholder={$t("Nota dell'inventario (facoltativa), es. Inventario di fine mese")} style={{ flex: 1, minWidth: 220 }} />
        <button onClick={reset} style={btnGhost}>{$t("Azzera conteggi")}</button>
        <button onClick={apply} disabled={applying || diffRows.length === 0} style={{ background: applying || diffRows.length === 0 ? 'var(--bg3)' : 'var(--accent)', border: 'none', borderRadius: 8, padding: '7px 16px', fontSize: 13, color: applying || diffRows.length === 0 ? 'var(--text3)' : '#fff', cursor: applying || diffRows.length === 0 ? 'default' : 'pointer', fontWeight: 500 }}>
          {applying ? $t("Applicazione...") : $t("Applica {0} rettifiche", [diffRows.length])}
        </button>
      </div>
    </div>
  )
}
