import React from 'react'

// Le sezioni sono accessibili a tutti gli utenti autenticati via Clerk.
// La protezione reale avviene sul backend tramite verifica del token.
export default function SectionLock({ children }) {
  return children
}
