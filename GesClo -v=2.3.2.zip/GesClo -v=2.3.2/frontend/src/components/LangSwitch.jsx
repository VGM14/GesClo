import React from 'react'
import { LANG, setLang } from '../i18n'

// Pulsante compatto IT/EN per le schermate senza sidebar (login, primo avvio).
// I nomi delle lingue non si traducono: ognuna si chiama nella propria lingua.
export default function LangSwitch() {
  const next = LANG === 'it' ? 'en' : 'it'
  return (
    <button
      onClick={() => setLang(next)}
      title={LANG === 'it' ? 'Switch to English' : 'Passa all’italiano'}
      style={{ height: 32, padding: '0 9px', borderRadius: 8, border: '0.5px solid var(--border)', background: 'transparent', cursor: 'pointer', color: 'var(--text3)', fontSize: 12, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}
    >
      <i className="ti ti-language" style={{ fontSize: 15 }} aria-hidden="true"></i>{next.toUpperCase()}
    </button>
  )
}
