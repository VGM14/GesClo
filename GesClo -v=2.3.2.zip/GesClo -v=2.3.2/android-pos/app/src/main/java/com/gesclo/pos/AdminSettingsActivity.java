package com.gesclo.pos;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AdminSettingsActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private EditText etPin, etPosName, etWallpaper;
    private TextView tvRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        setContentView(R.layout.activity_admin_settings);

        prefs = getSharedPreferences("gesclo_pos", MODE_PRIVATE);
        etPin      = findViewById(R.id.et_pos_pin);
        etPosName  = findViewById(R.id.et_pos_name);
        etWallpaper = findViewById(R.id.et_pos_wallpaper);
        tvRole     = findViewById(R.id.tv_admin_role);

        String role = prefs.getString("clerk_user_role", "Super Admin");
        tvRole.setText("Accesso: " + role);

        loadSettings();

        findViewById(R.id.btn_admin_save).setOnClickListener(v -> saveSettings());
        findViewById(R.id.btn_admin_back).setOnClickListener(v -> finish());
    }

    private void loadSettings() {
        String ip  = prefs.getString("server_ip", "");
        String key = prefs.getString("api_key", "");
        if (ip.isEmpty()) return;
        new AsyncTask<Void, Void, String>() {
            protected String doInBackground(Void... v) {
                try {
                    String u = "http://" + ip + ":3001/api/pos/config";
                    if (!key.isEmpty()) u += "?key=" + key;
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(3000); c.setReadTimeout(3000);
                    if (!key.isEmpty()) c.setRequestProperty("X-NFC-Key", key);
                    if (c.getResponseCode() != 200) return null;
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                        String line; while ((line = br.readLine()) != null) sb.append(line);
                    }
                    return sb.toString();
                } catch (Exception e) { return null; }
            }
            protected void onPostExecute(String json) {
                if (json == null) return;
                etPin.setText(extractJson(json, "pos_pin"));
                etPosName.setText(extractJson(json, "pos_name"));
                etWallpaper.setText(extractJson(json, "pos_wallpaper"));
            }
        }.execute();
    }

    private void saveSettings() {
        String ip    = prefs.getString("server_ip", "");
        String token = prefs.getString("clerk_token", "");
        if (ip.isEmpty() || token.isEmpty()) {
            Toast.makeText(this, "Sessione scaduta — fai di nuovo login", Toast.LENGTH_LONG).show();
            return;
        }
        String pin      = etPin.getText().toString().trim();
        String posName  = etPosName.getText().toString().trim();
        String wallpaper = etWallpaper.getText().toString().trim();

        new AsyncTask<Void, Void, Boolean>() {
            protected Boolean doInBackground(Void... v) {
                try {
                    boolean ok = postSetting(ip, token, "pos_pin",  pin)
                              && postSetting(ip, token, "pos_name", posName);
                    if (!wallpaper.isEmpty()) {
                        ok = ok && postWallpaper(ip, token, wallpaper);
                    }
                    return ok;
                } catch (Exception e) { return false; }
            }
            protected void onPostExecute(Boolean ok) {
                if (ok) {
                    Toast.makeText(AdminSettingsActivity.this,
                        "Impostazioni salvate", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(AdminSettingsActivity.this,
                        "Errore salvataggio — token scaduto?", Toast.LENGTH_LONG).show();
                }
            }
        }.execute();
    }

    private boolean postSetting(String ip, String token, String key, String value) throws Exception {
        HttpURLConnection c = (HttpURLConnection)
            new URL("http://" + ip + ":3001/api/settings").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(3000); c.setReadTimeout(3000);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setDoOutput(true);
        String body = "{\"key\":\"" + key + "\",\"value\":\"" + value + "\"}";
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        return c.getResponseCode() == 200;
    }

    private boolean postWallpaper(String ip, String token, String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection)
            new URL("http://" + ip + ":3001/api/pos/wallpaper").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(3000); c.setReadTimeout(3000);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setDoOutput(true);
        String body = "{\"wallpaper\":\"" + url + "\"}";
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        return c.getResponseCode() == 200;
    }

    private static String extractJson(String json, String key) {
        if (json == null) return "";
        String search = "\"" + key + "\":";
        int idx = json.indexOf(search);
        if (idx < 0) return "";
        int start = idx + search.length();
        if (start >= json.length()) return "";
        char c = json.charAt(start);
        if (c == '"') {
            int end = json.indexOf('"', start + 1);
            return end > start ? json.substring(start + 1, end) : "";
        }
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        return json.substring(start, end).trim();
    }
}
