package com.gesclo.pos;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LauncherActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private TextView tvConnDot, tvConnText;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean polling = false;
    private String lastHandledRequestId = null;
    private String serverPin = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();

        prefs = getSharedPreferences("gesclo_pos", MODE_PRIVATE);

        String ip = prefs.getString("server_ip", "");
        boolean loggedIn = prefs.getBoolean("logged_in", false);

        if (ip.isEmpty()) {
            startActivity(new Intent(this, SettingsActivity.class));
            finish();
            return;
        }

        if (!loggedIn) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_launcher);
        tvConnDot = findViewById(R.id.tv_conn_dot);
        tvConnText = findViewById(R.id.tv_conn_text);

        findViewById(R.id.btn_pos).setOnClickListener(v ->
            startActivity(new Intent(this, PosActivity.class)));

        findViewById(R.id.btn_nfc).setOnClickListener(v ->
            startActivity(new Intent(this, NfcReaderActivity.class)));

        findViewById(R.id.btn_settings).setOnClickListener(v -> showPinDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
        checkConnection();
        fetchPosConfig();
        polling = true;
        pollForPayment();
    }

    @Override
    protected void onPause() {
        super.onPause();
        polling = false;
    }

    private void showPinDialog() {
        if (serverPin.isEmpty()) {
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }

        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("PIN");

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
            .setTitle("Inserisci PIN")
            .setMessage("Inserisci il PIN per accedere alle impostazioni")
            .setView(input)
            .setPositiveButton("OK", (d, w) -> {
                if (input.getText().toString().equals(serverPin)) {
                    startActivity(new Intent(this, SettingsActivity.class));
                } else {
                    Toast.makeText(this, "PIN errato", Toast.LENGTH_SHORT).show();
                }
            })
            .setNeutralButton("Impostazioni Android", (d, w) -> {
                if (input.getText().toString().equals(serverPin)) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                } else {
                    Toast.makeText(this, "PIN errato", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Annulla", null)
            .show();
    }

    private void fetchPosConfig() {
        String ip = prefs.getString("server_ip", "");
        String key = prefs.getString("api_key", "");
        if (ip.isEmpty()) return;
        new AsyncTask<Void, Void, String>() {
            protected String doInBackground(Void... v) {
                try {
                    String u = "http://" + ip + ":3001/api/pos/config";
                    if (!key.isEmpty()) u += "?key=" + key;
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(2000);
                    c.setReadTimeout(2000);
                    if (!key.isEmpty()) c.setRequestProperty("X-NFC-Key", key);
                    if (c.getResponseCode() != 200) return null;
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                        String line; while ((line = br.readLine()) != null) sb.append(line);
                    }
                    return sb.toString();
                } catch (Exception e) { return null; }
            }
            protected void onPostExecute(String json) {
                if (json != null) {
                    String pin = extractJson(json, "pos_pin");
                    if (pin != null) serverPin = pin;
                    String wallpaper = extractJson(json, "pos_wallpaper");
                    if (wallpaper != null && !wallpaper.isEmpty()) {
                        loadWallpaper(wallpaper);
                    }
                }
            }
        }.execute();
    }

    private void pollForPayment() {
        if (!polling) return;
        String ip = prefs.getString("server_ip", "");
        if (!ip.isEmpty()) {
            new PollTask(ip, prefs.getString("api_key", "")).execute();
        }
        handler.postDelayed(this::pollForPayment, 2000);
    }

    private class PollTask extends AsyncTask<Void, Void, String[]> {
        private final String ip, key;
        PollTask(String ip, String key) { this.ip = ip; this.key = key; }

        protected String[] doInBackground(Void... v) {
            try {
                String u = "http://" + ip + ":3001/api/pos/pending";
                if (!key.isEmpty()) u += "?key=" + key;
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(2000);
                c.setReadTimeout(2000);
                if (!key.isEmpty()) c.setRequestProperty("X-NFC-Key", key);
                if (c.getResponseCode() != 200) return null;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) sb.append(line);
                }
                String json = sb.toString();
                if (json.contains("\"status\":\"pending\"")) {
                    String amount = extractJson(json, "amount");
                    String id = extractJson(json, "id");
                    if (amount != null && id != null) {
                        return new String[]{amount, id};
                    }
                }
            } catch (Exception ignored) {}
            return null;
        }

        protected void onPostExecute(String[] result) {
            if (result != null && polling) {
                String id = result[1];
                if (!id.equals(lastHandledRequestId)) {
                    lastHandledRequestId = id;
                    polling = false;
                    Intent intent = new Intent(LauncherActivity.this, PosActivity.class);
                    intent.putExtra("remote_amount", Double.parseDouble(result[0]));
                    startActivity(intent);
                }
            }
        }
    }

    private void checkConnection() {
        String ip = prefs.getString("server_ip", "");
        if (ip.isEmpty()) {
            tvConnDot.setBackgroundResource(R.drawable.dot_red);
            tvConnText.setText("  Non configurato");
            return;
        }
        new AsyncTask<Void, Void, Boolean>() {
            protected Boolean doInBackground(Void... v) {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL("http://" + ip + ":3001/health").openConnection();
                    c.setConnectTimeout(2000);
                    c.setReadTimeout(2000);
                    return c.getResponseCode() == 200;
                } catch (Exception e) { return false; }
            }
            protected void onPostExecute(Boolean ok) {
                tvConnDot.setBackgroundResource(ok ? R.drawable.dot_green : R.drawable.dot_red);
                tvConnText.setText(ok ? "  Connesso a GesClo" : "  Server non raggiungibile");
            }
        }.execute();
    }

    private void loadWallpaper(String url) {
        new AsyncTask<Void, Void, Bitmap>() {
            protected Bitmap doInBackground(Void... v) {
                try {
                    InputStream in = new URL(url).openStream();
                    return BitmapFactory.decodeStream(in);
                } catch (Exception e) { return null; }
            }
            protected void onPostExecute(Bitmap bmp) {
                if (bmp != null) {
                    ImageView bg = findViewById(R.id.iv_wallpaper);
                    View overlay = findViewById(R.id.wallpaper_overlay);
                    if (bg != null) {
                        bg.setImageBitmap(bmp);
                        bg.setVisibility(View.VISIBLE);
                        if (overlay != null) overlay.setVisibility(View.VISIBLE);
                    }
                }
            }
        }.execute();
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private static String extractJson(String json, String key) {
        String search = "\"" + key + "\":";
        int idx = json.indexOf(search);
        if (idx < 0) return null;
        int start = idx + search.length();
        if (start >= json.length()) return null;
        char c = json.charAt(start);
        if (c == '"') {
            int end = json.indexOf('"', start + 1);
            return end > start ? json.substring(start + 1, end) : null;
        }
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        return json.substring(start, end).trim();
    }
}
