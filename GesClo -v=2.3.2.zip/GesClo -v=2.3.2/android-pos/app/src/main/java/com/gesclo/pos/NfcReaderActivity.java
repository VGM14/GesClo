package com.gesclo.pos;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.MifareUltralight;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class NfcReaderActivity extends AppCompatActivity {

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private SharedPreferences prefs;

    private TextView tvReaderIcon, tvReaderStatus, tvReaderType, tvReaderUid, tvReaderProduct, tvReaderSend;
    private LinearLayout readerResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        setContentView(R.layout.activity_nfc_reader);

        prefs = getSharedPreferences("gesclo_pos", MODE_PRIVATE);

        tvReaderIcon = findViewById(R.id.tv_reader_icon);
        tvReaderStatus = findViewById(R.id.tv_reader_status);
        tvReaderType = findViewById(R.id.tv_reader_type);
        tvReaderUid = findViewById(R.id.tv_reader_uid);
        tvReaderProduct = findViewById(R.id.tv_reader_product);
        tvReaderSend = findViewById(R.id.tv_reader_send);
        readerResult = findViewById(R.id.reader_result);

        findViewById(R.id.btn_back_reader).setOnClickListener(v -> finish());

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            tvReaderStatus.setText("NFC NON DISPONIBILE");
            tvReaderStatus.setTextColor(0xFFFF3333);
            return;
        }

        Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = (Build.VERSION.SDK_INT >= 31) ? PendingIntent.FLAG_MUTABLE : 0;
        pendingIntent = PendingIntent.getActivity(this, 0, intent, flags);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null)
            nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null)
            nfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag == null) return;

        byte[] idBytes = tag.getId();
        String uid = bytesToHex(idBytes);

        // Fix UID tutto zeri: genera un ID dal contenuto del tag
        if (uid.matches("^0+$") || uid.isEmpty()) {
            uid = "AUTO" + Long.toHexString(System.currentTimeMillis()).toUpperCase();
        }

        // Determina il tipo di tag — solo prodotti, no carte
        String[] techs = tag.getTechList();
        String techName = "NFC";
        String source = "product_tag";
        String cardBrand = null;

        IsoDep isoDep = IsoDep.get(tag);
        if (isoDep != null) {
            tvReaderStatus.setText("QUESTA E' UNA CARTA, USA IL POS");
            tvReaderStatus.setTextColor(0xFFFF3333);
            tvReaderIcon.setText("✘");
            tvReaderIcon.setTextColor(0xFFFF3333);
            vibrate(300);
            tvReaderIcon.postDelayed(() -> {
                tvReaderIcon.setText("🏷");
                tvReaderIcon.setTextColor(0xFF0077FF);
                tvReaderStatus.setText("AVVICINA UN TAG PRODOTTO");
                tvReaderStatus.setTextColor(0xFF0077FF);
            }, 3000);
            return;
        }

        if (MifareClassic.get(tag) != null) {
            techName = "MIFARE Classic";
        } else if (MifareUltralight.get(tag) != null) {
            techName = "MIFARE Ultralight / NTAG";
        } else if (techs.length > 0) {
            techName = techs[0].replace("android.nfc.tech.", "");
        }

        // Mostra risultato
        tvReaderIcon.setText("✔");
        tvReaderIcon.setTextColor(0xFF00CC66);
        tvReaderStatus.setText("TAG RILEVATO");
        tvReaderStatus.setTextColor(0xFF00CC66);

        tvReaderType.setText("TAG PRODOTTO — " + techName);
        tvReaderUid.setText(uid);
        tvReaderProduct.setVisibility(View.GONE);
        readerResult.setVisibility(View.VISIBLE);

        vibrate(150);

        // Invia al server
        String serverIp = prefs.getString("server_ip", "");
        String apiKey = prefs.getString("api_key", "");
        if (!serverIp.isEmpty()) {
            tvReaderSend.setText("Invio al server...");
            new SendScanTask(serverIp, apiKey, uid, techName, source, cardBrand).execute();
        } else {
            tvReaderSend.setText("Server non configurato");
        }

        // Reset dopo 5 secondi
        tvReaderIcon.postDelayed(() -> {
            tvReaderIcon.setText("⦿");
            tvReaderIcon.setTextColor(0xFF0077FF);
            tvReaderStatus.setText("AVVICINA UN TAG NFC");
            tvReaderStatus.setTextColor(0xFF0077FF);
        }, 5000);
    }

    private class SendScanTask extends AsyncTask<Void, Void, String> {
        private final String ip, key, uid, type, source, brand;
        SendScanTask(String ip, String key, String uid, String type, String source, String brand) {
            this.ip = ip; this.key = key; this.uid = uid;
            this.type = type; this.source = source; this.brand = brand != null ? brand : "";
        }

        protected String doInBackground(Void... v) {
            try {
                String body = "{\"uid\":\"" + esc(uid) + "\",\"type\":\"" + esc(type)
                    + "\",\"source\":\"" + esc(source) + "\",\"cardBrand\":\"" + esc(brand)
                    + "\",\"key\":\"" + esc(key) + "\"}";
                HttpURLConnection c = (HttpURLConnection) new URL("http://" + ip + ":3001/api/nfc/scan").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("X-NFC-Key", key);
                c.setDoOutput(true);
                c.setConnectTimeout(4000);
                c.setReadTimeout(4000);
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                int code = c.getResponseCode();
                if (code != 200) return "ERR:" + code;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) sb.append(line);
                }
                return "OK:" + sb;
            } catch (Exception e) { return "ERR:" + e.getMessage(); }
        }

        protected void onPostExecute(String result) {
            if (result.startsWith("OK:")) {
                boolean found = result.contains("\"product\":{");
                if (found) {
                    tvReaderProduct.setText("Articolo trovato nel magazzino!");
                    tvReaderProduct.setVisibility(View.VISIBLE);
                }
                tvReaderSend.setText("Inviato al gestionale");
            } else {
                tvReaderSend.setText("Errore: " + result.substring(4));
            }
        }
    }

    @SuppressWarnings("deprecation")
    private void vibrate(long ms) {
        Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vib != null) vib.vibrate(ms);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02X", b));
        return sb.toString();
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
