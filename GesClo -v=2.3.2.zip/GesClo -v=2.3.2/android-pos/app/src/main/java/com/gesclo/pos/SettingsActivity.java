package com.gesclo.pos;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class SettingsActivity extends AppCompatActivity {

    private TextView tvPinStatus;
    private Button btnAdminSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        setContentView(R.layout.activity_settings);

        SharedPreferences prefs = getSharedPreferences("gesclo_pos", MODE_PRIVATE);
        EditText etIp = findViewById(R.id.et_server_ip);
        EditText etKey = findViewById(R.id.et_api_key);
        tvPinStatus = findViewById(R.id.tv_pin_status);
        btnAdminSettings = findViewById(R.id.btn_admin_settings_gestionale);
        btnAdminSettings.setVisibility(View.GONE);

        etIp.setText(prefs.getString("server_ip", ""));
        etKey.setText(prefs.getString("api_key", ""));

        findViewById(R.id.btn_save).setOnClickListener(v -> {
            String ip = etIp.getText().toString().trim();
            if (ip.isEmpty()) {
                Toast.makeText(this, "Inserisci l'IP del server", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit()
                .putString("server_ip", ip)
                .putString("api_key", etKey.getText().toString().trim())
                .apply();
            Toast.makeText(this, "Salvato", Toast.LENGTH_SHORT).show();
            finish();
        });

        findViewById(R.id.btn_android_settings).setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_SETTINGS)));

        TextView tvAccount = findViewById(R.id.tv_account);
        String userName = prefs.getString("clerk_user_name", "");
        String userEmail = prefs.getString("clerk_user_email", "");
        if (!userName.isEmpty() || !userEmail.isEmpty()) {
            tvAccount.setText("Account: " + userName + (userEmail.isEmpty() ? "" : " (" + userEmail + ")"));
        }

        findViewById(R.id.btn_logout).setOnClickListener(v -> {
            prefs.edit()
                .remove("clerk_user_id")
                .remove("clerk_user_name")
                .remove("clerk_user_email")
                .remove("clerk_token")
                .putBoolean("logged_in", false)
                .apply();
            Toast.makeText(this, "Logout effettuato", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        fetchPinStatus(prefs.getString("server_ip", ""), prefs.getString("api_key", ""));
        checkSuperAdmin(prefs);
    }

    private void checkSuperAdmin(SharedPreferences prefs) {
        String role = prefs.getString("clerk_user_role", "");
        if ("Super Admin".equals(role)) {
            btnAdminSettings.setVisibility(View.VISIBLE);
            btnAdminSettings.setOnClickListener(v ->
                startActivity(new Intent(this, AdminSettingsActivity.class)));
        }
    }

    private void fetchPinStatus(String ip, String key) {
        if (ip.isEmpty()) return;
        new AsyncTask<Void, Void, String>() {
            protected String doInBackground(Void... v) {
                try {
                    String u = "http://" + ip + ":3001/api/pos/config";
                    if (!key.isEmpty()) u += "?key=" + key;
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(2000);
                    c.setReadTimeout(2000);
                    if (!key.isEmpty()) c.setRequestProperty("X-NFC-Key", key);
                    if (c.getResponseCode() != 200) return null;
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                        String line; while ((line = br.readLine()) != null) sb.append(line);
                    }
                    return sb.toString();
                } catch (Exception e) { return null; }
            }
            protected void onPostExecute(String json) {
                if (json == null) {
                    tvPinStatus.setText("Server non raggiungibile");
                    tvPinStatus.setTextColor(0xFFFF4444);
                    return;
                }
                String pin = extractJson(json, "pos_pin");
                if (pin != null && !pin.isEmpty()) {
                    tvPinStatus.setText("PIN attivo (configurato dal gestionale)");
                    tvPinStatus.setTextColor(0xFF00CC66);
                } else {
                    tvPinStatus.setText("Nessun PIN — accesso libero");
                    tvPinStatus.setTextColor(0xFFFFAA00);
                }
            }
        }.execute();
    }

    private static String extractJson(String json, String key) {
        String search = "\"" + key + "\":";
        int idx = json.indexOf(search);
        if (idx < 0) return null;
        int start = idx + search.length();
        if (start >= json.length()) return null;
        char c = json.charAt(start);
        if (c == '"') {
            int end = json.indexOf('"', start + 1);
            return end > start ? json.substring(start + 1, end) : null;
        }
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        return json.substring(start, end).trim();
    }
}
