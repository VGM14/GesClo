package com.gesclo.pos;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private WebView webView;
    private View loadingOverlay;
    private SharedPreferences prefs;
    private boolean tokenCaptured = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        setContentView(R.layout.activity_login);

        prefs = getSharedPreferences("gesclo_pos", MODE_PRIVATE);
        loadingOverlay = findViewById(R.id.login_loading);
        webView = findViewById(R.id.webview_login);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.addJavascriptInterface(new ClerkBridge(), "GesCloPOS");
        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!tokenCaptured) {
                    view.postDelayed(() -> tryExtractSession(), 3000);
                }
            }
        });

        String serverIp = prefs.getString("server_ip", "");
        if (serverIp.isEmpty()) {
            Toast.makeText(this, "Configura prima l'IP del server", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        webView.loadUrl("http://" + serverIp + ":3000");
    }

    private void tryExtractSession() {
        if (tokenCaptured) return;
        String js = "(function() {" +
            "try {" +
            "  if (window.Clerk && window.Clerk.user) {" +
            "    var u = window.Clerk.user;" +
            "    var email = u.primaryEmailAddress ? u.primaryEmailAddress.emailAddress : '';" +
            "    var name = u.firstName || email;" +
            "    var id = u.id;" +
            "    var role = (u.publicMetadata && u.publicMetadata.role) ? u.publicMetadata.role : 'Operatore';" +
            "    window.Clerk.session.getToken().then(function(token) {" +
            "      GesCloPOS.onLogin(id, name, email, token, role);" +
            "    });" +
            "    return;" +
            "  }" +
            "} catch(e) {}" +
            "setTimeout(function() {" +
            "  GesCloPOS.onNotLoggedIn();" +
            "}, 1000);" +
            "})()";
        webView.evaluateJavascript(js, null);
    }

    private class ClerkBridge {
        @JavascriptInterface
        public void onLogin(String userId, String userName, String email, String token, String role) {
            tokenCaptured = true;
            prefs.edit()
                .putString("clerk_user_id", userId)
                .putString("clerk_user_name", userName)
                .putString("clerk_user_email", email)
                .putString("clerk_token", token)
                .putString("clerk_user_role", role)
                .putBoolean("logged_in", true)
                .apply();

            runOnUiThread(() -> {
                loadingOverlay.setVisibility(View.VISIBLE);
                Toast.makeText(LoginActivity.this,
                    "Accesso effettuato: " + userName, Toast.LENGTH_SHORT).show();

                webView.postDelayed(() -> {
                    startActivity(new Intent(LoginActivity.this, LauncherActivity.class));
                    finish();
                }, 1500);
            });
        }

        @JavascriptInterface
        public void onNotLoggedIn() {
            runOnUiThread(() -> tryExtractSession());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
