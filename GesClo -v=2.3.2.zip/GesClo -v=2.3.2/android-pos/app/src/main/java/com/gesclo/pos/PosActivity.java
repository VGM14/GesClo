package com.gesclo.pos;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class PosActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private NfcAdapter nfcAdapter;
    private PendingIntent nfcPendingIntent;
    private Handler handler = new Handler(Looper.getMainLooper());

    private View screenKeypad, screenNfc, screenResult;
    private TextView tvDisplay, tvRemoteBanner;
    private TextView tvNfcAmount, tvNfcIcon, tvNfcStatus, tvCardBrand, btnCancelNfc;
    private TextView tvResultIcon, tvResultText, tvResultBrand;
    private Button btnCharge;

    private StringBuilder amountDigits = new StringBuilder();
    private String serverIp, apiKey;
    private boolean polling = false;
    private double chargeAmount = 0;
    private String pendingRequestId = null;
    private String lastHandledRequestId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();
        setContentView(R.layout.activity_pos);

        prefs = getSharedPreferences("gesclo_pos", MODE_PRIVATE);
        serverIp = prefs.getString("server_ip", "");
        apiKey = prefs.getString("api_key", "");

        screenKeypad = findViewById(R.id.screen_keypad);
        screenNfc = findViewById(R.id.screen_nfc);
        screenResult = findViewById(R.id.screen_result);

        tvDisplay = findViewById(R.id.tv_display);
        tvRemoteBanner = findViewById(R.id.tv_remote_banner);
        btnCharge = findViewById(R.id.btn_charge);

        tvNfcAmount = findViewById(R.id.tv_nfc_amount);
        tvNfcIcon = findViewById(R.id.tv_nfc_icon);
        tvNfcStatus = findViewById(R.id.tv_nfc_status);
        tvCardBrand = findViewById(R.id.tv_card_brand);
        btnCancelNfc = findViewById(R.id.btn_cancel_nfc);

        tvResultIcon = findViewById(R.id.tv_result_icon);
        tvResultText = findViewById(R.id.tv_result_text);
        tvResultBrand = findViewById(R.id.tv_result_brand);

        setupKeypad();
        btnCharge.setOnClickListener(v -> startCharge());
        btnCancelNfc.setOnClickListener(v -> cancelPayment());

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter != null) {
            Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = (Build.VERSION.SDK_INT >= 31) ? PendingIntent.FLAG_MUTABLE : 0;
            nfcPendingIntent = PendingIntent.getActivity(this, 0, intent, flags);
        }

        showKeypad();

        double remoteAmount = getIntent().getDoubleExtra("remote_amount", 0);
        if (remoteAmount > 0) {
            chargeAmount = remoteAmount;
            long cents = Math.round(remoteAmount * 100);
            amountDigits.setLength(0);
            amountDigits.append(cents);
            updateDisplay();
            tvRemoteBanner.setText("Richiesta da GesClo");
            tvRemoteBanner.setVisibility(View.VISIBLE);
            pendingRequestId = "remote";
            lastHandledRequestId = null;
            showNfcScreen();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (nfcAdapter != null) nfcAdapter.enableForegroundDispatch(this, nfcPendingIntent, null, null);
        polling = true;
        pollServer();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) nfcAdapter.disableForegroundDispatch(this);
        polling = false;
    }

    // ── Tastierino ───────────────────────────────────────────────
    private void setupKeypad() {
        int[] ids = {R.id.k0, R.id.k1, R.id.k2, R.id.k3, R.id.k4,
                     R.id.k5, R.id.k6, R.id.k7, R.id.k8, R.id.k9};
        for (int i = 0; i < ids.length; i++) {
            final int digit = i;
            findViewById(ids[i]).setOnClickListener(v -> appendDigit(digit));
        }
        findViewById(R.id.kClear).setOnClickListener(v -> {
            amountDigits.setLength(0);
            updateDisplay();
        });
        findViewById(R.id.kBack).setOnClickListener(v -> {
            if (amountDigits.length() > 0)
                amountDigits.setLength(amountDigits.length() - 1);
            updateDisplay();
        });
    }

    private void appendDigit(int d) {
        if (amountDigits.length() >= 8) return;
        amountDigits.append(d);
        updateDisplay();
    }

    private void updateDisplay() {
        long cents = 0;
        if (amountDigits.length() > 0) {
            try { cents = Long.parseLong(amountDigits.toString()); } catch (NumberFormatException ignored) {}
        }
        tvDisplay.setText(String.format("%d,%02d", cents / 100, cents % 100));
    }

    private double getDisplayAmount() {
        long cents = 0;
        if (amountDigits.length() > 0) {
            try { cents = Long.parseLong(amountDigits.toString()); } catch (NumberFormatException ignored) {}
        }
        return cents / 100.0;
    }

    // ── Schermate ────────────────────────────────────────────────
    private void showKeypad() {
        screenKeypad.setVisibility(View.VISIBLE);
        screenNfc.setVisibility(View.GONE);
        screenResult.setVisibility(View.GONE);
        tvRemoteBanner.setVisibility(View.GONE);
        pendingRequestId = null;
    }

    private void startCharge() {
        chargeAmount = getDisplayAmount();
        if (chargeAmount <= 0) return;
        showNfcScreen();
    }

    private void showNfcScreen() {
        screenKeypad.setVisibility(View.GONE);
        screenNfc.setVisibility(View.VISIBLE);
        screenResult.setVisibility(View.GONE);
        tvNfcAmount.setText(String.format("€ %,.2f", chargeAmount));
        tvNfcIcon.setText("⦿");
        tvNfcIcon.setTextColor(0xFF0077FF);
        tvNfcStatus.setText("AVVICINA LA CARTA");
        tvNfcStatus.setTextColor(0xFF0077FF);
        tvCardBrand.setVisibility(View.GONE);
        btnCancelNfc.setVisibility(View.VISIBLE);
        vibrate(200);
    }

    private void cancelPayment() {
        if (pendingRequestId != null) {
            lastHandledRequestId = pendingRequestId;
            new CancelTask().execute();
        }
        amountDigits.setLength(0);
        updateDisplay();
        showKeypad();
    }

    private void showSuccess(String brand) {
        screenKeypad.setVisibility(View.GONE);
        screenNfc.setVisibility(View.GONE);
        screenResult.setVisibility(View.VISIBLE);
        tvResultIcon.setText("✔");
        tvResultIcon.setTextColor(0xFF00CC66);
        tvResultText.setText("APPROVATA");
        tvResultText.setTextColor(0xFF00CC66);
        tvResultBrand.setText(brand + "  •  € " + String.format("%,.2f", chargeAmount));
        tvResultBrand.setVisibility(View.VISIBLE);
        vibrate(100, 80, 100);

        lastHandledRequestId = pendingRequestId;
        handler.postDelayed(() -> {
            amountDigits.setLength(0);
            updateDisplay();
            showKeypad();
        }, 3500);
    }

    private void showError(String msg) {
        screenKeypad.setVisibility(View.GONE);
        screenNfc.setVisibility(View.GONE);
        screenResult.setVisibility(View.VISIBLE);
        tvResultIcon.setText("✘");
        tvResultIcon.setTextColor(0xFFFF3333);
        tvResultText.setText(msg);
        tvResultText.setTextColor(0xFFFF3333);
        tvResultBrand.setVisibility(View.GONE);
        vibrate(500);
        handler.postDelayed(this::showKeypad, 3000);
    }

    // ── Polling ──────────────────────────────────────────────────
    private void pollServer() {
        if (!polling || serverIp.isEmpty()) return;
        new PollTask().execute();
        handler.postDelayed(this::pollServer, 2000);
    }

    private class PollTask extends AsyncTask<Void, Void, String> {
        protected String doInBackground(Void... v) {
            try {
                String u = "http://" + serverIp + ":3001/api/pos/pending";
                if (!apiKey.isEmpty()) u += "?key=" + apiKey;
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(2000);
                c.setReadTimeout(2000);
                if (!apiKey.isEmpty()) c.setRequestProperty("X-NFC-Key", apiKey);
                if (c.getResponseCode() != 200) return null;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) sb.append(line);
                }
                return sb.toString();
            } catch (Exception e) { return null; }
        }

        protected void onPostExecute(String json) {
            if (json == null) return;
            if (json.contains("\"status\":\"pending\"") && screenKeypad.getVisibility() == View.VISIBLE) {
                String id = extractJson(json, "id");
                if (id != null && !id.equals(lastHandledRequestId)) {
                    String amount = extractJson(json, "amount");
                    if (amount != null) {
                        try {
                            chargeAmount = Double.parseDouble(amount);
                            pendingRequestId = id;
                            long cents = Math.round(chargeAmount * 100);
                            amountDigits.setLength(0);
                            amountDigits.append(cents);
                            updateDisplay();
                            tvRemoteBanner.setText("Richiesta da GesClo");
                            tvRemoteBanner.setVisibility(View.VISIBLE);
                            showNfcScreen();
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
        }
    }

    // ── Cancel al server ─────────────────────────────────────────
    private class CancelTask extends AsyncTask<Void, Void, Void> {
        protected Void doInBackground(Void... v) {
            try {
                String body = "{\"reason\":\"Annullato dall'operatore POS\",\"key\":\"" + esc(apiKey) + "\"}";
                HttpURLConnection c = (HttpURLConnection) new URL("http://" + serverIp + ":3001/api/pos/cancel").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("X-NFC-Key", apiKey);
                c.setDoOutput(true);
                c.setConnectTimeout(3000);
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                c.getResponseCode();
            } catch (Exception ignored) {}
            return null;
        }
    }

    // ── NFC ──────────────────────────────────────────────────────
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag == null) return;

        if (screenNfc.getVisibility() != View.VISIBLE) {
            vibrate(300);
            return;
        }

        tvNfcStatus.setText("LETTURA IN CORSO...");
        tvNfcStatus.setTextColor(0xFFFFAA00);
        btnCancelNfc.setVisibility(View.GONE);

        IsoDep isoDep = IsoDep.get(tag);
        if (isoDep != null) {
            new ReadCardTask(tag, isoDep).execute();
        } else {
            String uid = bytesToHex(tag.getId());
            if (uid.matches("^0+$")) uid = String.valueOf(System.currentTimeMillis());
            String brand = "Contactless";
            if (!serverIp.isEmpty()) {
                if (pendingRequestId != null) {
                    new ConfirmTask(uid, brand).execute();
                } else {
                    new RegisterSaleTask(uid, brand).execute();
                }
            }
            showSuccess(brand);
        }
    }

    private class ReadCardTask extends AsyncTask<Void, Void, String[]> {
        private final Tag tag;
        private final IsoDep isoDep;
        ReadCardTask(Tag tag, IsoDep isoDep) { this.tag = tag; this.isoDep = isoDep; }

        protected String[] doInBackground(Void... v) {
            String uid = bytesToHex(tag.getId());
            if (uid.matches("^0+$")) uid = String.valueOf(System.currentTimeMillis());
            String brand = "Contactless";
            String error = null;
            try {
                isoDep.connect();
                isoDep.setTimeout(3000);
                byte[] resp = isoDep.transceive(new byte[]{
                    0x00, (byte)0xA4, 0x04, 0x00, 0x0E,
                    '2','P','A','Y','.','S','Y','S','.','D','D','F','0','1', 0x00
                });
                String hex = bytesToHex(resp).toUpperCase();
                if (hex.endsWith("9000")) {
                    brand = detectBrand(hex);
                }
            } catch (Exception e) {
                error = e.getMessage();
            } finally {
                try { isoDep.close(); } catch (Exception ignored) {}
            }
            return new String[]{uid, brand, error};
        }

        protected void onPostExecute(String[] res) {
            String uid = res[0], brand = res[1];
            if (!serverIp.isEmpty()) {
                if (pendingRequestId != null) {
                    new ConfirmTask(uid, brand).execute();
                } else {
                    new RegisterSaleTask(uid, brand).execute();
                }
            }
            showSuccess(brand);
        }

        private String detectBrand(String hex) {
            if (hex.contains("A0000000031010")) return "Visa";
            if (hex.contains("A0000000032010")) return "Visa Electron";
            if (hex.contains("A0000000033010")) return "V Pay";
            if (hex.contains("A0000000041010")) return "Mastercard";
            if (hex.contains("A0000000043060")) return "Maestro";
            if (hex.contains("A000000025010801")) return "AmEx";
            if (hex.contains("A000000141010201")) return "PagoBANCOMAT";
            if (hex.contains("A000000141")) return "Bancomat";
            return "Contactless";
        }
    }

    private class ConfirmTask extends AsyncTask<Void, Void, Void> {
        private final String uid, brand;
        ConfirmTask(String uid, String brand) { this.uid = uid; this.brand = brand; }
        protected Void doInBackground(Void... v) {
            try {
                String body = "{\"uid\":\"" + esc(uid) + "\",\"cardBrand\":\"" + esc(brand)
                    + "\",\"requestId\":\"" + esc(pendingRequestId) + "\",\"key\":\"" + esc(apiKey) + "\"}";
                HttpURLConnection c = (HttpURLConnection) new URL("http://" + serverIp + ":3001/api/pos/confirm").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("X-NFC-Key", apiKey);
                c.setDoOutput(true);
                c.setConnectTimeout(4000);
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                c.getResponseCode();
            } catch (Exception ignored) {}
            return null;
        }
    }

    private class RegisterSaleTask extends AsyncTask<Void, Void, Void> {
        private final String uid, brand;
        RegisterSaleTask(String uid, String brand) { this.uid = uid; this.brand = brand; }
        protected Void doInBackground(Void... v) {
            try {
                String body = "{\"amount\":" + chargeAmount
                    + ",\"cardBrand\":\"" + esc(brand) + "\""
                    + ",\"cardUid\":\"" + esc(uid) + "\""
                    + ",\"key\":\"" + esc(apiKey) + "\"}";
                HttpURLConnection c = (HttpURLConnection) new URL("http://" + serverIp + ":3001/api/pos/sale").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("X-NFC-Key", apiKey);
                c.setDoOutput(true);
                c.setConnectTimeout(4000);
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                c.getResponseCode();
            } catch (Exception ignored) {}
            return null;
        }
    }

    // ── Utils ─────────────────────────────────────────────────────
    @SuppressWarnings("deprecation")
    private void vibrate(long... pattern) {
        Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vib == null) return;
        if (pattern.length == 1) { vib.vibrate(pattern[0]); return; }
        long[] p = new long[pattern.length * 2];
        for (int i = 0; i < pattern.length; i++) { p[i*2] = i == 0 ? 0 : pattern[i]; p[i*2+1] = pattern[i]; }
        vib.vibrate(p, -1);
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02X", b));
        return sb.toString();
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String extractJson(String json, String key) {
        String search = "\"" + key + "\":";
        int idx = json.indexOf(search);
        if (idx < 0) return null;
        int start = idx + search.length();
        if (start >= json.length()) return null;
        char c = json.charAt(start);
        if (c == '"') {
            int end = json.indexOf('"', start + 1);
            return end > start ? json.substring(start + 1, end) : null;
        }
        int end = start;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        return json.substring(start, end).trim();
    }
}
