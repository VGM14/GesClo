namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/Reports.jsx — vuota anche nella webapp.
public class ReportsPage : UserControl
{
    public ReportsPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        var card = new CardPanel { Dock = DockStyle.Fill };
        var lbl = new Label { Text = "Nessun report disponibile", ForeColor = Theme.Text3, Font = Theme.FontRegular, AutoSize = true };
        card.Controls.Add(lbl);
        card.Resize += (_, _) => lbl.Location = new Point((card.Width - lbl.Width) / 2, (card.Height - lbl.Height) / 2);
        Controls.Add(card);
    }
}
