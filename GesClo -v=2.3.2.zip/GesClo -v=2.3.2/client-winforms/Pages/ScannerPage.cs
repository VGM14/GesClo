using GesClo.Client.Api;
using GesClo.Client.Controls;

namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/Scanner.jsx — solo modalità tastiera/scanner USB-BT
// (la fotocamera e l'NFC live della webapp dipendono da API browser-specifiche).
public class ScannerPage : UserControl
{
    private readonly RoundedTextBox _code = new();
    private readonly Label _error = new();
    private readonly CardPanel _resultCard = new() { Visible = false };
    private Product? _result;

    public ScannerPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;
        AutoScroll = true;

        var wrap = new Panel { Width = 560, Location = new Point(0, 0), Height = 500, Anchor = AnchorStyles.Top | AnchorStyles.Left };

        var note = new Label
        {
            Text = "Modalità tastiera / scanner USB-BT — inquadra o digita il codice.\nFotocamera e NFC live non ancora disponibili in questo client.",
            ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, 0)
        };
        wrap.Controls.Add(note);

        _error.ForeColor = Theme.DangerTxt;
        _error.BackColor = Theme.DangerBg;
        _error.Location = new Point(0, 34);
        _error.Visible = false;
        wrap.Controls.Add(_error);

        var scanCard = new CardPanel { Location = new Point(0, 34), Size = new Size(560, 90) };
        var scanLabel = new Label { Text = "SCANSIONA O DIGITA CODICE", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(16, 14) };
        _code.Location = new Point(16, 40);
        _code.Size = new Size(420, 32);
        _code.Inner.KeyDown += async (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await SearchAsync(); } };
        var searchBtn = RoundedButton.Primary("Cerca");
        searchBtn.Location = new Point(446, 40);
        searchBtn.Size = new Size(98, 32);
        searchBtn.Click += async (_, _) => await SearchAsync();
        scanCard.Controls.Add(scanLabel);
        scanCard.Controls.Add(_code);
        scanCard.Controls.Add(searchBtn);
        wrap.Controls.Add(scanCard);

        _resultCard.Location = new Point(0, 140);
        _resultCard.Size = new Size(560, 260);
        wrap.Controls.Add(_resultCard);

        Controls.Add(wrap);
        _code.Inner.Focus();
    }

    private async Task SearchAsync()
    {
        var code = _code.Text.Trim();
        if (code.Length == 0) return;
        _error.Visible = false;
        try
        {
            _result = await ApiClient.FindByBarcodeAsync(code);
            ShowResult(_result);
        }
        catch (ApiException ex)
        {
            _resultCard.Visible = false;
            _error.Text = ex.Message.Contains("non trovato") ? $"Nessun articolo con codice \"{code}\"" : ex.Message;
            _error.Size = new Size(560, 28);
            _error.Visible = true;
        }
    }

    private void ShowResult(Product p)
    {
        _resultCard.Controls.Clear();
        _resultCard.Visible = true;

        var title = new Label { Text = "ARTICOLO TROVATO", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(16, 14) };
        _resultCard.Controls.Add(title);

        var rows = new (string, string)[]
        {
            ("Codice", p.Barcode ?? _code.Text),
            ("Nome", p.Name),
            ("Categoria", p.Category ?? "—"),
            ("Quantità", $"{p.Qty} {p.Unit}"),
            ("Prezzo", p.Price != null ? $"€{p.Price:0.00}" : "—"),
        };
        int y = 44;
        foreach (var (l, v) in rows)
        {
            var lbl = new Label { Text = l, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(16, y) };
            var val = new Label { Text = v, ForeColor = Theme.Text, Font = Theme.FontMedium, AutoSize = true, Location = new Point(300, y) };
            var line = new Panel { Location = new Point(16, y + 22), Size = new Size(528, 1), BackColor = Theme.Border };
            _resultCard.Controls.Add(lbl);
            _resultCard.Controls.Add(val);
            _resultCard.Controls.Add(line);
            y += 32;
        }

        var newScanBtn = RoundedButton.Ghost("Nuova scansione");
        newScanBtn.Location = new Point(16, y + 10);
        newScanBtn.Size = new Size(160, 34);
        newScanBtn.Click += (_, _) => Reset();
        _resultCard.Controls.Add(newScanBtn);

        var movBtn = RoundedButton.Primary("Registra movimento");
        movBtn.Location = new Point(184, y + 10);
        movBtn.Size = new Size(360, 34);
        movBtn.Click += async (_, _) => await RegisterMovementAsync();
        _resultCard.Controls.Add(movBtn);
    }

    private void Reset()
    {
        _result = null;
        _resultCard.Visible = false;
        _code.Text = "";
        _error.Visible = false;
        _code.Inner.Focus();
    }

    private async Task RegisterMovementAsync()
    {
        if (_result == null) return;
        using var dlg = new MovementDialog(new List<Product> { _result });
        if (dlg.ShowDialog(FindForm()) == DialogResult.OK)
            Reset();
    }
}
