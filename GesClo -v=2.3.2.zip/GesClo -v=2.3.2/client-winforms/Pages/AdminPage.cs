using GesClo.Client.Api;
using GesClo.Client.Controls;

namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/Admin.jsx — sotto-tab Dashboard, Utenti, Cassa.
// AI Setup, Log, Sistema, Hardware non ancora portate (segnaposto).
public class AdminPage : UserControl
{
    private static readonly string[] SubTabs = { "Dashboard", "Utenti", "Cassa", "AI Setup", "Log", "Sistema", "Hardware" };
    private readonly Panel _tabBar = new() { Dock = DockStyle.Top, Height = 40 };
    private readonly Panel _body = new() { Dock = DockStyle.Fill };
    private string _tab = "Dashboard";

    private List<UserAccount> _users = new();

    public AdminPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        int x = 0;
        foreach (var t in SubTabs)
        {
            var btn = RoundedButton.Ghost(t);
            btn.Size = new Size(t.Length * 7 + 32, 30);
            btn.Location = new Point(x, 0);
            btn.Click += (_, _) => { _tab = t; RenderTab(); };
            _tabBar.Controls.Add(btn);
            x += btn.Width + 6;
        }

        var wrapper = new Panel { Dock = DockStyle.Fill };
        wrapper.Controls.Add(_body);
        wrapper.Controls.Add(_tabBar);
        Controls.Add(wrapper);

        Load += (_, _) => RenderTab();
    }

    private void RenderTab()
    {
        foreach (Control c in _tabBar.Controls)
            if (c is RoundedButton b)
            {
                var active = b.Text == _tab;
                b.BackColor = active ? Theme.AccentBg : Theme.Bg2;
                b.ForeColor = active ? Theme.AccentText : Theme.Text3;
                b.BorderColor = active ? Theme.Accent : Theme.Border;
            }

        _body.Controls.Clear();
        switch (_tab)
        {
            case "Dashboard": _ = BuildDashboardAsync(); break;
            case "Utenti": _ = BuildUtentiAsync(); break;
            case "Cassa": _ = BuildCassaAsync(); break;
            default: BuildPlaceholder(_tab); break;
        }
    }

    private void BuildPlaceholder(string name)
    {
        var card = new CardPanel { Dock = DockStyle.Fill };
        var lbl = new Label { Text = $"{name} — non ancora disponibile in questo client", ForeColor = Theme.Text3, AutoSize = true };
        card.Controls.Add(lbl);
        card.Resize += (_, _) => lbl.Location = new Point((card.Width - lbl.Width) / 2, (card.Height - lbl.Height) / 2);
        _body.Controls.Add(card);
    }

    // ── DASHBOARD ──────────────────────────────────────────────
    private async Task BuildDashboardAsync()
    {
        var grid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1 };
        for (int i = 0; i < 3; i++) grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3f));
        _body.Controls.Add(grid);

        var serverCard = new CardPanel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 6, 0), Padding = new Padding(14) };
        var invCard = new CardPanel { Dock = DockStyle.Fill, Margin = new Padding(6, 0, 6, 0), Padding = new Padding(14) };
        var movCard = new CardPanel { Dock = DockStyle.Fill, Margin = new Padding(6, 0, 0, 0), Padding = new Padding(14) };
        grid.Controls.Add(serverCard, 0, 0);
        grid.Controls.Add(invCard, 1, 0);
        grid.Controls.Add(movCard, 2, 0);

        AddInfoRows(serverCard, "STATO SERVER", new[] { ("API Server", "...", Theme.Text3) });

        Stats stats;
        HealthResponse? health;
        try
        {
            stats = await ApiClient.GetStatsAsync();
            health = await ApiClient.GetHealthAsync();
            _users = await ApiClient.GetUsersAsync();
        }
        catch (ApiException ex)
        {
            AddInfoRows(serverCard, "STATO SERVER", new[] { ("Errore", ex.Message, Theme.DangerTxt) });
            return;
        }

        serverCard.Controls.Clear();
        AddInfoRows(serverCard, "STATO SERVER", new[]
        {
            ("API Server", health != null ? "Online" : "Offline", health != null ? Theme.SuccessTxt : Theme.DangerTxt),
            ("Database", health != null ? $"OK ({health.Db?.Products ?? 0} art.)" : "N/D", health != null ? Theme.SuccessTxt : Theme.Text3),
            ("Uptime", health != null ? $"{health.Uptime}s" : "—", Theme.AccentText),
        });

        AddInfoRows(invCard, "INVENTARIO", new[]
        {
            ("Articoli totali", stats.TotalProducts.ToString(), Theme.AccentText),
            ("Stock basso", stats.LowStock.ToString(), Theme.WarnTxt),
            ("Esauriti", stats.OutOfStock.ToString(), Theme.DangerTxt),
        });

        AddInfoRows(movCard, "MOVIMENTI", new[]
        {
            ("Oggi", stats.TodayMovements.ToString(), Theme.SuccessTxt),
            ("Utenti", _users.Count.ToString(), Theme.AccentText),
        });
    }

    private static void AddInfoRows(CardPanel card, string title, (string label, string value, Color color)[] rows)
    {
        card.Controls.Clear();
        var titleLbl = new Label { Text = title, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, 0) };
        card.Controls.Add(titleLbl);
        int y = 26;
        foreach (var (label, value, color) in rows)
        {
            var l = new Label { Text = label, ForeColor = Theme.Text, Font = Theme.FontRegular, AutoSize = true, Location = new Point(0, y) };
            var pill = Widgets.Pill(value, Theme.Bg3, color);
            pill.Location = new Point(200, y - 3);
            card.Controls.Add(l);
            card.Controls.Add(pill);
            var line = new Panel { Location = new Point(0, y + 22), Size = new Size(280, 1), BackColor = Theme.Border };
            card.Controls.Add(line);
            y += 32;
        }
    }

    // ── UTENTI ─────────────────────────────────────────────────
    private async Task BuildUtentiAsync()
    {
        var card = new CardPanel { Dock = DockStyle.Fill, Padding = new Padding(16) };
        _body.Controls.Add(card);

        var header = new Panel { Dock = DockStyle.Top, Height = 40 };
        var search = new RoundedTextBox { Location = new Point(0, 0), Size = new Size(300, 32) };
        var addBtn = RoundedButton.Primary("+ Nuovo utente");
        addBtn.Size = new Size(150, 32);
        addBtn.Click += async (_, _) => await OpenUserDialogAsync(null);
        header.Controls.Add(search);
        header.Controls.Add(addBtn);
        header.Resize += (_, _) => addBtn.Location = new Point(header.Width - addBtn.Width, 0);

        var list = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Margin = new Padding(0, 12, 0, 0) };

        card.Controls.Add(list);
        card.Controls.Add(header);

        async Task RefreshAsync()
        {
            try { _users = await ApiClient.GetUsersAsync(); }
            catch (ApiException ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            RenderUserList(list, search.Text, RefreshAsync);
        }

        search.Inner.TextChanged += (_, _) => RenderUserList(list, search.Text, RefreshAsync);
        addBtn.Click += async (_, _) => { if (await OpenUserDialogAsync(null)) await RefreshAsync(); };

        await RefreshAsync();
    }

    private void RenderUserList(FlowLayoutPanel list, string search, Func<Task> refresh)
    {
        list.Controls.Clear();
        var filtered = _users.Where(u => u.Username.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
        if (filtered.Count == 0)
        {
            list.Controls.Add(new Label { Text = _users.Count == 0 ? "Nessun utente" : "Nessun risultato", ForeColor = Theme.Text3, AutoSize = true });
            return;
        }
        foreach (var u in filtered)
        {
            var row = new Panel { Width = 760, Height = 40 };
            var avatar = new Panel { Size = new Size(32, 32), Location = new Point(0, 4), BackColor = Theme.AccentBg };
            Theme.ApplyRoundedRegion(avatar, 16);
            var initial = new Label { Text = u.Username.Length > 0 ? u.Username[0].ToString().ToUpper() : "U", ForeColor = Theme.AccentText, Font = Theme.FontMedium, AutoSize = true, Location = new Point(10, 8) };
            avatar.Controls.Add(initial);
            var name = new Label { Text = u.Username, ForeColor = Theme.Text, Font = Theme.FontMedium, AutoSize = true, Location = new Point(44, 4) };
            var email = new Label { Text = u.Email ?? "", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(44, 20) };
            var rolePill = Widgets.Pill(u.Role, RoleColor(u.Role).bg, RoleColor(u.Role).fg);
            rolePill.Location = new Point(300, 10);
            var editBtn = RoundedButton.Ghost("Modifica");
            editBtn.Size = new Size(80, 26);
            editBtn.Location = new Point(450, 7);
            editBtn.Click += async (_, _) => { if (await OpenUserDialogAsync(u)) await refresh(); };
            var delBtn = RoundedButton.Ghost("Elimina");
            delBtn.Size = new Size(80, 26);
            delBtn.Location = new Point(538, 7);
            delBtn.ForeColor = Theme.DangerTxt;
            delBtn.BorderColor = Theme.DangerTxt;
            delBtn.Click += async (_, _) =>
            {
                if (MessageBox.Show($"Eliminare l'utente \"{u.Username}\"? L'azione è irreversibile.", "Conferma", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                try { await ApiClient.DeleteUserAsync(u.Id); await refresh(); }
                catch (ApiException ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            row.Controls.Add(avatar); row.Controls.Add(name); row.Controls.Add(email); row.Controls.Add(rolePill); row.Controls.Add(editBtn); row.Controls.Add(delBtn);
            var line = new Panel { Height = 1, Dock = DockStyle.Bottom, BackColor = Theme.Border };
            row.Controls.Add(line);
            list.Controls.Add(row);
        }
    }

    private static (Color bg, Color fg) RoleColor(string role)
    {
        var r = role.ToLowerInvariant();
        if (r.Contains("super")) return (Theme.AccentBg, Theme.AccentText);
        if (r.Contains("admin")) return (Theme.Bg3, Theme.AccentText);
        if (r.Contains("manager")) return (Theme.WarnBg, Theme.WarnTxt);
        if (r.Contains("operator") || r.Contains("operatore")) return (Theme.SuccessBg, Theme.SuccessTxt);
        return (Theme.Bg3, Theme.Text3);
    }

    private async Task<bool> OpenUserDialogAsync(UserAccount? existing)
    {
        using var dlg = new UserDialog(existing);
        return dlg.ShowDialog(FindForm()) == DialogResult.OK;
    }

    // ── CASSA ──────────────────────────────────────────────────
    private async Task BuildCassaAsync()
    {
        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        _body.Controls.Add(scroll);

        CashRegister cr;
        try { cr = await ApiClient.GetCashRegisterAsync(); }
        catch (ApiException ex) { scroll.Controls.Add(new Label { Text = ex.Message, ForeColor = Theme.DangerTxt, AutoSize = true }); return; }

        var card = new CardPanel { Location = new Point(0, 0), Size = new Size(560, 420), Padding = new Padding(16) };
        scroll.Controls.Add(card);

        var title = new Label { Text = "INTESTAZIONE DOCUMENTI", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, 0) };
        card.Controls.Add(title);

        var name = new RoundedTextBox { Text = cr.Name ?? "" };
        var address = new RoundedTextBox { Text = cr.Address ?? "" };
        var vat = new RoundedTextBox { Text = cr.VatNumber ?? "" };
        var header = new RoundedTextBox { Text = cr.HeaderText ?? "" };
        var footer = new RoundedTextBox { Text = cr.FooterText ?? "" };

        int y = 26;
        y = Widgets.LabeledField(card, "Nome azienda / punto vendita", name, 0, y, 500);
        y = Widgets.LabeledField(card, "Indirizzo", address, 0, y, 500);
        y = Widgets.LabeledField(card, "P.IVA / C.F.", vat, 0, y, 500);
        y = Widgets.LabeledField(card, "Testo header scontrino", header, 0, y, 500);
        y = Widgets.LabeledField(card, "Testo footer scontrino", footer, 0, y, 500);

        var saveBtn = RoundedButton.Primary("Salva impostazioni");
        saveBtn.Location = new Point(0, y);
        saveBtn.Size = new Size(500, 36);
        var savedLbl = new Label { ForeColor = Theme.SuccessTxt, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, y + 44), Visible = false };
        saveBtn.Click += async (_, _) =>
        {
            saveBtn.Enabled = false;
            try
            {
                await ApiClient.UpdateCashRegisterAsync(new { name = name.Text, address = address.Text, vat_number = vat.Text, header_text = header.Text, footer_text = footer.Text });
                savedLbl.Text = "Salvato ✓";
                savedLbl.Visible = true;
            }
            catch (ApiException ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            finally { saveBtn.Enabled = true; }
        };
        card.Controls.Add(saveBtn);
        card.Controls.Add(savedLbl);
        card.Height = y + 90;
    }
}

class UserDialog : ModalForm
{
    private readonly UserAccount? _existing;
    private readonly RoundedTextBox _username = new();
    private readonly RoundedTextBox _email = new();
    private readonly RoundedTextBox _password = new();
    private readonly ComboBox _role = Widgets.MakeCombo(new[] { "Operatore", "Manager", "Admin", "Super Admin", "Kiosk" });
    private readonly RoundedButton _saveBtn = RoundedButton.Primary("Salva");
    private readonly Label _error = new();

    public UserDialog(UserAccount? existing) : base(360, 460)
    {
        _existing = existing;
        Title(existing == null ? "Nuovo utente" : "Modifica utente");

        _error.ForeColor = Theme.DangerTxt;
        _error.BackColor = Theme.DangerBg;
        _error.Location = new Point(22, 50);
        _error.Visible = false;
        Card.Controls.Add(_error);

        int y = 60;
        y = Widgets.LabeledField(Card, "Username", _username, 22, y, 300);
        y = Widgets.LabeledField(Card, "Email (opzionale)", _email, 22, y, 300);
        y = Widgets.LabeledField(Card, existing == null ? "Password (min 8 caratteri)" : "Nuova password (lascia vuoto per non cambiare)", _password, 22, y, 300);
        _password.UseSystemPasswordChar = true;
        y = Widgets.LabeledField(Card, "Ruolo", _role, 22, y, 300);

        var cancelBtn = RoundedButton.Ghost("Annulla");
        cancelBtn.Size = new Size(100, 34);
        cancelBtn.Location = new Point(22, y + 6);
        cancelBtn.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
        Card.Controls.Add(cancelBtn);

        _saveBtn.Size = new Size(190, 34);
        _saveBtn.Location = new Point(130, y + 6);
        _saveBtn.Click += async (_, _) => await SaveAsync();
        Card.Controls.Add(_saveBtn);

        if (existing != null)
        {
            _username.Text = existing.Username;
            _email.Text = existing.Email ?? "";
            var idx = _role.Items.IndexOf(existing.Role);
            if (idx >= 0) _role.SelectedIndex = idx;
        }
    }

    private void ShowError(string msg)
    {
        _error.Text = msg;
        _error.Size = new Size(300, 26);
        _error.Visible = true;
    }

    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_username.Text)) { ShowError("Username obbligatorio"); return; }
        if (_existing == null && _password.Text.Length < 8) { ShowError("Password minimo 8 caratteri"); return; }
        if (_password.Text.Length > 0 && _password.Text.Length < 8) { ShowError("Password minimo 8 caratteri"); return; }

        _saveBtn.Enabled = false;
        try
        {
            if (_existing == null)
            {
                await ApiClient.AddUserAsync(new { username = _username.Text.Trim(), email = _email.Text.Trim(), password = _password.Text, role = _role.SelectedItem?.ToString() ?? "Operatore" });
            }
            else
            {
                var payload = _password.Text.Length >= 8
                    ? new { username = _username.Text.Trim(), role = _role.SelectedItem?.ToString() ?? "Operatore", password = _password.Text }
                    : (object)new { username = _username.Text.Trim(), role = _role.SelectedItem?.ToString() ?? "Operatore" };
                await ApiClient.UpdateUserAsync(_existing.Id, payload);
            }
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (ApiException ex) { ShowError(ex.Message); }
        finally { _saveBtn.Enabled = true; }
    }
}
