using GesClo.Client.Api;

namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/Dashboard.jsx.
public class DashboardPage : UserControl
{
    private readonly Label _errorLabel = new();
    private readonly TableLayoutPanel _metrics = new();
    private readonly ListPanel _movementsPanel;
    private readonly ListPanel _salesPanel;

    public DashboardPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        _errorLabel.ForeColor = Theme.DangerTxt;
        _errorLabel.BackColor = Theme.DangerBg;
        _errorLabel.Dock = DockStyle.Top;
        _errorLabel.Height = 0;
        _errorLabel.Padding = new Padding(10, 8, 10, 8);
        _errorLabel.Visible = false;

        _metrics.Dock = DockStyle.Top;
        _metrics.Height = 90;
        _metrics.ColumnCount = 4;
        _metrics.RowCount = 1;
        for (int i = 0; i < 4; i++) _metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));

        var spacer = new Panel { Dock = DockStyle.Top, Height = 14, BackColor = Theme.Bg };

        var lists = new TableLayoutPanel { Dock = DockStyle.Top, Height = 260, ColumnCount = 2, RowCount = 1 };
        lists.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        lists.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _movementsPanel = new ListPanel("ULTIMI MOVIMENTI", "Nessun movimento") { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 6, 0) };
        _salesPanel = new ListPanel("ULTIME VENDITE", "Nessuna vendita") { Dock = DockStyle.Fill, Margin = new Padding(6, 0, 0, 0) };
        lists.Controls.Add(_movementsPanel, 0, 0);
        lists.Controls.Add(_salesPanel, 1, 0);

        // Per uno stack di controlli Dock=Top, l'ultimo aggiunto e il piu vicino al bordo
        // superiore: si aggiunge quindi in ordine visivo inverso (dal basso verso l'alto).
        Controls.Add(lists);
        Controls.Add(spacer);
        Controls.Add(_metrics);
        Controls.Add(_errorLabel);

        Load += async (_, _) => await LoadDataAsync();
    }

    private async Task LoadDataAsync()
    {
        SetMetrics(loading: true, new Stats());
        try
        {
            var statsTask = ApiClient.GetStatsAsync();
            var movementsTask = ApiClient.GetMovementsAsync();
            var salesTask = ApiClient.GetSalesAsync();
            await Task.WhenAll(statsTask, movementsTask, salesTask);

            SetMetrics(loading: false, statsTask.Result);
            _movementsPanel.SetMovements(movementsTask.Result.Take(4).ToList());
            _salesPanel.SetSales(salesTask.Result.Take(4).ToList());
        }
        catch (ApiException ex)
        {
            ShowError(ex.Message);
        }
        catch (Exception ex)
        {
            ShowError($"Errore caricamento dati: {ex.Message}");
        }
    }

    private void ShowError(string message)
    {
        _errorLabel.Text = message;
        _errorLabel.Height = 34;
        _errorLabel.Visible = true;
    }

    private void SetMetrics(bool loading, Stats stats)
    {
        _metrics.Controls.Clear();
        var cards = new[]
        {
            ("Articoli", loading ? "..." : stats.TotalProducts.ToString()),
            ("Vendite oggi", loading ? "..." : stats.TodaySales.ToString()),
            ("Incasso oggi", loading ? "..." : $"€{stats.TodayRevenue:0.00}"),
            ("Alert", loading ? "..." : (stats.OutOfStock + stats.LowStock).ToString()),
        };
        for (int i = 0; i < cards.Length; i++)
        {
            var (label, value) = cards[i];
            _metrics.Controls.Add(MakeMetricCard(label, value), i, 0);
        }
    }

    private static Panel MakeMetricCard(string label, string value)
    {
        var card = new CardPanel { Margin = new Padding(0, 0, 10, 0), Dock = DockStyle.Fill };
        var lbl = new Label { Text = label, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(14, 12) };
        var val = new Label { Text = value, ForeColor = Theme.Text, Font = new Font("Segoe UI", 17f, FontStyle.Regular), AutoSize = true, Location = new Point(14, 34) };
        card.Controls.Add(lbl);
        card.Controls.Add(val);
        return card;
    }
}

// Riquadro con titolo + elenco righe "etichetta a sinistra, valore a destra" (movimenti/vendite).
class ListPanel : CardPanel
{
    private readonly string _emptyText;
    private readonly Label _emptyLabel;
    private readonly FlowLayoutPanel _rows;

    public ListPanel(string title, string emptyText)
    {
        _emptyText = emptyText;
        Padding = new Padding(14);

        var titleLabel = new Label { Text = title, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Dock = DockStyle.Top };
        _emptyLabel = new Label { Text = emptyText, ForeColor = Theme.Text3, Font = Theme.FontRegular, AutoSize = true, Dock = DockStyle.Top, Padding = new Padding(0, 16, 0, 0), TextAlign = ContentAlignment.MiddleCenter };
        _rows = new FlowLayoutPanel { Dock = DockStyle.Top, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Visible = false };

        // Vedi nota in DashboardPage: per Dock=Top si aggiunge in ordine visivo inverso.
        Controls.Add(_rows);
        Controls.Add(_emptyLabel);
        Controls.Add(titleLabel);
    }

    public void SetMovements(List<Movement> movements)
    {
        _rows.Controls.Clear();
        _emptyLabel.Visible = movements.Count == 0;
        _rows.Visible = movements.Count > 0;
        foreach (var m in movements)
        {
            var sign = m.Type == "entrata" ? "+" : "-";
            var color = m.Type == "entrata" ? Theme.SuccessTxt : Theme.DangerTxt;
            _rows.Controls.Add(MakeRow(m.ProductName, $"{sign}{m.Qty}", color));
        }
    }

    public void SetSales(List<Sale> sales)
    {
        _rows.Controls.Clear();
        _emptyLabel.Visible = sales.Count == 0;
        _rows.Visible = sales.Count > 0;
        foreach (var s in sales)
            _rows.Controls.Add(MakeRow(s.CustomerName, $"€{s.Total:0.00}", Theme.Accent));
    }

    private static Panel MakeRow(string left, string right, Color rightColor)
    {
        var row = new Panel { Width = 300, Height = 26 };
        var l = new Label { Text = left, ForeColor = Theme.Text, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, 5) };
        var r = new Label { Text = right, ForeColor = rightColor, Font = Theme.FontMedium, AutoSize = true };
        row.Controls.Add(l);
        row.Controls.Add(r);
        row.Resize += (_, _) => r.Location = new Point(row.Width - r.Width, 5);
        r.Location = new Point(row.Width - r.Width, 5);
        return row;
    }
}
