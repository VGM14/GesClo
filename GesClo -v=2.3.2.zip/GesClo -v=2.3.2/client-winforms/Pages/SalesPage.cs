using GesClo.Client.Api;
using GesClo.Client.Controls;

namespace GesClo.Client.Pages;

class CartItem
{
    public string ProductId = "";
    public string Name = "";
    public double Price;
    public int Qty;
    public double Subtotal => Price * Qty;
}

// Rispecchia frontend/src/pages/Sales.jsx (cassa + storico + clienti). L'integrazione
// POS Android/NFC live e la stampa scontrino HTML della webapp non sono portate:
// dipendono da hardware/browser specifici, fuori scope per un client desktop nativo.
public class SalesPage : UserControl
{
    private readonly Panel _tabBar = new() { Dock = DockStyle.Top, Height = 40 };
    private readonly Panel _body = new() { Dock = DockStyle.Fill };
    private string _tab = "cassa";

    private List<Product> _products = new();
    private List<Customer> _customers = new();
    private List<Sale> _sales = new();
    private CashRegister _cashReg = new();
    private readonly List<CartItem> _cart = new();
    private Customer? _selectedCustomer;
    private string _paymentMethod = "contanti";
    private double _discountPercent;

    // Controlli cassa (creati una volta, riusati a ogni Render)
    private RoundedTextBox? _productSearch, _customerSearch, _notesBox, _discountBox;
    private FlowLayoutPanel? _productGrid, _cartRows, _customerSuggestions;
    private Label? _totalLabel, _subtotalLabel, _discountAmtLabel;
    private RoundedButton? _completeBtn;
    private readonly Dictionary<string, RoundedButton> _paymentButtons = new();

    public SalesPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        foreach (var (key, label) in new[] { ("cassa", "Cassa"), ("storico", "Storico vendite"), ("clienti", "Clienti") })
        {
            var btn = RoundedButton.Ghost(label);
            btn.Size = new Size(label.Length * 8 + 40, 30);
            btn.Click += (_, _) => { _tab = key; RenderTab(); };
            _tabBar.Controls.Add(btn);
        }
        LayoutTabBar();

        var wrapper = new Panel { Dock = DockStyle.Fill };
        wrapper.Controls.Add(_body);
        wrapper.Controls.Add(_tabBar);
        Controls.Add(wrapper);

        Load += async (_, _) => await LoadAllAsync();
    }

    private void LayoutTabBar()
    {
        int x = 0;
        foreach (Control c in _tabBar.Controls) { c.Location = new Point(x, 0); x += c.Width + 6; }
    }

    private async Task LoadAllAsync()
    {
        try
        {
            var pT = ApiClient.GetProductsAsync();
            var cT = ApiClient.GetCustomersAsync();
            var sT = ApiClient.GetSalesAsync();
            var crT = ApiClient.GetCashRegisterAsync();
            await Task.WhenAll(pT, cT, sT, crT);
            _products = pT.Result; _customers = cT.Result; _sales = sT.Result; _cashReg = crT.Result;
        }
        catch (ApiException ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        RenderTab();
    }

    private void RenderTab()
    {
        foreach (Control c in _tabBar.Controls)
            if (c is RoundedButton b)
            {
                var key = b.Text == "Cassa" ? "cassa" : b.Text == "Storico vendite" ? "storico" : "clienti";
                b.BackColor = key == _tab ? Theme.AccentBg : Theme.Bg2;
                b.ForeColor = key == _tab ? Theme.AccentText : Theme.Text3;
                b.BorderColor = key == _tab ? Theme.Accent : Theme.Border;
            }

        _body.Controls.Clear();
        switch (_tab)
        {
            case "cassa": BuildCassa(); break;
            case "storico": BuildStorico(); break;
            case "clienti": BuildClienti(); break;
        }
    }

    // ── CASSA ──────────────────────────────────────────────────
    private void BuildCassa()
    {
        var split = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62));
        split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38));

        // ── Sinistra: ricerca + griglia prodotti ──
        var left = new Panel { Dock = DockStyle.Fill };
        _productSearch = new RoundedTextBox { Location = new Point(0, 0), Size = new Size(400, 32) };
        _productSearch.Inner.TextChanged += (_, _) => RenderProductGrid();
        var searchLbl = new Label { Text = "Cerca prodotto...", ForeColor = Theme.Text3, Font = Theme.FontSmall, Visible = false };
        left.Controls.Add(_productSearch);

        var gridCard = new CardPanel { Location = new Point(0, 42), Size = new Size(600, 500), AutoScroll = true };
        _productGrid = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(8) };
        gridCard.Controls.Add(_productGrid);
        left.Controls.Add(gridCard);
        left.Resize += (_, _) => { _productSearch.Width = left.Width; gridCard.Size = new Size(left.Width, left.Height - 42); };

        // ── Destra: cliente, carrello, totali ──
        var right = new Panel { Dock = DockStyle.Fill };

        var custCard = new CardPanel { Location = new Point(0, 0), Size = new Size(340, 90) };
        var custLbl = new Label { Text = "CLIENTE", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(12, 10) };
        _customerSearch = new RoundedTextBox { Location = new Point(12, 32), Size = new Size(260, 30) };
        _customerSearch.Inner.TextChanged += (_, _) => { _selectedCustomer = null; RenderCustomerSuggestions(); };
        var addCustBtn = RoundedButton.Primary("+");
        addCustBtn.Location = new Point(280, 32);
        addCustBtn.Size = new Size(40, 30);
        addCustBtn.Click += async (_, _) => await OpenNewCustomerAsync();
        _customerSuggestions = new FlowLayoutPanel { Location = new Point(12, 64), Size = new Size(308, 0), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true };
        custCard.Controls.Add(custLbl); custCard.Controls.Add(_customerSearch); custCard.Controls.Add(addCustBtn); custCard.Controls.Add(_customerSuggestions);
        right.Controls.Add(custCard);

        var cartCard = new CardPanel { Location = new Point(0, 98), Size = new Size(340, 260), AutoScroll = true };
        _cartRows = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true };
        cartCard.Controls.Add(_cartRows);
        right.Controls.Add(cartCard);

        var totalsCard = new CardPanel { Location = new Point(0, 366), Size = new Size(340, 300) };
        BuildTotalsCard(totalsCard);
        right.Controls.Add(totalsCard);

        right.Resize += (_, _) =>
        {
            custCard.Width = right.Width;
            cartCard.Size = new Size(right.Width, Math.Max(120, right.Height - 98 - 308));
            totalsCard.Location = new Point(0, cartCard.Bottom + 8);
            totalsCard.Width = right.Width;
        };

        split.Controls.Add(left, 0, 0);
        split.Controls.Add(right, 1, 0);
        _body.Controls.Add(split);

        RenderProductGrid();
        RenderCart();
        RenderCustomerSuggestions();
    }

    private void BuildTotalsCard(CardPanel card)
    {
        _subtotalLabel = new Label { ForeColor = Theme.Text, Font = Theme.FontRegular, AutoSize = true, Location = new Point(12, 12) };
        card.Controls.Add(new Label { Text = "Subtotale", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(12, 12) });
        _subtotalLabel.Location = new Point(280, 12);
        card.Controls.Add(_subtotalLabel);

        card.Controls.Add(new Label { Text = "Sconto %", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(12, 40) });
        _discountBox = new RoundedTextBox { Text = "0", Location = new Point(90, 34), Size = new Size(60, 28) };
        _discountBox.Inner.TextChanged += (_, _) => { double.TryParse(_discountBox!.Text, out _discountPercent); RenderTotals(); };
        card.Controls.Add(_discountBox);
        _discountAmtLabel = new Label { ForeColor = Theme.DangerTxt, Font = Theme.FontSmall, AutoSize = true, Location = new Point(160, 40) };
        card.Controls.Add(_discountAmtLabel);

        _totalLabel = new Label { ForeColor = Theme.Accent, Font = new Font("Segoe UI", 15f, FontStyle.Bold), AutoSize = true, Location = new Point(200, 66) };
        card.Controls.Add(new Label { Text = "TOTALE", ForeColor = Theme.Text, Font = Theme.FontMedium, AutoSize = true, Location = new Point(12, 72) });
        card.Controls.Add(_totalLabel);

        var payGrid = new FlowLayoutPanel { Location = new Point(12, 104), Size = new Size(316, 70), WrapContents = true };
        _paymentButtons.Clear();
        foreach (var (key, label) in new[] { ("contanti", "Contanti"), ("carta", "Carta"), ("bonifico", "Bonifico"), ("assegno", "Assegno"), ("altro", "Altro") })
        {
            var b = RoundedButton.Ghost(label);
            b.Size = new Size(96, 30);
            b.Click += (_, _) => { _paymentMethod = key; UpdatePaymentButtons(); };
            _paymentButtons[key] = b;
            payGrid.Controls.Add(b);
        }
        card.Controls.Add(payGrid);
        UpdatePaymentButtons();

        _notesBox = new RoundedTextBox { Location = new Point(12, 182), Size = new Size(316, 30) };
        card.Controls.Add(_notesBox);

        _completeBtn = RoundedButton.Primary("✓ Completa vendita");
        _completeBtn.Location = new Point(12, 222);
        _completeBtn.Size = new Size(316, 40);
        _completeBtn.Click += async (_, _) => await CompleteSaleAsync();
        card.Controls.Add(_completeBtn);
    }

    private void UpdatePaymentButtons()
    {
        foreach (var (key, b) in _paymentButtons)
        {
            var active = key == _paymentMethod;
            b.BackColor = active ? Theme.AccentBg : Theme.Bg2;
            b.ForeColor = active ? Theme.AccentText : Theme.Text3;
            b.BorderColor = active ? Theme.Accent : Theme.Border;
        }
    }

    private void RenderProductGrid()
    {
        if (_productGrid == null) return;
        var q = (_productSearch?.Text ?? "").Trim().ToLowerInvariant();
        var filtered = _products.Where(p => (p.Name?.ToLowerInvariant().Contains(q) ?? false) || (p.Barcode?.Contains(q) ?? false)).ToList();

        _productGrid.Controls.Clear();
        foreach (var p in filtered)
        {
            var tile = new CardPanel { Width = 150, Height = 70, Margin = new Padding(4), Radius = 10 };
            var outOfStock = p.Qty <= 0;
            tile.Cursor = outOfStock ? Cursors.Default : Cursors.Hand;
            var name = new Label { Text = p.Name, ForeColor = outOfStock ? Theme.Text3 : Theme.Text, Font = Theme.FontMedium, AutoSize = false, Size = new Size(134, 32), Location = new Point(8, 6) };
            var price = new Label { Text = $"€{(p.Price ?? 0):0.00}", ForeColor = Theme.Accent, Font = Theme.FontSmall, AutoSize = true, Location = new Point(8, 38) };
            var stock = new Label { Text = outOfStock ? "Esaurito" : $"{p.Qty} {p.Unit}", ForeColor = outOfStock ? Theme.DangerTxt : p.Qty <= 5 ? Theme.WarnTxt : Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(8, 54) };
            tile.Controls.Add(name); tile.Controls.Add(price); tile.Controls.Add(stock);
            if (!outOfStock)
            {
                void Click(object? s, EventArgs e) => AddToCart(p);
                tile.Click += Click; name.Click += Click; price.Click += Click; stock.Click += Click;
            }
            _productGrid.Controls.Add(tile);
        }
    }

    private void RenderCustomerSuggestions()
    {
        if (_customerSuggestions == null) return;
        _customerSuggestions.Controls.Clear();
        var q = (_customerSearch?.Text ?? "").Trim();
        if (q.Length == 0 || _selectedCustomer != null) { _customerSuggestions.Height = 0; return; }

        var matches = _customers.Where(c => (c.Name?.Contains(q, StringComparison.OrdinalIgnoreCase) ?? false) || (c.Phone?.Contains(q) ?? false)).Take(5).ToList();
        _customerSuggestions.Height = Math.Min(100, matches.Count * 24);
        foreach (var c in matches)
        {
            var row = new Label { Text = c.Name + (string.IsNullOrEmpty(c.Phone) ? "" : $" — {c.Phone}"), ForeColor = Theme.Text, Font = Theme.FontSmall, AutoSize = false, Size = new Size(300, 22), Cursor = Cursors.Hand };
            row.Click += (_, _) => { _selectedCustomer = c; _customerSearch!.Text = c.Name; RenderCustomerSuggestions(); };
            _customerSuggestions.Controls.Add(row);
        }
    }

    private void AddToCart(Product p)
    {
        var existing = _cart.FirstOrDefault(i => i.ProductId == p.Id);
        if (existing != null) existing.Qty++;
        else _cart.Add(new CartItem { ProductId = p.Id, Name = p.Name, Price = p.Price ?? 0, Qty = 1 });
        RenderCart();
    }

    private void RenderCart()
    {
        if (_cartRows == null) return;
        _cartRows.Controls.Clear();
        foreach (var item in _cart)
        {
            var row = new Panel { Width = 300, Height = 30 };
            var name = new Label { Text = item.Name, ForeColor = Theme.Text, Font = Theme.FontSmall, AutoSize = false, Size = new Size(120, 20), Location = new Point(0, 5) };
            var qtyBox = new NumericUpDown { Value = item.Qty, Minimum = 1, Maximum = 9999, Location = new Point(122, 3), Width = 50 };
            qtyBox.ValueChanged += (_, _) => { item.Qty = (int)qtyBox.Value; RenderCart(); };
            var subtotal = new Label { Text = $"€{item.Subtotal:0.00}", ForeColor = Theme.Accent, Font = Theme.FontMedium, AutoSize = true, Location = new Point(180, 5) };
            var removeBtn = new Label { Text = "×", ForeColor = Theme.DangerTxt, Font = new Font("Segoe UI", 12f, FontStyle.Bold), AutoSize = true, Location = new Point(270, 2), Cursor = Cursors.Hand };
            removeBtn.Click += (_, _) => { _cart.Remove(item); RenderCart(); };
            row.Controls.Add(name); row.Controls.Add(qtyBox); row.Controls.Add(subtotal); row.Controls.Add(removeBtn);
            _cartRows.Controls.Add(row);
        }
        RenderTotals();
    }

    private void RenderTotals()
    {
        var subtotal = _cart.Sum(i => i.Subtotal);
        var discountAmt = subtotal * _discountPercent / 100;
        var tax = _cashReg.ShowTax ? (subtotal - discountAmt) * _cashReg.TaxRate / 100 : 0;
        var total = subtotal - discountAmt + tax;
        if (_subtotalLabel != null) _subtotalLabel.Text = $"€{subtotal:0.00}";
        if (_discountAmtLabel != null) _discountAmtLabel.Text = discountAmt > 0 ? $"-€{discountAmt:0.00}" : "";
        if (_totalLabel != null) _totalLabel.Text = $"€{total:0.00}";
        if (_completeBtn != null) _completeBtn.Enabled = _cart.Count > 0;
    }

    private async Task OpenNewCustomerAsync()
    {
        using var dlg = new CustomerDialog();
        if (dlg.ShowDialog(FindForm()) == DialogResult.OK && dlg.Created != null)
        {
            _customers.Add(dlg.Created);
            _selectedCustomer = dlg.Created;
            _customerSearch!.Text = dlg.Created.Name;
            RenderCustomerSuggestions();
        }
    }

    private async Task CompleteSaleAsync()
    {
        if (_cart.Count == 0) return;
        var subtotal = _cart.Sum(i => i.Subtotal);
        var discountAmt = subtotal * _discountPercent / 100;
        var tax = _cashReg.ShowTax ? (subtotal - discountAmt) * _cashReg.TaxRate / 100 : 0;
        var total = subtotal - discountAmt + tax;

        var payload = new
        {
            customer_id = _selectedCustomer?.Id ?? "",
            customer_name = _selectedCustomer?.Name ?? "Cliente generico",
            items = _cart.Select(i => new { product_id = i.ProductId, name = i.Name, price = i.Price, qty = i.Qty, subtotal = i.Subtotal }).ToList(),
            subtotal, discount = discountAmt, tax, total,
            payment_method = _paymentMethod,
            payment_other = "",
            notes = _notesBox?.Text ?? ""
        };

        _completeBtn!.Enabled = false;
        _completeBtn.Text = "Registrazione...";
        try
        {
            var sale = await ApiClient.AddSaleAsync(payload);
            MessageBox.Show($"Vendita #{sale.Number} registrata!", "Vendita completata", MessageBoxButtons.OK, MessageBoxIcon.Information);
            _cart.Clear(); _selectedCustomer = null; _discountPercent = 0;
            if (_customerSearch != null) _customerSearch.Text = "";
            if (_discountBox != null) _discountBox.Text = "0";
            if (_notesBox != null) _notesBox.Text = "";
            _products = await ApiClient.GetProductsAsync();
            _sales = await ApiClient.GetSalesAsync();
            RenderProductGrid();
            RenderCart();
        }
        catch (ApiException ex)
        {
            MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _completeBtn.Enabled = true;
            _completeBtn.Text = "✓ Completa vendita";
        }
    }

    // ── STORICO ────────────────────────────────────────────────
    private void BuildStorico()
    {
        var card = new CardPanel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(16) };
        var list = new FlowLayoutPanel { Dock = DockStyle.Top, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true };

        if (_sales.Count == 0)
        {
            list.Controls.Add(new Label { Text = "Nessuna vendita", ForeColor = Theme.Text3, AutoSize = true });
        }
        else
        {
            foreach (var s in _sales)
            {
                var row = new Panel { Width = 900, Height = 30 };
                row.Controls.Add(new Label { Text = $"#{s.Number}", ForeColor = Theme.Accent, Font = Theme.FontMedium, AutoSize = true, Location = new Point(0, 5) });
                row.Controls.Add(new Label { Text = s.Date, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(60, 6) });
                row.Controls.Add(new Label { Text = s.CustomerName, ForeColor = Theme.Text, Font = Theme.FontRegular, AutoSize = true, Location = new Point(150, 5) });
                var payPill = Widgets.Pill(s.PaymentMethod, Theme.AccentBg, Theme.AccentText);
                payPill.Location = new Point(480, 4);
                row.Controls.Add(payPill);
                row.Controls.Add(new Label { Text = $"€{s.Total:0.00}", ForeColor = Theme.Accent, Font = Theme.FontMedium, AutoSize = true, Location = new Point(600, 5) });
                list.Controls.Add(row);
            }
        }
        card.Controls.Add(list);
        _body.Controls.Add(card);
    }

    // ── CLIENTI ────────────────────────────────────────────────
    private void BuildClienti()
    {
        var card = new CardPanel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(16) };

        var header = new Panel { Dock = DockStyle.Top, Height = 30 };
        header.Controls.Add(new Label { Text = "CLIENTI", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, 6) });
        var addBtn = RoundedButton.Primary("+ Nuovo cliente");
        addBtn.Size = new Size(150, 30);
        addBtn.Location = new Point(header.Width - addBtn.Width, 0);
        addBtn.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        addBtn.Click += async (_, _) =>
        {
            using var dlg = new CustomerDialog();
            if (dlg.ShowDialog(FindForm()) == DialogResult.OK) { _customers = await ApiClient.GetCustomersAsync(); RenderTab(); }
        };
        header.Controls.Add(addBtn);

        var list = new FlowLayoutPanel { Dock = DockStyle.Top, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Margin = new Padding(0, 12, 0, 0) };
        if (_customers.Count == 0)
        {
            list.Controls.Add(new Label { Text = "Nessun cliente", ForeColor = Theme.Text3, AutoSize = true });
        }
        else
        {
            foreach (var c in _customers)
            {
                var row = new Panel { Width = 700, Height = 34 };
                row.Controls.Add(new Label { Text = c.Name, ForeColor = Theme.Text, Font = Theme.FontMedium, AutoSize = true, Location = new Point(0, 8) });
                var contact = string.Join(" — ", new[] { c.Email, c.Phone }.Where(s => !string.IsNullOrEmpty(s)));
                row.Controls.Add(new Label { Text = contact, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(220, 9) });
                list.Controls.Add(row);
            }
        }

        card.Controls.Add(list);
        card.Controls.Add(header);
        _body.Controls.Add(card);
    }
}

class CustomerDialog : ModalForm
{
    public new Customer? Created;
    private readonly RoundedTextBox _name = new();
    private readonly RoundedTextBox _email = new();
    private readonly RoundedTextBox _phone = new();
    private readonly RoundedTextBox _address = new();
    private readonly RoundedButton _saveBtn = RoundedButton.Primary("Salva");
    private readonly Label _error = new();

    public CustomerDialog() : base(360, 420)
    {
        Title("Nuovo cliente");
        _error.ForeColor = Theme.DangerTxt;
        _error.BackColor = Theme.DangerBg;
        _error.Location = new Point(22, 50);
        _error.Visible = false;
        Card.Controls.Add(_error);

        int y = 60;
        y = Widgets.LabeledField(Card, "Nome *", _name, 22, y, 300);
        y = Widgets.LabeledField(Card, "Email", _email, 22, y, 300);
        y = Widgets.LabeledField(Card, "Telefono", _phone, 22, y, 300);
        y = Widgets.LabeledField(Card, "Indirizzo", _address, 22, y, 300);

        var cancelBtn = RoundedButton.Ghost("Annulla");
        cancelBtn.Size = new Size(100, 34);
        cancelBtn.Location = new Point(22, y + 6);
        cancelBtn.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
        Card.Controls.Add(cancelBtn);

        _saveBtn.Size = new Size(190, 34);
        _saveBtn.Location = new Point(130, y + 6);
        _saveBtn.Click += async (_, _) => await SaveAsync();
        Card.Controls.Add(_saveBtn);
    }

    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_name.Text))
        {
            _error.Text = "Il nome è obbligatorio";
            _error.Size = new Size(300, 26);
            _error.Visible = true;
            return;
        }
        try
        {
            Created = await ApiClient.AddCustomerAsync(new { name = _name.Text.Trim(), email = _email.Text.Trim(), phone = _phone.Text.Trim(), address = _address.Text.Trim() });
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (ApiException ex)
        {
            _error.Text = ex.Message;
            _error.Size = new Size(300, 26);
            _error.Visible = true;
        }
    }
}
