using GesClo.Client.Api;
using GesClo.Client.Controls;

namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/Stock.jsx.
public class StockPage : UserControl
{
    private readonly RoundedTextBox _search = new();
    private readonly DataGridView _grid = new();
    private readonly Label _empty = new();
    private List<Product> _products = new();

    public StockPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        var toolbar = new Panel { Dock = DockStyle.Top, Height = 40 };
        _search.Location = new Point(0, 0);
        _search.Size = new Size(320, 32);
        toolbar.Controls.Add(_search);

        var addBtn = RoundedButton.Primary("+ Nuovo articolo");
        addBtn.Size = new Size(150, 32);
        addBtn.Click += (_, _) => OpenEdit(null);
        toolbar.Controls.Add(addBtn);

        var refreshBtn = RoundedButton.Ghost("↻");
        refreshBtn.Size = new Size(36, 32);
        refreshBtn.Click += async (_, _) => await LoadAsync();
        toolbar.Controls.Add(refreshBtn);

        toolbar.Resize += (_, _) =>
        {
            refreshBtn.Location = new Point(toolbar.Width - refreshBtn.Width, 0);
            addBtn.Location = new Point(refreshBtn.Left - addBtn.Width - 8, 0);
        };

        _search.Inner.TextChanged += (_, _) => Render();

        SetupGrid();

        _empty.Dock = DockStyle.Fill;
        _empty.TextAlign = ContentAlignment.MiddleCenter;
        _empty.ForeColor = Theme.Text3;
        _empty.Font = Theme.FontRegular;
        _empty.Text = "Caricamento...";

        var body = new CardPanel { Dock = DockStyle.Fill, Margin = new Padding(0, 12, 0, 0) };
        body.Controls.Add(_grid);
        body.Controls.Add(_empty);
        _grid.BringToFront();

        var wrapper = new Panel { Dock = DockStyle.Fill };
        wrapper.Controls.Add(body);
        wrapper.Controls.Add(toolbar);

        Controls.Add(wrapper);

        Load += async (_, _) => await LoadAsync();
    }

    private void SetupGrid()
    {
        _grid.Dock = DockStyle.Fill;
        _grid.BackgroundColor = Theme.Bg2;
        _grid.BorderStyle = BorderStyle.None;
        _grid.GridColor = Theme.Border;
        _grid.RowHeadersVisible = false;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToResizeRows = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.RowTemplate.Height = 34;
        _grid.EnableHeadersVisualStyles = false;
        _grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        _grid.ColumnHeadersHeight = 32;
        _grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Theme.Bg2, ForeColor = Theme.Text3, Font = Theme.FontSmall,
            Alignment = DataGridViewContentAlignment.MiddleLeft, SelectionBackColor = Theme.Bg2, SelectionForeColor = Theme.Text3
        };
        _grid.DefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Theme.Bg2, ForeColor = Theme.Text, Font = Theme.FontRegular,
            SelectionBackColor = Theme.AccentBg, SelectionForeColor = Theme.AccentText, Padding = new Padding(2)
        };
        _grid.AlternatingRowsDefaultCellStyle = _grid.DefaultCellStyle;
        _grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;

        _grid.Columns.Add("name", "Articolo");
        _grid.Columns.Add("category", "Categoria");
        _grid.Columns.Add("price", "Prezzo");
        _grid.Columns.Add("qty", "Qty");
        _grid.Columns.Add("status", "Stato");
        var editCol = new DataGridViewButtonColumn { Name = "edit", HeaderText = "", Text = "Modifica", UseColumnTextForButtonValue = true, Width = 80 };
        var delCol = new DataGridViewButtonColumn { Name = "delete", HeaderText = "", Text = "Elimina", UseColumnTextForButtonValue = true, Width = 80 };
        _grid.Columns.Add(editCol);
        _grid.Columns.Add(delCol);
        _grid.Columns["price"].FillWeight = 60;
        _grid.Columns["qty"].FillWeight = 50;
        _grid.Columns["status"].FillWeight = 70;
        _grid.Columns["category"].FillWeight = 80;

        _grid.CellClick += async (_, e) =>
        {
            if (e.RowIndex < 0) return;
            var p = (Product)_grid.Rows[e.RowIndex].Tag!;
            if (_grid.Columns[e.ColumnIndex].Name == "edit") OpenEdit(p);
            else if (_grid.Columns[e.ColumnIndex].Name == "delete") await DeleteAsync(p);
        };
    }

    private async Task LoadAsync()
    {
        _empty.Text = "Caricamento...";
        _empty.Visible = true;
        try
        {
            _products = await ApiClient.GetProductsAsync();
            Render();
        }
        catch (ApiException ex)
        {
            _empty.Text = ex.Message;
            _empty.Visible = true;
        }
    }

    private void Render()
    {
        var q = _search.Text.Trim().ToLowerInvariant();
        var filtered = _products.Where(p =>
            (p.Name?.ToLowerInvariant().Contains(q) ?? false) ||
            (p.Barcode?.Contains(q) ?? false) ||
            (p.Category?.ToLowerInvariant().Contains(q) ?? false)).ToList();

        _grid.Rows.Clear();
        _empty.Visible = filtered.Count == 0;
        _empty.Text = _products.Count == 0 ? "Nessun articolo — clicca \"Nuovo articolo\"" : $"Nessun risultato per \"{_search.Text}\"";

        foreach (var p in filtered)
        {
            var (label, bg, fg) = StatusOf(p.Qty);
            var idx = _grid.Rows.Add(p.Name, p.Category ?? "—", p.Price != null ? $"€{p.Price:0.00}" : "—", $"{p.Qty} {p.Unit}", label);
            _grid.Rows[idx].Tag = p;
            _grid.Rows[idx].Cells["status"].Style.ForeColor = fg;
            _grid.Rows[idx].Cells["status"].Style.BackColor = bg;
        }
    }

    private static (string label, Color bg, Color fg) StatusOf(int qty)
    {
        if (qty <= 0) return ("Esaurito", Theme.DangerBg, Theme.DangerTxt);
        if (qty <= 5) return ("Basso", Theme.WarnBg, Theme.WarnTxt);
        return ("OK", Theme.SuccessBg, Theme.SuccessTxt);
    }

    private void OpenEdit(Product? existing)
    {
        using var dlg = new ProductDialog(existing);
        if (dlg.ShowDialog(FindForm()) == DialogResult.OK)
            _ = LoadAsync();
    }

    private async Task DeleteAsync(Product p)
    {
        if (MessageBox.Show($"Eliminare \"{p.Name}\"? L'azione è irreversibile.", "Conferma eliminazione", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            return;
        try { await ApiClient.DeleteProductAsync(p.Id); await LoadAsync(); }
        catch (ApiException ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}

// Modale aggiungi/modifica articolo.
class ProductDialog : ModalForm
{
    private readonly Product? _existing;
    private readonly RoundedTextBox _name = new();
    private readonly RoundedTextBox _barcode = new();
    private readonly RoundedTextBox _category = new();
    private readonly RoundedTextBox _price = new();
    private readonly RoundedTextBox _qty = new();
    private readonly ComboBox _unit = Widgets.MakeCombo(new[] { "pz", "kg", "g", "l", "ml", "m", "cm", "conf", "box" });
    private readonly RoundedTextBox _notes = new();
    private readonly RoundedButton _saveBtn = RoundedButton.Primary("Salva");
    private readonly Label _error = new();

    public ProductDialog(Product? existing) : base(400, 560)
    {
        _existing = existing;
        Title(existing == null ? "Nuovo articolo" : "Modifica articolo");

        _error.ForeColor = Theme.DangerTxt;
        _error.BackColor = Theme.DangerBg;
        _error.Location = new Point(22, 50);
        _error.Size = new Size(0, 0);
        _error.Padding = new Padding(8, 6, 8, 6);
        _error.Visible = false;
        Card.Controls.Add(_error);

        int y = 60;
        y = Widgets.LabeledField(Card, "Nome articolo *", _name, 22, y, 336);
        y = Widgets.LabeledField(Card, "Barcode", _barcode, 22, y, 336);
        y = Widgets.LabeledField(Card, "Categoria", _category, 22, y, 336);
        y = Widgets.LabeledField(Card, "Prezzo (€)", _price, 22, y, 336);

        var qtyLbl = new Label { Text = "Quantità", ForeColor = Theme.Text2, Font = Theme.FontSmall, AutoSize = true, Location = new Point(22, y) };
        var unitLbl = new Label { Text = "Unità", ForeColor = Theme.Text2, Font = Theme.FontSmall, AutoSize = true, Location = new Point(190, y) };
        Card.Controls.Add(qtyLbl); Card.Controls.Add(unitLbl);
        y += 18;
        _qty.Location = new Point(22, y); _qty.Size = new Size(160, 30);
        _unit.Location = new Point(190, y); _unit.Size = new Size(168, 26);
        Card.Controls.Add(_qty); Card.Controls.Add(_unit);
        y += 42;

        y = Widgets.LabeledField(Card, "Note", _notes, 22, y, 336);

        var cancelBtn = RoundedButton.Ghost("Annulla");
        cancelBtn.Size = new Size(110, 34);
        cancelBtn.Location = new Point(22, y + 6);
        cancelBtn.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
        Card.Controls.Add(cancelBtn);

        _saveBtn.Size = new Size(226, 34);
        _saveBtn.Location = new Point(140, y + 6);
        _saveBtn.Click += async (_, _) => await SaveAsync();
        Card.Controls.Add(_saveBtn);

        if (existing != null)
        {
            _name.Text = existing.Name;
            _barcode.Text = existing.Barcode ?? "";
            _category.Text = existing.Category ?? "";
            _price.Text = existing.Price?.ToString("0.00") ?? "";
            _qty.Text = existing.Qty.ToString();
            _notes.Text = existing.Notes ?? "";
            var idx = _unit.Items.IndexOf(existing.Unit);
            if (idx >= 0) _unit.SelectedIndex = idx;
        }
        else
        {
            _qty.Text = "0";
        }
    }

    private void ShowError(string msg)
    {
        _error.Text = msg;
        _error.Size = new Size(336, 28);
        _error.Visible = true;
    }

    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(_name.Text)) { ShowError("Il nome è obbligatorio"); return; }

        double? price = double.TryParse(_price.Text, out var pv) ? pv : null;
        var payload = new
        {
            name = _name.Text.Trim(),
            barcode = _barcode.Text.Trim(),
            category = _category.Text.Trim(),
            price,
            qty = int.TryParse(_qty.Text, out var q) ? q : 0,
            unit = _unit.SelectedItem?.ToString() ?? "pz",
            notes = _notes.Text.Trim()
        };

        _saveBtn.Enabled = false;
        _saveBtn.Text = "Salvataggio...";
        try
        {
            if (_existing == null) await ApiClient.AddProductAsync(payload);
            else await ApiClient.UpdateProductAsync(_existing.Id, payload);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (ApiException ex)
        {
            ShowError(ex.Message);
        }
        finally
        {
            _saveBtn.Enabled = true;
            _saveBtn.Text = "Salva";
        }
    }
}
