using GesClo.Client.Api;

namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/AIPage.jsx — chat con GesBot. Le azioni UI che la webapp
// esegue in risposta ai comandi admin (nascondi tab, rinomina, ecc.) non sono applicate qui.
public class AIPage : UserControl
{
    private readonly FlowLayoutPanel _messages = new();
    private readonly Panel _scroll = new();
    private readonly RoundedTextBox _input = new();
    private readonly RoundedButton _sendBtn;
    private readonly List<(string text, bool isUser)> _history = new();
    private AiConfig? _config;
    private bool _busy;

    public AIPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        _scroll.Dock = DockStyle.Fill;
        _scroll.AutoScroll = true;
        _messages.Dock = DockStyle.Top;
        _messages.FlowDirection = FlowDirection.TopDown;
        _messages.WrapContents = false;
        _messages.AutoSize = true;
        _messages.Padding = new Padding(4);
        _scroll.Controls.Add(_messages);

        var inputBar = new Panel { Dock = DockStyle.Bottom, Height = 46 };
        _input.Location = new Point(0, 6);
        _input.Height = 34;
        _input.Inner.KeyDown += async (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await SendAsync(); } };
        _sendBtn = RoundedButton.Primary("Invia →");
        _sendBtn.Size = new Size(90, 34);
        _sendBtn.Location = new Point(0, 6);
        _sendBtn.Click += async (_, _) => await SendAsync();
        inputBar.Controls.Add(_input);
        inputBar.Controls.Add(_sendBtn);
        inputBar.Resize += (_, _) =>
        {
            _sendBtn.Location = new Point(inputBar.Width - _sendBtn.Width, 6);
            _input.Width = inputBar.Width - _sendBtn.Width - 8;
        };

        var wrapper = new Panel { Dock = DockStyle.Fill };
        wrapper.Controls.Add(_scroll);
        wrapper.Controls.Add(inputBar);
        Controls.Add(wrapper);

        AddMessage("Ciao! Sono GesBot. Posso aiutarti a usare il gestionale. Cosa vuoi fare?", false, null);

        Load += async (_, _) =>
        {
            try { _config = await ApiClient.GetAiConfigAsync(); }
            catch { _config = new AiConfig { Provider = "groq" }; }
        };
    }

    private async Task SendAsync()
    {
        var text = _input.Text.Trim();
        if (text.Length == 0 || _busy) return;
        _input.Text = "";
        AddMessage(text, true, null);
        _history.Add((text, true));

        _busy = true;
        _sendBtn.Enabled = false;
        var thinking = AddMessage("GesBot sta elaborando...", false, null);
        try
        {
            var result = await AiService.AskAsync(text, _history, _config ?? new AiConfig());
            _messages.Controls.Remove(thinking);
            AddMessage(result.Text, false, result.Source);
            _history.Add((result.Text, false));
        }
        catch (ApiException ex)
        {
            _messages.Controls.Remove(thinking);
            AddMessage(ex.Message, false, "errore");
        }
        finally
        {
            _busy = false;
            _sendBtn.Enabled = true;
            _input.Inner.Focus();
        }
    }

    private Control AddMessage(string text, bool isUser, string? source)
    {
        var bubble = new CardPanel
        {
            Radius = 14,
            BackColor = isUser ? Theme.Accent : Theme.Bg2,
            MaximumSize = new Size(520, 0),
            AutoSize = true,
            Padding = new Padding(14, 10, 14, 10),
            Margin = new Padding(isUser ? 200 : 0, 4, isUser ? 0 : 200, 4)
        };
        var lbl = new Label
        {
            Text = text,
            ForeColor = isUser ? Color.White : Theme.Text,
            Font = Theme.FontRegular,
            AutoSize = true,
            MaximumSize = new Size(492, 0)
        };
        bubble.Controls.Add(lbl);

        if (!string.IsNullOrEmpty(source))
        {
            var src = new Label { Text = $"via {source}", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, lbl.Bottom + 4) };
            bubble.Controls.Add(src);
        }

        var row = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true, Anchor = isUser ? AnchorStyles.Right : AnchorStyles.Left, WrapContents = false };
        row.Controls.Add(bubble);

        _messages.Controls.Add(row);
        _scroll.VerticalScroll.Value = _scroll.VerticalScroll.Maximum;
        return row;
    }
}
