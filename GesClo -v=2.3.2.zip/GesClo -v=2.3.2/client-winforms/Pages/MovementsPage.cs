using GesClo.Client.Api;
using GesClo.Client.Controls;

namespace GesClo.Client.Pages;

// Rispecchia frontend/src/pages/Movements.jsx.
public class MovementsPage : UserControl
{
    private readonly FlowLayoutPanel _rows = new();
    private readonly Label _empty = new();
    private List<Product> _products = new();

    public MovementsPage()
    {
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;

        var card = new CardPanel { Dock = DockStyle.Fill, Padding = new Padding(16) };

        var header = new Panel { Dock = DockStyle.Top, Height = 30 };
        var title = new Label { Text = "ULTIMI MOVIMENTI", ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(0, 6) };
        var addBtn = RoundedButton.Primary("+ Nuovo movimento");
        addBtn.Size = new Size(160, 30);
        addBtn.Click += async (_, _) => await OpenNewAsync();
        header.Controls.Add(title);
        header.Controls.Add(addBtn);
        header.Resize += (_, _) => addBtn.Location = new Point(header.Width - addBtn.Width, 0);
        addBtn.Location = new Point(header.Width - addBtn.Width, 0);

        _empty.Dock = DockStyle.Top;
        _empty.Height = 60;
        _empty.TextAlign = ContentAlignment.MiddleCenter;
        _empty.ForeColor = Theme.Text3;
        _empty.Text = "Caricamento...";

        _rows.Dock = DockStyle.Top;
        _rows.FlowDirection = FlowDirection.TopDown;
        _rows.WrapContents = false;
        _rows.AutoSize = true;
        _rows.AutoScroll = false;

        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        scroll.Controls.Add(_rows);
        scroll.Controls.Add(_empty);

        // Dock=Top: aggiungere in ordine visivo inverso.
        card.Controls.Add(scroll);
        card.Controls.Add(header);

        Controls.Add(card);

        Load += async (_, _) => await LoadAsync();
    }

    private async Task LoadAsync()
    {
        _empty.Text = "Caricamento...";
        _empty.Visible = true;
        try
        {
            var movementsTask = ApiClient.GetMovementsAsync();
            var productsTask = ApiClient.GetProductsAsync();
            await Task.WhenAll(movementsTask, productsTask);
            _products = productsTask.Result;
            Render(movementsTask.Result);
        }
        catch (ApiException ex)
        {
            _empty.Text = ex.Message;
        }
    }

    private void Render(List<Movement> movements)
    {
        _rows.Controls.Clear();
        _empty.Visible = movements.Count == 0;
        _empty.Text = "Nessun movimento registrato";

        foreach (var m in movements)
        {
            var row = new Panel { Width = 900, Height = 34 };
            var isIn = m.Type == "entrata";
            var pill = Widgets.Pill(isIn ? "Entrata" : "Uscita", isIn ? Theme.SuccessBg : Theme.DangerBg, isIn ? Theme.SuccessTxt : Theme.DangerTxt);
            pill.Location = new Point(0, 6);
            var name = new Label { Text = m.ProductName, ForeColor = Theme.Text, Font = Theme.FontRegular, AutoSize = true, Location = new Point(90, 9) };
            var qty = new Label { Text = $"{(isIn ? "+" : "-")}{m.Qty}", ForeColor = isIn ? Theme.SuccessTxt : Theme.DangerTxt, Font = Theme.FontMedium, AutoSize = true, Location = new Point(420, 9) };
            var date = DateTime.TryParse(m.CreatedAt, out var dt) ? dt.ToString("dd/MM/yyyy HH:mm") : "";
            var dateLbl = new Label { Text = date, ForeColor = Theme.Text3, Font = Theme.FontSmall, AutoSize = true, Location = new Point(480, 10) };
            row.Controls.Add(pill);
            row.Controls.Add(name);
            row.Controls.Add(qty);
            row.Controls.Add(dateLbl);

            var line = new Panel { Height = 1, BackColor = Theme.Border, Dock = DockStyle.Bottom };
            row.Controls.Add(line);
            _rows.Controls.Add(row);
        }
    }

    private async Task OpenNewAsync()
    {
        if (_products.Count == 0)
        {
            try { _products = await ApiClient.GetProductsAsync(); }
            catch (ApiException ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
        }
        using var dlg = new MovementDialog(_products);
        if (dlg.ShowDialog(FindForm()) == DialogResult.OK)
            await LoadAsync();
    }
}

class MovementDialog : ModalForm
{
    private readonly ComboBox _product;
    private readonly ComboBox _type = Widgets.MakeCombo(new[] { "Entrata", "Uscita" });
    private readonly RoundedTextBox _qty = new() { Text = "1" };
    private readonly RoundedTextBox _notes = new();
    private readonly RoundedButton _saveBtn = RoundedButton.Primary("Registra");
    private readonly Label _error = new();
    private readonly List<Product> _products;

    public MovementDialog(List<Product> products) : base(380, 400)
    {
        _products = products;
        Title("Nuovo movimento");

        _error.ForeColor = Theme.DangerTxt;
        _error.BackColor = Theme.DangerBg;
        _error.Location = new Point(22, 50);
        _error.Visible = false;
        Card.Controls.Add(_error);

        _product = Widgets.MakeCombo(products.Select(p => $"{p.Name} ({p.Qty} {p.Unit})").ToArray());
        _product.Items.Insert(0, "Seleziona articolo...");
        _product.SelectedIndex = 0;

        int y = 60;
        y = Widgets.LabeledField(Card, "Articolo", _product, 22, y, 336);

        var typeLbl = new Label { Text = "Tipo", ForeColor = Theme.Text2, Font = Theme.FontSmall, AutoSize = true, Location = new Point(22, y) };
        var qtyLbl = new Label { Text = "Quantità", ForeColor = Theme.Text2, Font = Theme.FontSmall, AutoSize = true, Location = new Point(190, y) };
        Card.Controls.Add(typeLbl); Card.Controls.Add(qtyLbl);
        y += 18;
        _type.Location = new Point(22, y); _type.Size = new Size(160, 26);
        _qty.Location = new Point(190, y); _qty.Size = new Size(168, 30);
        Card.Controls.Add(_type); Card.Controls.Add(_qty);
        y += 42;

        y = Widgets.LabeledField(Card, "Note", _notes, 22, y, 336);

        var cancelBtn = RoundedButton.Ghost("Annulla");
        cancelBtn.Size = new Size(110, 34);
        cancelBtn.Location = new Point(22, y + 6);
        cancelBtn.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
        Card.Controls.Add(cancelBtn);

        _saveBtn.Size = new Size(226, 34);
        _saveBtn.Location = new Point(140, y + 6);
        _saveBtn.Click += async (_, _) => await SaveAsync();
        Card.Controls.Add(_saveBtn);
    }

    private void ShowError(string msg)
    {
        _error.Text = msg;
        _error.Size = new Size(336, 28);
        _error.Visible = true;
    }

    private async Task SaveAsync()
    {
        var idx = _product.SelectedIndex - 1;
        if (idx < 0) { ShowError("Seleziona un articolo"); return; }
        var product = _products[idx];

        var payload = new
        {
            product_id = product.Id,
            product_name = product.Name,
            type = _type.SelectedIndex == 0 ? "entrata" : "uscita",
            qty = int.TryParse(_qty.Text, out var q) ? q : 1,
            notes = _notes.Text.Trim()
        };

        _saveBtn.Enabled = false;
        _saveBtn.Text = "Registrazione...";
        try
        {
            await ApiClient.AddMovementAsync(payload);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (ApiException ex) { ShowError(ex.Message); }
        finally { _saveBtn.Enabled = true; _saveBtn.Text = "Registra"; }
    }
}
