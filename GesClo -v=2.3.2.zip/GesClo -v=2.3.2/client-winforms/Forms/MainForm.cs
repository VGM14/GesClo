using GesClo.Client.Api;
using GesClo.Client.Pages;

namespace GesClo.Client.Forms;

// Rispecchia frontend/src/components/Layout.jsx: sidebar di navigazione + area contenuto.
public class MainForm : Form
{
    private readonly Panel _sidebar = new();
    private readonly Panel _topBar = new();
    private readonly Panel _content = new();
    private readonly Label _titleLabel = new();
    private readonly Label _userLabel = new();
    private readonly Dictionary<string, RoundedButton> _navButtons = new();

    private static readonly (string Key, string Label)[] NavItems =
    {
        ("dashboard", "Dashboard"),
        ("stock", "Stock"),
        ("sales", "Vendite"),
        ("movements", "Movimenti"),
        ("reports", "Report"),
        ("ai", "AI"),
    };

    public MainForm()
    {
        Text = "GesClo";
        Size = new Size(1360, 860);
        MinimumSize = new Size(960, 600);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Theme.Bg;
        Font = Theme.FontRegular;

        BuildSidebar();
        BuildTopBar();
        BuildContentArea();

        ShowPage("dashboard");
    }

    private void BuildSidebar()
    {
        _sidebar.Dock = DockStyle.Left;
        _sidebar.Width = 200;
        _sidebar.BackColor = Theme.Bg2;
        Controls.Add(_sidebar);

        var brand = new Panel { Dock = DockStyle.Top, Height = 52 };
        var badge = new Panel { Size = new Size(30, 30), Location = new Point(14, 11), BackColor = Theme.Accent };
        Theme.ApplyRoundedRegion(badge, 8);
        brand.Controls.Add(badge);
        var brandLabel = new Label { Text = "GesClo", ForeColor = Theme.Text, Font = Theme.FontMedium, AutoSize = true, Location = new Point(52, 16) };
        brand.Controls.Add(brandLabel);

        var navPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoSize = true,
            Padding = new Padding(8, 8, 8, 8)
        };
        foreach (var (key, label) in NavItems)
        {
            var btn = MakeNavButton(label);
            btn.Click += (_, _) => ShowPage(key);
            _navButtons[key] = btn;
            navPanel.Controls.Add(btn);
        }

        // Dock=Top: l'ultimo aggiunto e il piu vicino al bordo superiore, quindi si aggiunge
        // in ordine visivo inverso (il brand deve stare sopra la navigazione).
        _sidebar.Controls.Add(navPanel);
        _sidebar.Controls.Add(brand);

        if (Session.IsAdmin)
        {
            var adminBtn = MakeNavButton("Admin");
            adminBtn.Click += (_, _) => ShowPage("admin");
            _navButtons["admin"] = adminBtn;
            adminBtn.Location = new Point(8, 420);
            _sidebar.Controls.Add(adminBtn);
            adminBtn.BringToFront();
        }

        var logoutBtn = RoundedButton.Ghost("Esci");
        logoutBtn.Width = 176;
        logoutBtn.Location = new Point(8, 470);
        logoutBtn.Click += async (_, _) => await DoLogoutAsync();
        _sidebar.Controls.Add(logoutBtn);
        logoutBtn.BringToFront();
    }

    private RoundedButton MakeNavButton(string label)
    {
        return new RoundedButton
        {
            Text = label,
            Width = 176,
            Height = 32,
            Radius = 8,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12, 0, 0, 0),
            ForeColor = Theme.Text2,
            Font = Theme.FontRegular,
            Cursor = Cursors.Hand,
            BackColor = Theme.Bg2
        };
    }

    private void BuildTopBar()
    {
        _topBar.Dock = DockStyle.Top;
        _topBar.Height = 52;
        _topBar.BackColor = Theme.Bg2;
        Controls.Add(_topBar);

        _titleLabel.Font = Theme.FontMedium;
        _titleLabel.ForeColor = Theme.Text;
        _titleLabel.AutoSize = true;
        _titleLabel.Location = new Point(16, 16);
        _topBar.Controls.Add(_titleLabel);

        _userLabel.Text = Session.Username;
        _userLabel.ForeColor = Theme.Text2;
        _userLabel.Font = Theme.FontSmall;
        _userLabel.AutoSize = true;
        _topBar.Controls.Add(_userLabel);
        _topBar.Resize += (_, _) => PositionUserLabel();
        PositionUserLabel();
    }

    private void PositionUserLabel()
        => _userLabel.Location = new Point(_topBar.Width - _userLabel.Width - 16, 18);

    private void BuildContentArea()
    {
        _content.Dock = DockStyle.Fill;
        _content.BackColor = Theme.Bg;
        _content.Padding = new Padding(16);
        _content.AutoScroll = true;
        Controls.Add(_content);
        _content.BringToFront();
    }

    private void ShowPage(string key)
    {
        foreach (var kv in _navButtons)
        {
            kv.Value.BackColor = kv.Key == key ? Theme.AccentBg : Theme.Bg2;
            kv.Value.ForeColor = kv.Key == key ? Theme.AccentText : Theme.Text2;
        }

        _content.Controls.Clear();

        Control page = key switch
        {
            "dashboard" => new DashboardPage(),
            "stock" => new StockPage(),
            "sales" => new SalesPage(),
            "movements" => new MovementsPage(),
            "reports" => new ReportsPage(),
            "ai" => new AIPage(),
            "admin" => new AdminPage(),
            _ => new PlaceholderPage(NavItems.FirstOrDefault(n => n.Key == key).Label ?? key)
        };
        page.Dock = DockStyle.Fill;
        _content.Controls.Add(page);

        _titleLabel.Text = key switch
        {
            "dashboard" => "Dashboard",
            "admin" => "Pannello Admin",
            _ => NavItems.FirstOrDefault(n => n.Key == key).Label ?? key
        };
    }

    private async Task DoLogoutAsync()
    {
        await ApiClient.LogoutAsync();
        Hide();
        using var login = new LoginForm();
        if (login.ShowDialog() == DialogResult.OK)
        {
            _userLabel.Text = Session.Username;
            ShowPage("dashboard");
            Show();
        }
        else
        {
            Close();
        }
    }
}

// Segnaposto per le pagine non ancora implementate in questo passaggio.
file class PlaceholderPage : Control
{
    public PlaceholderPage(string name)
    {
        var lbl = new Label
        {
            Text = $"{name} — in arrivo",
            ForeColor = Theme.Text3,
            Font = Theme.FontRegular,
            AutoSize = true
        };
        Controls.Add(lbl);
        Resize += (_, _) => lbl.Location = new Point((Width - lbl.Width) / 2, (Height - lbl.Height) / 2);
    }
}
