using GesClo.Client.Api;

namespace GesClo.Client.Forms;

// Rispecchia frontend/src/pages/Login.jsx: indirizzo server, username, master password.
public class LoginForm : Form
{
    private readonly RoundedTextBox _serverBox = new();
    private readonly RoundedTextBox _userBox = new();
    private readonly RoundedTextBox _passBox = new();
    private readonly RoundedButton _loginBtn = RoundedButton.Primary("Accedi →");
    private readonly Label _errorLabel = new();
    private readonly CardPanel _card = new() { Radius = 16 };

    public LoginForm()
    {
        Text = "GesClo";
        Size = new Size(440, 520);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Theme.Bg;
        Font = Theme.FontRegular;

        BuildUi();
    }

    private void BuildUi()
    {
        _card.Size = new Size(360, 400);
        _card.Location = new Point((ClientSize.Width - _card.Width) / 2, 40);
        _card.Anchor = AnchorStyles.Top;
        Controls.Add(_card);

        var badge = new Panel { Size = new Size(34, 34), Location = new Point(24, 22), BackColor = Theme.Accent };
        Theme.ApplyRoundedRegion(badge, 9);
        _card.Controls.Add(badge);

        var logo = new Label
        {
            Text = "GesClo",
            Font = Theme.FontTitle,
            ForeColor = Theme.Text,
            AutoSize = true,
            Location = new Point(68, 26)
        };
        _card.Controls.Add(logo);

        var subtitle = new Label
        {
            Text = "Accedi al gestionale",
            Font = Theme.FontSmall,
            ForeColor = Theme.Text3,
            AutoSize = true,
            Location = new Point(24, 66)
        };
        _card.Controls.Add(subtitle);

        _errorLabel.ForeColor = Theme.DangerTxt;
        _errorLabel.BackColor = Theme.DangerBg;
        _errorLabel.Location = new Point(24, 96);
        _errorLabel.Size = new Size(312, 0);
        _errorLabel.Padding = new Padding(8, 6, 8, 6);
        _errorLabel.Visible = false;
        _card.Controls.Add(_errorLabel);

        int y = 108;
        y = AddField("Indirizzo server", _serverBox, y);
        _serverBox.Text = Session.ServerBaseUrl;
        y = AddField("Username", _userBox, y);
        y = AddField("Master password", _passBox, y);
        _passBox.UseSystemPasswordChar = true;

        _loginBtn.Location = new Point(24, y + 12);
        _loginBtn.Size = new Size(312, 36);
        _loginBtn.Click += async (_, _) => await DoLoginAsync();
        _card.Controls.Add(_loginBtn);

        AcceptButton = null; // il bottone e' auto-disegnato: l'Enter e' gestito via KeyDown sui campi
        foreach (var box in new[] { _serverBox, _userBox, _passBox })
            box.Inner.KeyDown += async (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await DoLoginAsync(); } };
    }

    private int AddField(string label, RoundedTextBox box, int y)
    {
        var lbl = new Label { Text = label, ForeColor = Theme.Text2, Font = Theme.FontSmall, AutoSize = true, Location = new Point(24, y) };
        _card.Controls.Add(lbl);
        y += 18;
        box.Location = new Point(24, y);
        box.Size = new Size(312, 30);
        _card.Controls.Add(box);
        return y + 42;
    }

    private void ShowError(string message)
    {
        _errorLabel.Text = message;
        _errorLabel.Size = new Size(312, TextRenderer.MeasureText(message, Font, new Size(296, 0), TextFormatFlags.WordBreak).Height + 14);
        _errorLabel.Visible = true;
    }

    private async Task DoLoginAsync()
    {
        _errorLabel.Visible = false;

        if (string.IsNullOrWhiteSpace(_userBox.Text) || _passBox.Text.Length < 6)
        {
            ShowError("Username e password (min 6 caratteri) richiesti");
            return;
        }

        Session.ServerBaseUrl = _serverBox.Text.Trim();
        _loginBtn.Enabled = false;
        _loginBtn.Text = "Accesso in corso...";
        try
        {
            await ApiClient.LoginAsync(_userBox.Text.Trim(), _passBox.Text);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (ApiException ex)
        {
            ShowError(ex.Message);
        }
        catch (Exception ex)
        {
            ShowError($"Errore imprevisto: {ex.Message}");
        }
        finally
        {
            _loginBtn.Enabled = true;
            _loginBtn.Text = "Accedi →";
        }
    }
}
