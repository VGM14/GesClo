using System.Text.Json.Serialization;

namespace GesClo.Client.Api;

public class LoginResponse
{
    [JsonPropertyName("token")]    public string Token { get; set; } = "";
    [JsonPropertyName("username")] public string Username { get; set; } = "";
    [JsonPropertyName("role")]     public string Role { get; set; } = "";
}

public class MeResponse
{
    [JsonPropertyName("id")]    public string Id { get; set; } = "";
    [JsonPropertyName("role")]  public string Role { get; set; } = "";
    [JsonPropertyName("name")]  public string Name { get; set; } = "";
    [JsonPropertyName("email")] public string Email { get; set; } = "";
}

public class ApiError
{
    [JsonPropertyName("error")] public string Error { get; set; } = "";
}

public class Stats
{
    [JsonPropertyName("totalProducts")]  public int TotalProducts { get; set; }
    [JsonPropertyName("lowStock")]       public int LowStock { get; set; }
    [JsonPropertyName("outOfStock")]     public int OutOfStock { get; set; }
    [JsonPropertyName("todayMovements")] public int TodayMovements { get; set; }
    [JsonPropertyName("todaySales")]     public int TodaySales { get; set; }
    [JsonPropertyName("todayRevenue")]   public double TodayRevenue { get; set; }
}

public class Movement
{
    [JsonPropertyName("id")]           public string Id { get; set; } = "";
    [JsonPropertyName("product_id")]   public string ProductId { get; set; } = "";
    [JsonPropertyName("product_name")] public string ProductName { get; set; } = "";
    [JsonPropertyName("type")]         public string Type { get; set; } = "";
    [JsonPropertyName("qty")]          public int Qty { get; set; }
    [JsonPropertyName("notes")]        public string Notes { get; set; } = "";
    [JsonPropertyName("user")]         public string? User { get; set; }
    [JsonPropertyName("created_at")]   public string? CreatedAt { get; set; }
}

public class SaleItem
{
    [JsonPropertyName("product_id")] public string ProductId { get; set; } = "";
    [JsonPropertyName("name")]       public string Name { get; set; } = "";
    [JsonPropertyName("price")]      public double Price { get; set; }
    [JsonPropertyName("qty")]        public int Qty { get; set; }
    [JsonPropertyName("subtotal")]   public double Subtotal { get; set; }
}

public class Sale
{
    [JsonPropertyName("id")]             public string Id { get; set; } = "";
    [JsonPropertyName("number")]         public int Number { get; set; }
    [JsonPropertyName("date")]           public string Date { get; set; } = "";
    [JsonPropertyName("customer_id")]    public string? CustomerId { get; set; }
    [JsonPropertyName("customer_name")]  public string CustomerName { get; set; } = "";
    [JsonPropertyName("items")]          public List<SaleItem> Items { get; set; } = new();
    [JsonPropertyName("subtotal")]       public double Subtotal { get; set; }
    [JsonPropertyName("discount")]       public double Discount { get; set; }
    [JsonPropertyName("tax")]            public double Tax { get; set; }
    [JsonPropertyName("total")]          public double Total { get; set; }
    [JsonPropertyName("payment_method")] public string PaymentMethod { get; set; } = "";
    [JsonPropertyName("payment_other")]  public string? PaymentOther { get; set; }
    [JsonPropertyName("notes")]          public string? Notes { get; set; }
}

public class Product
{
    [JsonPropertyName("id")]       public string Id { get; set; } = "";
    [JsonPropertyName("name")]     public string Name { get; set; } = "";
    [JsonPropertyName("barcode")]  public string? Barcode { get; set; }
    [JsonPropertyName("nfc_uid")]  public string? NfcUid { get; set; }
    [JsonPropertyName("qty")]      public int Qty { get; set; }
    [JsonPropertyName("unit")]     public string Unit { get; set; } = "pz";
    [JsonPropertyName("price")]    public double? Price { get; set; }
    [JsonPropertyName("category")] public string? Category { get; set; }
    [JsonPropertyName("notes")]    public string? Notes { get; set; }
}

public class Customer
{
    [JsonPropertyName("id")]      public string Id { get; set; } = "";
    [JsonPropertyName("name")]    public string Name { get; set; } = "";
    [JsonPropertyName("email")]   public string? Email { get; set; }
    [JsonPropertyName("phone")]   public string? Phone { get; set; }
    [JsonPropertyName("address")] public string? Address { get; set; }
    [JsonPropertyName("notes")]   public string? Notes { get; set; }
}

public class CashRegister
{
    [JsonPropertyName("name")]         public string? Name { get; set; }
    [JsonPropertyName("address")]      public string? Address { get; set; }
    [JsonPropertyName("vat_number")]   public string? VatNumber { get; set; }
    [JsonPropertyName("printer_type")] public string PrinterType { get; set; } = "a4";
    [JsonPropertyName("printer_ip")]   public string? PrinterIp { get; set; }
    [JsonPropertyName("printer_port")] public string? PrinterPort { get; set; }
    [JsonPropertyName("header_text")]  public string? HeaderText { get; set; }
    [JsonPropertyName("footer_text")]  public string? FooterText { get; set; }
    [JsonPropertyName("show_tax")]     public bool ShowTax { get; set; }
    [JsonPropertyName("tax_rate")]     public double TaxRate { get; set; } = 22;
    [JsonPropertyName("currency")]     public string Currency { get; set; } = "EUR";
}

public class UserAccount
{
    [JsonPropertyName("id")]       public string Id { get; set; } = "";
    [JsonPropertyName("username")] public string Username { get; set; } = "";
    [JsonPropertyName("email")]    public string? Email { get; set; }
    [JsonPropertyName("role")]     public string Role { get; set; } = "Operatore";
}

public class AiConfig
{
    [JsonPropertyName("provider")] public string Provider { get; set; } = "groq";
    [JsonPropertyName("key")]      public string? Key { get; set; }
    [JsonPropertyName("url")]      public string? Url { get; set; }
}

public class HealthResponse
{
    [JsonPropertyName("ok")]      public bool Ok { get; set; }
    [JsonPropertyName("version")] public string? Version { get; set; }
    [JsonPropertyName("uptime")]  public int Uptime { get; set; }
    [JsonPropertyName("db")]      public HealthDb? Db { get; set; }
}

public class HealthDb
{
    [JsonPropertyName("products")]  public int Products { get; set; }
    [JsonPropertyName("customers")] public int Customers { get; set; }
    [JsonPropertyName("movements")] public int Movements { get; set; }
    [JsonPropertyName("sales")]     public int Sales { get; set; }
}
