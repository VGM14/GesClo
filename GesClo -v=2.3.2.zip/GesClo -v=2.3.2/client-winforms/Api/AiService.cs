using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace GesClo.Client.Api;

public class AiResult
{
    public string Text = "";
    public string Source = "";
}

// Rispecchia frontend/src/services/aiService.js: chiamata diretta ai provider esterni
// (Groq/Gemini/AI locale) usando la chiave salvata in Admin -> AI Setup. Le azioni UI
// ([AZIONE]...[/AZIONE]) della webapp non sono applicate in questo client — solo la chat.
public static class AiService
{
    private const string GroqUrl = "https://api.groq.com/openai/v1/chat/completions";
    private const string GeminiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

    private const string SystemPrompt =
        "Sei GesBot, l'assistente AI integrato in GesClo, un gestionale tutto fare. " +
        "Aiuti gli utenti a usare il gestionale in italiano: prodotti, stock, vendite, movimenti, clienti, report. " +
        "Sii conciso e parla sempre in italiano.";

    private static readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(30) };

    public static async Task<AiResult> AskAsync(string userMessage, List<(string text, bool isUser)> history, AiConfig config)
    {
        if (config.Provider == "local" && !string.IsNullOrWhiteSpace(config.Url))
            return await AskLocalAsync(userMessage, config.Url!);

        if (string.IsNullOrWhiteSpace(config.Key))
            throw new ApiException("Nessuna API key configurata — vai in Admin → AI Setup");

        return config.Provider switch
        {
            "gemini" => await AskGeminiAsync(userMessage, history, config.Key!),
            _ => await AskGroqAsync(userMessage, history, config.Key!),
        };
    }

    private static async Task<AiResult> AskLocalAsync(string userMessage, string url)
    {
        var body = new { model = "llama3.2:3b", prompt = $"{SystemPrompt}\n\nUtente: {userMessage}", stream = false };
        using var req = new HttpRequestMessage(HttpMethod.Post, url.TrimEnd('/') + "/api/generate")
        { Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json") };
        HttpResponseMessage res;
        try { res = await _http.SendAsync(req); }
        catch { throw new ApiException("PC AI locale non raggiungibile"); }
        if (!res.IsSuccessStatusCode) throw new ApiException("PC AI locale non raggiungibile");
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        var text = doc.RootElement.TryGetProperty("response", out var r) ? r.GetString() ?? "" : "";
        return new AiResult { Text = text, Source = "AI locale" };
    }

    private static async Task<AiResult> AskGroqAsync(string userMessage, List<(string text, bool isUser)> history, string key)
    {
        var messages = new List<object> { new { role = "system", content = SystemPrompt } };
        foreach (var (msgText, msgIsUser) in history.TakeLast(6))
            messages.Add(new { role = msgIsUser ? "user" : "assistant", content = msgText });
        messages.Add(new { role = "user", content = userMessage });

        var body = new { model = "llama-3.1-8b-instant", messages, max_tokens = 1000 };
        using var req = new HttpRequestMessage(HttpMethod.Post, GroqUrl)
        {
            Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json")
        };
        req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", key);

        var res = await _http.SendAsync(req);
        var raw = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode)
        {
            var msg = "Errore Groq";
            try { using var errDoc = JsonDocument.Parse(raw); msg = errDoc.RootElement.GetProperty("error").GetProperty("message").GetString() ?? msg; } catch { }
            throw new ApiException(msg);
        }
        using var doc = JsonDocument.Parse(raw);
        var text = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
        if (string.IsNullOrEmpty(text)) throw new ApiException("Risposta Groq non valida");
        return new AiResult { Text = text, Source = "Groq" };
    }

    private static async Task<AiResult> AskGeminiAsync(string userMessage, List<(string text, bool isUser)> history, string key)
    {
        var contents = new List<object>();
        foreach (var (msgText, msgIsUser) in history.TakeLast(6))
            contents.Add(new { role = msgIsUser ? "user" : "model", parts = new[] { new { text = msgText } } });
        contents.Add(new { role = "user", parts = new[] { new { text = userMessage } } });

        var body = new { system_instruction = new { parts = new[] { new { text = SystemPrompt } } }, contents };
        using var req = new HttpRequestMessage(HttpMethod.Post, $"{GeminiUrl}?key={key}")
        {
            Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json")
        };
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) throw new ApiException("Errore Gemini — controlla la API key");
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        var text = doc.RootElement.GetProperty("candidates")[0].GetProperty("content").GetProperty("parts")[0].GetProperty("text").GetString();
        if (string.IsNullOrEmpty(text)) throw new ApiException("Risposta Gemini non valida");
        return new AiResult { Text = text, Source = "Gemini" };
    }
}
