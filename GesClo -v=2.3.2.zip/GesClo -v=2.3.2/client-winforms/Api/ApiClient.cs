using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace GesClo.Client.Api;

public class ApiException : Exception
{
    public ApiException(string message) : base(message) { }
}

// Rispecchia frontend/src/services/apiService.js: stessa base URL, stesso schema di
// autenticazione a token Bearer, stessi endpoint del backend Node esistente (server.js).
public static class ApiClient
{
    private static readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(15) };
    private static readonly JsonSerializerOptions _json = new() { PropertyNameCaseInsensitive = true };

    private static async Task<string> SendAsync(string path, HttpMethod method, object? body)
    {
        var url = Session.ServerBaseUrl.TrimEnd('/') + path;
        using var req = new HttpRequestMessage(method, url);
        if (!string.IsNullOrEmpty(Session.Token))
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.Token);
        if (body != null)
            req.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

        HttpResponseMessage res;
        try { res = await _http.SendAsync(req); }
        catch (Exception ex) { throw new ApiException($"Impossibile contattare il server ({Session.ServerBaseUrl}): {ex.Message}"); }

        var text = await res.Content.ReadAsStringAsync();

        if (!res.IsSuccessStatusCode)
        {
            var msg = $"Errore {(int)res.StatusCode}";
            try
            {
                var err = JsonSerializer.Deserialize<ApiError>(text, _json);
                if (!string.IsNullOrEmpty(err?.Error)) msg = err.Error;
            }
            catch { /* corpo non JSON, tieni il messaggio generico */ }
            throw new ApiException(msg);
        }

        return text;
    }

    private static async Task<T> RequestAsync<T>(string path, HttpMethod method, object? body = null)
    {
        var text = await SendAsync(path, method, body);
        return JsonSerializer.Deserialize<T>(text, _json)!;
    }

    private static Task RequestAsync(string path, HttpMethod method, object? body = null)
        => SendAsync(path, method, body);

    // ── AUTENTICAZIONE ────────────────────────────────────────
    public static async Task<LoginResponse> LoginAsync(string username, string password)
    {
        var result = await RequestAsync<LoginResponse>("/api/login", HttpMethod.Post, new { username, password });
        Session.Token = result.Token;
        Session.Username = result.Username;
        Session.Role = result.Role;
        return result;
    }

    public static async Task LogoutAsync()
    {
        try { await RequestAsync("/api/logout", HttpMethod.Post); } catch { /* non bloccare l'uscita se il server non risponde */ }
        Session.Clear();
    }

    public static Task<MeResponse> GetMeAsync() => RequestAsync<MeResponse>("/api/me", HttpMethod.Get);

    // Verifica raggiungibilità del server senza autenticazione (usato dal LoginForm).
    public static async Task<bool> CheckHealthAsync(string baseUrl)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, baseUrl.TrimEnd('/') + "/health");
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(3));
            var res = await _http.SendAsync(req, cts.Token);
            return res.IsSuccessStatusCode;
        }
        catch { return false; }
    }

    // ── DASHBOARD / SALUTE SERVER ──────────────────────────────
    public static Task<Stats> GetStatsAsync() => RequestAsync<Stats>("/api/stats", HttpMethod.Get);

    public static async Task<HealthResponse?> GetHealthAsync()
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, Session.ServerBaseUrl.TrimEnd('/') + "/health");
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(4));
            var res = await _http.SendAsync(req, cts.Token);
            if (!res.IsSuccessStatusCode) return null;
            return JsonSerializer.Deserialize<HealthResponse>(await res.Content.ReadAsStringAsync(), _json);
        }
        catch { return null; }
    }

    // ── PRODOTTI ───────────────────────────────────────────────
    public static Task<List<Product>> GetProductsAsync() => RequestAsync<List<Product>>("/api/products", HttpMethod.Get);
    public static Task<Product> AddProductAsync(object payload) => RequestAsync<Product>("/api/products", HttpMethod.Post, payload);
    public static Task UpdateProductAsync(string id, object payload) => RequestAsync($"/api/products/{id}", HttpMethod.Put, payload);
    public static Task DeleteProductAsync(string id) => RequestAsync($"/api/products/{id}", HttpMethod.Delete);
    public static Task<Product> FindByBarcodeAsync(string barcode) => RequestAsync<Product>($"/api/products/barcode/{Uri.EscapeDataString(barcode)}", HttpMethod.Get);

    // ── MOVIMENTI ──────────────────────────────────────────────
    public static Task<List<Movement>> GetMovementsAsync() => RequestAsync<List<Movement>>("/api/movements", HttpMethod.Get);
    public static Task<Movement> AddMovementAsync(object payload) => RequestAsync<Movement>("/api/movements", HttpMethod.Post, payload);

    // ── CLIENTI ────────────────────────────────────────────────
    public static Task<List<Customer>> GetCustomersAsync() => RequestAsync<List<Customer>>("/api/customers", HttpMethod.Get);
    public static Task<Customer> AddCustomerAsync(object payload) => RequestAsync<Customer>("/api/customers", HttpMethod.Post, payload);

    // ── VENDITE ────────────────────────────────────────────────
    public static Task<List<Sale>> GetSalesAsync() => RequestAsync<List<Sale>>("/api/sales", HttpMethod.Get);
    public static Task<Sale> AddSaleAsync(object payload) => RequestAsync<Sale>("/api/sales", HttpMethod.Post, payload);

    // ── CASSA ──────────────────────────────────────────────────
    public static Task<CashRegister> GetCashRegisterAsync() => RequestAsync<CashRegister>("/api/cash-register", HttpMethod.Get);
    public static Task UpdateCashRegisterAsync(object payload) => RequestAsync("/api/cash-register", HttpMethod.Put, payload);

    // ── UTENTI ─────────────────────────────────────────────────
    public static Task<List<UserAccount>> GetUsersAsync() => RequestAsync<List<UserAccount>>("/api/users", HttpMethod.Get);
    public static Task<UserAccount> AddUserAsync(object payload) => RequestAsync<UserAccount>("/api/users", HttpMethod.Post, payload);
    public static Task UpdateUserAsync(string id, object payload) => RequestAsync($"/api/users/{id}", HttpMethod.Put, payload);
    public static Task DeleteUserAsync(string id) => RequestAsync($"/api/users/{id}", HttpMethod.Delete);

    // ── AI ─────────────────────────────────────────────────────
    public static Task<AiConfig> GetAiConfigAsync() => RequestAsync<AiConfig>("/api/settings/ai", HttpMethod.Get);
    public static Task SaveAiConfigAsync(object payload) => RequestAsync("/api/settings/ai", HttpMethod.Post, payload);
}
