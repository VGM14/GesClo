namespace GesClo.Client.Api;

// Stato della sessione corrente: token, utente, indirizzo del server. Vive in memoria per
// tutta la durata del processo — come nel client web, un riavvio richiede un nuovo login.
public static class Session
{
    public static string ServerBaseUrl { get; set; } = "http://localhost:3001";
    public static string Token { get; set; } = "";
    public static string Username { get; set; } = "";
    public static string Role { get; set; } = "";

    public static bool IsAdmin => Role is "Super Admin" or "Admin";

    public static void Clear()
    {
        Token = "";
        Username = "";
        Role = "";
    }
}
