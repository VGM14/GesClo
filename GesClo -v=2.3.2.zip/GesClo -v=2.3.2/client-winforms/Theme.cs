using System.ComponentModel;
using System.Drawing.Drawing2D;

namespace GesClo.Client;

// Stessa palette del tema scuro di frontend/src/index.css (.dark), che è il tema di default dell'app.
static class Theme
{
    public static readonly Color Bg         = ColorTranslator.FromHtml("#1c1c1a");
    public static readonly Color Bg2        = ColorTranslator.FromHtml("#242422");
    public static readonly Color Bg3        = ColorTranslator.FromHtml("#2c2c2a");
    public static readonly Color Border     = ColorTranslator.FromHtml("#3a3a38");
    public static readonly Color Text       = ColorTranslator.FromHtml("#e8e6de");
    public static readonly Color Text2      = ColorTranslator.FromHtml("#a8a69e");
    public static readonly Color Text3      = ColorTranslator.FromHtml("#6a6866");
    public static readonly Color Accent     = ColorTranslator.FromHtml("#7F77DD");
    public static readonly Color AccentBg   = ColorTranslator.FromHtml("#26215C");
    public static readonly Color AccentText = ColorTranslator.FromHtml("#AFA9EC");
    public static readonly Color SuccessBg  = ColorTranslator.FromHtml("#173404");
    public static readonly Color SuccessTxt = ColorTranslator.FromHtml("#C0DD97");
    public static readonly Color DangerBg   = ColorTranslator.FromHtml("#501313");
    public static readonly Color DangerTxt  = ColorTranslator.FromHtml("#F09595");
    public static readonly Color WarnBg     = ColorTranslator.FromHtml("#412402");
    public static readonly Color WarnTxt    = ColorTranslator.FromHtml("#FAC775");

    public static readonly Font FontRegular = new("Segoe UI", 9.5f);
    public static readonly Font FontMedium  = new("Segoe UI", 9.5f, FontStyle.Bold);
    public static readonly Font FontTitle   = new("Segoe UI", 14f, FontStyle.Bold);
    public static readonly Font FontSmall   = new("Segoe UI", 8.5f);

    // Percorso di un rettangolo con angoli arrotondati (stesso effetto del border-radius CSS).
    public static GraphicsPath RoundedPath(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        if (radius <= 0) { path.AddRectangle(bounds); return path; }
        int d = Math.Min(radius * 2, Math.Min(bounds.Width, bounds.Height));
        path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
        path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
        path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    // Ritaglia un controllo (es. un badge colorato) in un quadrato/rettangolo arrotondato.
    public static void ApplyRoundedRegion(Control c, int radius)
    {
        void Update()
        {
            if (c.Width > 0 && c.Height > 0)
                c.Region = new Region(RoundedPath(new Rectangle(0, 0, c.Width, c.Height), radius));
        }
        c.Resize += (_, _) => Update();
        Update();
    }

    public static void StyleTextBox(RoundedTextBox t)
    {
        t.ForeColor = Text;
        t.Font = FontRegular;
    }
}

// Panel con bordo sottile color Theme.Border e angoli arrotondati, per rispecchiare le card
// CSS (background var(--bg2), border 0.5px solid var(--border), border-radius: 12px).
class CardPanel : Panel
{
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int Radius { get; set; } = 12;

    public CardPanel()
    {
        BackColor = Theme.Bg2;
        SetStyle(ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint, true);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (Width > 0 && Height > 0)
            Region = new Region(Theme.RoundedPath(new Rectangle(0, 0, Width, Height), Radius));
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var pen = new Pen(Theme.Border);
        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        e.Graphics.DrawPath(pen, Theme.RoundedPath(rect, Radius));
    }
}

// Bottone auto-disegnato con angoli arrotondati (border-radius CSS: 8-9px sui bottoni della webapp).
// FlatStyle di WinForms non supporta angoli arrotondati nativamente, quindi si disegna a mano.
class RoundedButton : Button
{
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int Radius { get; set; } = 8;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Color? BorderColor { get; set; }

    private Color _fill;

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new Color BackColor
    {
        get => _fill;
        set { _fill = value; Invalidate(); }
    }

    public RoundedButton()
    {
        _fill = Theme.Bg2;
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        FlatAppearance.MouseOverBackColor = Color.Transparent;
        FlatAppearance.MouseDownBackColor = Color.Transparent;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
        base.BackColor = Color.Transparent;
        TextAlign = ContentAlignment.MiddleCenter;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedPath(rect, Radius);
        using (var fill = new SolidBrush(_fill))
            e.Graphics.FillPath(fill, path);
        if (BorderColor is { } bc)
        {
            using var pen = new Pen(bc);
            e.Graphics.DrawPath(pen, path);
        }
        var textRect = new Rectangle(Padding.Left, 0, Width - Padding.Left - Padding.Right, Height);
        var flags = TextAlign switch
        {
            ContentAlignment.MiddleLeft  => TextFormatFlags.Left,
            ContentAlignment.MiddleRight => TextFormatFlags.Right,
            _                            => TextFormatFlags.HorizontalCenter
        } | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis;
        TextRenderer.DrawText(e.Graphics, Text, Font, textRect, ForeColor, flags);
    }

    public static RoundedButton Primary(string text)
    {
        var b = new RoundedButton { Text = text, Height = 34, Radius = 9, ForeColor = Color.White, Font = Theme.FontMedium, Cursor = Cursors.Hand };
        b.BackColor = Theme.Accent;
        return b;
    }

    public static RoundedButton Ghost(string text)
    {
        var b = new RoundedButton { Text = text, Height = 32, Radius = 8, ForeColor = Theme.Text2, Font = Theme.FontRegular, Cursor = Cursors.Hand, BorderColor = Theme.Border };
        b.BackColor = Theme.Bg2;
        return b;
    }
}

// TextBox con bordo arrotondato: incapsula una TextBox reale senza bordo dentro un
// contenitore auto-disegnato, per rispecchiare i campi input della webapp (radius ~8px).
class RoundedTextBox : UserControl
{
    public readonly TextBox Inner = new();

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int Radius { get; set; } = 8;

    public override string Text
    {
        get => Inner.Text;
        set => Inner.Text = value ?? "";
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool UseSystemPasswordChar
    {
        get => Inner.UseSystemPasswordChar;
        set => Inner.UseSystemPasswordChar = value;
    }

    public RoundedTextBox()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
        base.BackColor = Color.Transparent;
        Height = 30;

        Inner.BorderStyle = BorderStyle.None;
        Inner.BackColor = Theme.Bg3;
        Inner.ForeColor = Theme.Text;
        Inner.Font = Theme.FontRegular;
        Controls.Add(Inner);

        Resize += (_, _) => LayoutInner();
        LayoutInner();
    }

    private void LayoutInner()
    {
        Inner.Width = Math.Max(0, Width - 20);
        Inner.Location = new Point(10, (Height - Inner.Height) / 2);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedPath(rect, Radius);
        using (var fill = new SolidBrush(Theme.Bg3))
            e.Graphics.FillPath(fill, path);
        using var pen = new Pen(Theme.Border);
        e.Graphics.DrawPath(pen, path);
    }
}
