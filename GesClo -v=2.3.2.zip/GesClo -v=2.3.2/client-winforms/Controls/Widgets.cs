namespace GesClo.Client.Controls;

// Helper condivisi per evitare di ripetere lo stesso boilerplate in ogni pagina
// (campi con etichetta, dialog modali stile "card", badge di stato colorati).
static class Widgets
{
    // Aggiunge "label" + campo di input a un contenitore in posizione assoluta, ritorna la Y successiva.
    public static int LabeledField(Control parent, string label, Control input, int x, int y, int width)
    {
        var lbl = new Label { Text = label, ForeColor = Theme.Text2, Font = Theme.FontSmall, AutoSize = true, Location = new Point(x, y) };
        parent.Controls.Add(lbl);
        y += 18;
        input.Location = new Point(x, y);
        input.Width = width;
        parent.Controls.Add(input);
        return y + input.Height + 12;
    }

    public static ComboBox MakeCombo(string[] items, int selected = 0)
    {
        var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat, BackColor = Theme.Bg3, ForeColor = Theme.Text, Font = Theme.FontRegular, Height = 26 };
        c.Items.AddRange(items);
        if (items.Length > 0) c.SelectedIndex = selected;
        return c;
    }

    // Badge colorato tipo "pill" (stato scorte, entrata/uscita, ruolo utente, ecc.)
    public static Label Pill(string text, Color bg, Color fg)
    {
        return new Label
        {
            Text = text,
            BackColor = bg,
            ForeColor = fg,
            Font = Theme.FontSmall,
            AutoSize = true,
            Padding = new Padding(8, 3, 8, 3),
            TextAlign = ContentAlignment.MiddleCenter
        };
    }
}

// Form modale minimale in stile "card": bordo arrotondato, centrata sul parent.
class ModalForm : Form
{
    protected readonly CardPanel Card = new() { Radius = 14 };

    public ModalForm(int width, int height)
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Theme.Bg;
        Size = new Size(width, height);
        Card.Dock = DockStyle.Fill;
        Card.Padding = new Padding(22);
        Controls.Add(Card);

        var closeHint = new Label { Text = "Esc per annullare", Visible = false };
        Controls.Add(closeHint);
        KeyPreview = true;
        KeyDown += (_, e) => { if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); } };
    }

    protected Label Title(string text)
    {
        var lbl = new Label { Text = text, ForeColor = Theme.Text, Font = new Font("Segoe UI", 12f, FontStyle.Bold), AutoSize = true, Location = new Point(22, 20) };
        Card.Controls.Add(lbl);
        return lbl;
    }
}
